# GAPS AND OPEN QUESTIONS

## Open questions

1. **Canonical source files:** the seven named files were not retrievable in File Library during this pass; no exact line-level agreement claim can be made.
2. **KudaGo + MAX legal fit:** does a clickable KudaGo source link inside the MAX Mini App / bot satisfy the licence requirement that the link be open for indexing and free of nofollow/noindex semantics?
3. **Advertising material:** how are KudaGo advertising materials/tokens represented in actual API responses, and which payloads must Povod exclude or specially handle?
4. **Current KudaGo runtime:** current v1.4 response shapes, headers, pagination stability, removals and cancellation/edit behavior were not captured here.
5. **Provider rate limit:** no documented rate-limit contract was found; unknown is not “unlimited”.
6. **`actual_since` overlap:** validate the practical behavior with a known ongoing event that started before the filter moment.
7. **Occurrence continuity:** KudaGo dates have no documented ID. What edit patterns occur when an event time/date changes?
8. **Target database host:** exact PostgreSQL/PostGIS/pg_trgm availability and extension privileges on the chosen deployment host.
9. **PostgreSQL benchmark:** real Moscow corpus size, concurrency, index sizes, feed/search/geo P95 and reconcile/write cost.
10. **Russian search quality:** names, Cyrillic/Latin, `ё/е`, punctuation, aliases/transliteration and venue/artist typos.
11. **Price semantics:** UX decision for strict budget with `FROM`, conditional deposits, unknown fees or Event-level-only price evidence.
12. **Raw retention:** required retention horizon after provider terms, storage cost and debugging/audit needs.
13. **Freshness policy:** product-level soft/hard freshness thresholds and behavior after provider outages.
14. **Missing policy:** how many completed reconciliations/time elapsed before a missing source object is withdrawn.
15. **SLOs:** team must set acceptance targets before benchmarks; do not retrofit success after measurement.
16. **Geocoding:** whether provider coordinate coverage is sufficient. If not, a separate provenance-bearing geocoder decision is required.
17. **Current source URL behavior:** whether KudaGo `site_url` opens reliably/safely on MAX web/mobile.
18. **Images:** image rights/attribution are mainly a provider/legal topic; the pipeline should carry source/author metadata and never invent rights.
19. **Cancellation:** whether KudaGo exposes a reliable explicit cancellation field/status in current runtime.
20. **Publication/update semantics:** `publication_date` exists but must not be treated as modification time without evidence.

## What requires runtime

- KudaGo live API receipt.
- Target Postgres/PostGIS extension/version check.
- Search relevance fixtures.
- Feed/search/geo benchmark.
- Pagination/edit/removal observation.
- Crash/checkpoint recovery test.

## What requires human/manual decision

- Freshness SLO and stale UI policy.
- Strict-budget UNKNOWN UX.
- Acceptable search relevance.
- Raw retention period.
- One condition revision/fingerprint versus dual revision counters.
- Timing of a second provider.

## What requires legal review

- KudaGo indexable source-link compliance inside MAX.
- Advertising-token handling.
- Future commercial use/transfer of KudaGo data.
- Any external cache/search licence selected later.

## What requires Codex/host

- Actual repo path mapping.
- Migrations/constraints.
- Provider runtime spike.
- Query plans/benchmarks.
- Sanitized evidence capture.
- Host extension/version check.

## What is closed enough for implementation

- Event and Occurrence stay distinct.
- Provider IDs and canonical IDs stay distinct.
- UNKNOWN/no-fabrication invariants stay.
- PostgreSQL is the initial source of truth.
- PostGIS is preferred geo implementation if supported.
- FTS + pg_trgm is the first text-search implementation.
- Redis/external search/Kafka/vector/LLM paths are deferred.
- KudaGo is not a documented cursor/change-feed source; reconciliation is required.
