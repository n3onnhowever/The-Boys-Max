# OFFICIAL SOURCE NOTES

Concise derived notes; no source document is copied here.

## PostgreSQL
- 18.6 and 17.11 released 2026-08-13.
- 19 Beta 3 is prerelease and not intended for production.
- GIN is preferred for built-in FTS.
- pg_trgm provides similarity/index support.
- index-only benefit depends on all-visible pages; INCLUDE payload can enlarge indexes.
- partial-index use depends on query predicate implication.
- JSONB is normalized, not exact raw text.
- timestamptz does not retain the original timezone label.
- materialized views can be stale until refreshed.

## PostGIS
- 3.6.4 released 2026-06-08 with security-relevant fixes.
- 3.7.0rc2 released 2026-09-08 and is a release candidate with breaking changes.
- ST_DWithin geography uses meters and can exploit index-assisted filtering.

## KudaGo
- API v1.4 remains documented.
- Events page_size maximum 100.
- actual_since = started after; actual_until = ended before; UTC.
- price is in Event schema; dates[] is separate and lacks a documented ID.
- text_format can be text/plain/html.
- licence requires direct concrete source link open to indexing, without nofollow/noindex.
- terms can change unilaterally; advertising-token restriction exists.
- no updated_since term or published rate-limit contract was found in reviewed docs.

## Redis/search alternatives
- All compared projects are active; no evidence says Povod needs them in P0.
- Licences and operational surfaces differ materially.
