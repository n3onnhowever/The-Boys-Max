# FINAL VERIFIED RESEARCH — Production-quality Data Pipeline for «Повод»

**Project:** «Повод»  
**Team:** The Boys  
**Date checked:** 18.09.2026  
**Version:** FINAL-2026-09-18  
**Verification status:** **FINAL WITH OPEN BLOCKERS**  
**Scope:** ingestion, identity/dedup, PostgreSQL 17+, search/geo, price, ranking, quality, cache, freshness and migration path.

## Status vocabulary

- **FACT** — directly supported by a source.
- **INFERENCE** — follows from evidence but is not stated by the source.
- **RECOMMENDATION** — recommended for Povod.
- **PROPOSAL** — implementation/design value not yet accepted or measured.
- **OPEN QUESTION** — unresolved.
- **BLOCKER** — can block release/implementation decision.
- **VERIFIED BY OFFICIAL DOCS** — current primary docs checked.
- **VERIFIED BY SOURCE CODE** — official repository/licence/release metadata checked.
- **VERIFIED BY RUNTIME** — actual execution/evidence was observed.
- **NEEDS RUNTIME VERIFICATION** — docs support the design but Povod behavior/performance was not run.
- **NEEDS LEGAL VERIFICATION** — legal/compliance interpretation is unresolved.
- **REJECTED / DEFERRED** — deliberately not in P0.

# 1. EXECUTIVE SUMMARY

The previous architecture direction survives the verification, but several statements must be weakened from “production fact” to “proposal pending runtime”.

**Recommended P0 baseline:**
- PostgreSQL 17.11 or 18.6 as single source of truth.
- Stable PostGIS 3.6.x, preferably the current verified 3.6.4 line when the host supports it.
- PostgreSQL FTS + GIN for primary text retrieval.
- pg_trgm for typo/fuzzy fallback/candidate retrieval.
- Page-based KudaGo ProviderAdapter with idempotent rolling/broad reconciliation plus complete scoped reconciliation.
- Separate canonical Event / Occurrence / Venue identities and provider source mappings.
- Price parser with exact/from/range/free/conditional/unknown, raw text and explicit price scope.
- Hard constraints before soft ranking.
- Deterministic explanations and warnings.
- No Redis or external search service before a benchmark proves a need.

**Most important verified deltas:**
1. KudaGo `actual_since` means **started after**, not “updated since” or “active since”. Naive incremental logic is unsafe.
2. KudaGo Event `price` is free-form at Event level while `dates[]` is separate; `price_scope` must be explicit.
3. KudaGo date entries in the documented schema have no per-date ID, so stable provider Occurrence identity cannot be asserted absolutely.
4. JSONB is not byte/text-faithful raw storage; exact evidence requires a separate raw representation if needed.
5. PostgreSQL covering/partial “exact indexes” must be benchmarked; official docs describe planner/churn limitations.
6. KudaGo's open licence creates an unresolved legal/manual gate for direct source links open to indexing inside MAX.
7. Previous exact sync cadence, stale thresholds, retry numbers, TTLs and ranking weights were false precision and are downgraded to proposals/configuration.

The research remains **FINAL WITH OPEN BLOCKERS** because current live KudaGo behavior, Povod PostgreSQL benchmarks and KudaGo/MAX legal fit were not directly proven here.

# 2. FINAL VERDICT

## Recommended architecture

```text
KudaGo / future providers
        │
        ▼
ProviderAdapter
  pagination / retries / capabilities
        │
        ├── sync-run ledger
        ├── raw_body? + payload_jsonb + hash
        └── provider source IDs / source URL
        │
        ▼
Normalization
 Event ── Occurrence ── Venue
   │          │           │
 categories  price       geography
   │          │
 source/provenance + condition revision/fingerprint
        │
        ▼
Quality + freshness gate
        │
        ▼
PostgreSQL
  B-tree / unique constraints
  GIN FTS
  pg_trgm
  PostGIS GiST
        │
        ▼
hard constraints PASS / FAIL / UNKNOWN
        │
        ▼
deterministic explainable ranking
        │
        ▼
MAX API / Mini App / optional bot continuation
```

**Decision:** PostgreSQL should remain the only authoritative application datastore for P0 and the first product version **unless runtime evidence disproves the choice**.

This is a recommendation, not a performance benchmark result.

No evidence in this research justifies Redis, a second search engine, Kafka, vector infrastructure, an LLM recommender/parser, or Event/Occurrence partitioning.

# 3. WHAT WAS VERIFIED

## Project context

Verified against the explicit frozen rules supplied in this chat and the available `POVOD_TEST_DECK_V1.pptx`.

The deck corroborates:
- solo-first/social-next;
- one normalized event dataset;
- occurrence/venue/source normalization;
- old social confirmation must not silently survive time/price/place/session changes;
- runtime/provider/measured results are not represented as confirmed;
- pilot status `NOT RUN`.

### Source-of-truth limitation

The exact canonical files named by the user were searched in File Library but were not retrievable by exact name. Therefore this pass **does not claim a line-by-line canonical-file audit**.

## PostgreSQL

Verified from official docs/releases:
- current supported patch releases;
- PG19 beta status;
- generated-column differences between PG17 and PG18;
- indexes, partial/covering limitations;
- FTS/GIN;
- pg_trgm;
- JSONB behavior;
- timestamptz semantics;
- UPSERT;
- materialized-view staleness;
- partitioning considerations;
- EXPLAIN and pg_stat_statements.

## PostGIS

Verified:
- 3.6.4 release/fixes;
- 3.7.0rc2 prerelease/breaking status;
- `ST_DWithin` geography/index semantics;
- repository activity/licence snapshot.

## KudaGo

Verified from official documentation/licence:
- API v1.4;
- page/page_size and maximum 100;
- event fields and date filters;
- price/is_free;
- dates/place/location expansions;
- source URL;
- text format;
- no documented `updated_since` found;
- no published rate-limit contract found;
- source-link licence requirement;
- unilateral term-change clause;
- advertising-material/token restriction;
- data/API correctness/availability disclaimer.

Not runtime-verified:
- current live response body;
- current headers;
- current throttling behavior;
- edit/removal/cancellation patterns.

## Alternatives

Official repositories/docs were checked for:
- Redis;
- Meilisearch;
- Typesense;
- Elasticsearch;
- OpenSearch.

Repository activity and licence were recorded. Stars were not used as a decision basis.

# 4. CURRENT STATE AS OF 18.09.2026

## PostgreSQL

PostgreSQL 18.6 and 17.11 are current supported patch releases verified in the official 13.08.2026 release announcement. PostgreSQL 19 Beta 3 remains prerelease; official beta guidance advises against production/active-development use.

**Recommendation:** if Povod already uses PG17, patch to 17.11 and do not migrate only for new features. A greenfield supported deployment may use 18.6 if the selected host supports it. Do not use PG19 beta.

## PostGIS

3.6.4 is the stable verified line checked here. 3.7.0rc2 is a release candidate and lists breaking changes.

**Recommendation:** stable 3.6.x, not RC.

## KudaGo

The official docs still expose API v1.4. Their changelog shown in the current docs lists v1.4 from 2018. This is an important maintenance signal but not proof of runtime stability.

**Recommendation:** treat docs as contract evidence and obtain a fresh runtime receipt before calling current provider behavior verified.

# 5. KEY FINDINGS

## 5.1 Reconciliation is the critical ingestion problem

KudaGo exposes page pagination and event start/end filters, not a documented change cursor. The safe baseline is:

1. fetch a scoped window;
2. persist source payload/hash and mappings idempotently;
3. normalize;
4. commit the page durably;
5. advance checkpoint;
6. only a **completed** scoped reconcile can affect “missing” state;
7. periodically repeat/broaden enough scope to catch edits and long-running events.

A failed or partial crawl must never be interpreted as deletion.

## 5.2 `actual_since` is easy to misuse

Official semantics are events that **started after** the supplied UTC moment.

Consequences:
- not an update watermark;
- not “changed since”;
- not equivalent to “currently active”;
- `actual_since=now` can logically exclude an ongoing event that started yesterday;
- rolling sync must overlap/use a broader product horizon.

This requires an explicit runtime fixture before cadence/window behavior is frozen.

## 5.3 Raw payload should mean what the specification says

If raw retention means “semantic provider JSON”, JSONB is useful.

If raw retention means exact transport evidence/parser regression fixture, JSONB alone is insufficient because it normalizes representation.

Recommended split:
- optional `raw_body text/bytea/object`;
- parsed `payload_jsonb`;
- `payload_hash`;
- adapter/schema version.

Retention period remains an OPEN QUESTION.

## 5.4 Event and Occurrence identity remains correct, but occurrence continuity is not trivial

KudaGo provides Event IDs but documented expanded `dates[]` entries do not expose an ID.

Therefore:
- provider Event identity can be hard-mapped;
- provider Occurrence identity is not guaranteed;
- timestamp must not become immutable occurrence ID;
- a clear correction can keep canonical continuity;
- ambiguous date mutation must prefer correctness over continuity.

A false merge is worse than a new occurrence.

## 5.5 Price needs scope, not only parser type

KudaGo `price` belongs to the Event schema. `dates[]` contains timing fields, not per-date price.

So Povod needs both parser semantics **and evidence scope**:

`price_scope = EVENT | OCCURRENCE | UNKNOWN`

If the source only proves Event-level price, Povod must not silently phrase it as guaranteed session-specific price.

## 5.6 PostgreSQL search is the right first implementation, not a proven benchmark winner

FTS, GIN, pg_trgm and PostGIS capabilities are official and cover the P0 feature need.

But capability is not Povod runtime proof. The statement “PostgreSQL is fast enough” remains `NEEDS RUNTIME VERIFICATION` until representative data/concurrency/relevance are measured.

## 5.7 Exact indexes need less certainty

Strong baseline indexes:
- source identity uniqueness;
- Event/category relation;
- FTS GIN;
- trigram GIN;
- Venue GiST.

Hot occurrence covering/partial indexes must be derived from actual query/ORM plans.

Reasons:
- index-only scans may still hit the heap on recently mutated pages;
- INCLUDE payload can bloat indexes;
- partial indexes need planner-recognizable predicates;
- parameterized SQL can defeat expected partial-index use.

## 5.8 KudaGo provenance is a legal concern

The current open licence requires specific-source links open for indexing and without nofollow/noindex semantics. This is not a database-only decision.

The pipeline should:
- retain `site_url`;
- never detach normalized data from provenance;
- expose source URL to API/UI;
- record legal-check status in release readiness.

Whether MAX rendering satisfies the licence is a manual/legal question.

# 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

See `DECISION_DELTA.md`.

Major changes:
- PostgreSQL stays baseline, but performance sufficiency is no longer stated as runtime fact.
- hot covering/partial index definitions are candidates;
- PG17/18 generated-column behavior is version-specific;
- `actual_since` semantics are corrected precisely;
- `price_scope` is added;
- raw-body vs parsed-JSONB is separated;
- occurrence continuity is conservative because KudaGo date entries lack IDs;
- KudaGo licence becomes a release/legal gate;
- fixed cadence/stale/retry/TTL/weight numbers are downgraded to proposals.

# 7. CONFIRMED FACTS

## PostgreSQL / PostGIS

- PostgreSQL 18.6 and 17.11 were released 13.08.2026.
- PostgreSQL 19 Beta 3 is not intended for production.
- PG17 generated columns are stored; PG18 introduces virtual generated columns/default behavior.
- GIN is preferred for built-in PostgreSQL FTS.
- pg_trgm supports indexed similarity/fuzzy retrieval.
- `timestamptz` does not retain original timezone label.
- JSONB normalizes representation.
- `ON CONFLICT` supports UPSERT semantics.
- materialized views can be stale until refresh.
- PostGIS 3.6.4 was released 08.06.2026.
- PostGIS 3.7.0rc2 is prerelease and lists breaking changes.
- `ST_DWithin` geography distance is in meters and can use spatial index filtering.

## KudaGo

- v1.4 is documented.
- page_size maximum is 100.
- `actual_since` = started after; `actual_until` = ended before; UTC semantics.
- Event has free-form price and `is_free`.
- expanded Event dates have time/schedule fields and no documented ID.
- `site_url` is part of Event data.
- `text_format` supports html/plain/text.
- no `updated_since` term was found in the current docs.
- no published rate-limit contract was found in the reviewed docs.
- licence requires direct specific-source links open for indexing/no nofollow/noindex.
- terms may change unilaterally.
- advertising-token restriction exists.
- provider disclaims correctness/availability.

## Open-source alternatives

- Redis 8+ has a current tri-licence model and 8.10.2 was released 17.09.2026.
- Meilisearch is active; latest checked release v1.53.2; root licence is MIT AND BUSL-1.1.
- Typesense is active; stable checked release v30.2; server licence GPL-3.0.
- Elasticsearch is active; latest checked release v9.5.4; source licence is mixed/triple with exceptions.
- OpenSearch is active; checked release 3.8.0; Apache-2.0.

# 8. RECOMMENDATIONS

## Ingestion

Provider-specific responsibilities:
- pagination;
- request fields/expands;
- raw schema validation;
- source identities;
- source URL;
- error/retry classification;
- capability declaration.

Not ProviderAdapter responsibilities:
- cross-provider fuzzy merge;
- product ranking;
- silent defaults/fabrication.

Conceptual capability contract:

```ts
interface ProviderCapabilities {
  paginationMode: "PAGE" | "CURSOR" | "NONE";
  maxDocumentedPageSize?: number;
  supportsUpdatedSince: boolean;
  supportsDeletionFeed: boolean;
  supportsOccurrenceIds: boolean;
  documentedRateLimit?: unknown;
}
```

KudaGo baseline:
- PAGE;
- max 100;
- no documented updated-since;
- no documented occurrence IDs for dates;
- rate limit UNKNOWN;
- rolling/broad reconciliation.

### Retry

Use:
- timeout;
- transient-error classification;
- bounded exponential backoff;
- jitter;
- maximum attempts or elapsed time;
- `Retry-After` when observed/applicable.

Do not retry 400/401/403 blindly, do not stack retry layers, and do not retry unsafe non-idempotent operations without an idempotency mechanism.

Exact numeric settings remain runtime-tuned.

## Identity

### Event
Canonical opaque ID independent of provider.

`event_source(provider_id, provider_event_id)` is the hard provider mapping.

### Occurrence
Canonical opaque ID.

Candidate matching only within a provider Event and relevant time/venue neighborhood. Ambiguous mutation creates a new/superseding occurrence rather than unsafe merge.

### Venue
Provider venue ID mapping first. No coordinates → NULL. Do not auto-merge solely on fuzzy name.

## PostgreSQL schema

Core:
- provider;
- provider_sync_run;
- provider_checkpoint;
- provider_raw_object_version;
- Event/Event source;
- Occurrence/Occurrence source-reconcile mapping;
- Venue/Venue source;
- category/provider category map/event category;
- search projection.

Occurrence fields:
- local date/time;
- exact `timestamptz` only when exact;
- time precision;
- source/raw timezone;
- normalized zone if controlled;
- status;
- condition revision/fingerprint;
- last seen/verified;
- price semantics/scope;
- provenance.

### Strong baseline indexes

```sql
CREATE UNIQUE INDEX ... ON event_source(provider_id, provider_event_id);
CREATE UNIQUE INDEX ... ON event_category(event_id, category_id);
CREATE INDEX ... ON event_category(category_id, event_id);
CREATE INDEX ... ON event_search_document USING GIN(search_vector);
CREATE INDEX ... ON event_search_document
  USING GIN(search_text_normalized gin_trgm_ops);
CREATE INDEX ... ON venue USING GIST(position)
WHERE position IS NOT NULL;
```

A provider-occurrence uniqueness constraint exists only for providers that truly expose a stable provider occurrence ID.

A composite occurrence feed index such as `(city_id, start_date_local, starts_at, id)` possibly partial on a stable ACTIVE status is a **benchmark candidate**, not a frozen exact migration.

## Search

Projection:
- title;
- participants/artist;
- venue;
- categories;
- normalized text;
- weighted `tsvector`.

Flow:
1. normalize query;
2. FTS;
3. trigram fallback/candidates if needed;
4. hard filters;
5. text relevance;
6. optional personalization tie-break.

A named text query must not be drowned by weak personalization.

## Geo

Use nullable `geography(Point,4326)`.

Filter with `ST_DWithin(position, user_point, radius_meters)`.

Missing point → UNKNOWN, not zero distance or city center.

## Price

Kinds:
- EXACT;
- FROM;
- RANGE;
- FREE;
- CONDITIONAL;
- UNKNOWN.

Scope:
- EVENT;
- OCCURRENCE;
- UNKNOWN.

Also retain raw text, parser version/confidence, currency, deposit state/amount and service-fee state/amount.

Hard strict budget:
- known safe upper bound can PASS;
- known violation FAIL;
- unresolved upper cost/fee/scope is UNKNOWN.

## Ranking v1

Recommended P0:
- hard-filter tri-state first;
- small deterministic rule-based soft ordering;
- explanation codes;
- deterministic tie-break.

Potential signals if actually available:
- explicit interests;
- follows only if in scope/data;
- time fit;
- known budget fit;
- known distance fit;
- freshness.

Do not freeze arbitrary weights without labels/calibration.

## Cache

P0: no Redis.

Allowed:
- HTTP validation/ETag for public detail when revision is encoded;
- moderate caching of low-risk category/city metadata;
- static asset/config caching where safe.

Do not shared-cache identity/session/preferences/saves/social confirmations/personalized feed or long-stale current price/time/place.

## Freshness

Track:
- `last_seen_at`;
- `last_verified_at`;
- provider last successful complete reconcile;
- current run status.

Potential states:
- ACTIVE;
- SUSPECT_MISSING;
- STALE;
- WITHDRAWN;
- CANCELLED;
- EXPIRED.

Exact time thresholds and N-miss policy remain configuration pending evidence.

# 9. REJECTED / DEFERRED OPTIONS

## REJECT P0
- PostgreSQL 19 Beta 3.
- PostGIS 3.7.0rc2.
- Kafka/Redpanda.
- Elasticsearch/OpenSearch.
- vector DB.
- LLM ranking/dedup/price parsing.
- Event/Occurrence partitioning.
- fake geo/time/price defaults.

## DEFER
- Redis.
- Meilisearch.
- Typesense.
- materialized views for live data.
- cross-provider fuzzy dedup.
- complex synonym/transliteration service.
- second provider-specific canonical merge engine.

# 10. RISKS

See `RISKS.md`.

Top risks:
1. KudaGo legal source-link/indexability fit in MAX.
2. `actual_since` misuse.
3. no documented change cursor.
4. no stable provider occurrence ID for dates.
5. Event-level price overclaimed as Occurrence price.
6. provider page churn / incomplete reconcile false deletion.
7. PostgreSQL search relevance/performance not measured.
8. over-indexing.
9. untrusted provider content/URLs.
10. arbitrary stale/retry/ranking constants.

# 11. BLOCKERS

## B1 — KudaGo / MAX legal compatibility
**Status:** NEEDS LEGAL VERIFICATION / possible release blocker.

The licence wording is explicit, but this research cannot determine whether MAX rendering satisfies “open for indexing”.

## B2 — Provider runtime receipt
**Status:** NEEDS RUNTIME VERIFICATION.

No current live KudaGo payload/header evidence was successfully obtained here.

## B3 — Data-layer benchmark
**Status:** NEEDS RUNTIME VERIFICATION before any “production-performance” claim.

PostgreSQL capability is verified, not Povod-specific latency/relevance.

## B4 — Exact canonical-file audit
**Status:** research-integration blocker, not necessarily a product blocker.

Seven named source-of-truth files were not directly accessible in this chat.

# 12. OPEN QUESTIONS

See `GAPS_AND_OPEN_QUESTIONS.md`.

The most important are:
- legal link/indexing fit;
- provider runtime;
- rate limiting;
- occurrence edit patterns;
- strict-budget handling of unknown/conditional;
- retention;
- freshness thresholds;
- host extensions;
- benchmark acceptance SLO;
- Russian search relevance.

# 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`.

Minimum gate:
1. current KudaGo v1.4 receipt;
2. `actual_since` ongoing-event test;
3. complete pagination run;
4. target PostgreSQL/PostGIS version check;
5. feed/search/geo benchmark;
6. search relevance fixtures;
7. occurrence mutation/reconciliation tests;
8. price-parser golden fixtures;
9. source-link MAX evidence.

# 14. REQUIRED MANUAL / LEGAL CHECKS

## Manual
- MAX mobile/web concrete source-link rendering;
- UI wording for Event-level vs Occurrence-level price;
- UNKNOWN strict-budget behavior;
- stale/source-unavailable state;
- search relevance acceptance;
- one condition fingerprint versus two revision counters.

## Legal
- KudaGo direct-link/indexability clause in MAX;
- advertising-token clause;
- images/attribution where used;
- future commercial transfer/monetization;
- future Redis/search-engine licence choice if added.

This archive is technical research, not legal advice.

# 15. EXACT CHANGES FOR «ПОВОД»

Because the canonical files were not retrievable, these are **additive patch proposals**, not claimed applied diffs.

## Product Spec / Data Safety

Add invariants:
- incomplete provider sync cannot delete/withdraw data;
- source disappearance ≠ cancellation;
- date-only/unknown time never becomes midnight;
- blank price never becomes zero;
- Event-level price may not be presented as Occurrence-specific;
- stale beyond product threshold must be surfaced honestly;
- provider HTML/URLs are untrusted input.

Add enums:
- `ConstraintResult = PASS | FAIL | UNKNOWN`
- `PriceKind = EXACT | FROM | RANGE | FREE | CONDITIONAL | UNKNOWN`
- `PriceScope = EVENT | OCCURRENCE | UNKNOWN`
- `TimePrecision = EXACT | DATE_ONLY | UNKNOWN`

Occurrence additions:
- condition revision/fingerprint;
- last verified;
- source/provenance refs;
- source/raw timezone;
- normalized timezone if known;
- time precision.

Price additions:
- raw text;
- parse confidence/version;
- scope;
- fee/deposit states.

## KudaGo Provider Contract

Record:
- API version v1.4;
- pagination PAGE;
- max page size 100;
- `actual_since` = start-after UTC;
- `actual_until` = end-before UTC;
- documented update cursor = none found;
- documented rate limit = UNKNOWN;
- event-date occurrence IDs = not documented;
- price scope = EVENT by documented schema;
- preferred P0 text format = text;
- source URL retained;
- legal gate reference;
- sync mode = ROLLING_RECONCILE + FULL_SCOPED_RECONCILE.

## Data Gate / Receipt

Capture:
- PostgreSQL version;
- PostGIS version;
- extension availability;
- adapter/parser/schema/ranking versions;
- provider terms checked-at;
- runtime response receipt;
- quality metrics;
- benchmark results;
- source-link manual/legal result;
- unresolved gates.

## CONFLICT WITH CURRENT SOURCE OF TRUTH

**Found conflict only in the non-canonical test deck:** its MVP roadmap includes 2–3 cities, map, subscriptions and invite. The current explicit frozen P0 is narrower.

- **What conflicts:** roadmap scope.
- **Why:** test deck is lower-priority/non-canonical relative to current explicit freeze.
- **Criticality:** high if a developer uses the deck as implementation scope.
- **Recommendation:** do not change current P0.
- **Defer:** extra cities/map/subscriptions/social enhancements follow existing P1/stretch gates.

No data-pipeline recommendation in this report intentionally expands the current P0.

# 16. IMPACT ON P0 / P1 / STRETCH

## P0
Required:
- source mappings;
- safe reconcile/run completeness;
- Event/Occurrence distinction;
- price scope/UNKNOWN/raw text;
- provenance/source;
- PostgreSQL FTS/trgm/PostGIS baseline;
- quality/freshness fields;
- runtime/provider receipt;
- benchmark;
- legal source-link gate.

No new user-facing feature is introduced.

## P1
Possible after P0:
- follow-aware ranking;
- more advanced search tuning/synonyms;
- richer freshness automation;
- second provider + cross-provider dedup;
- caching if benchmark proves need.

## Stretch / Scale
Only with evidence:
- external search engine;
- Redis;
- partitioning raw history;
- more cities after data gate;
- complex recommendation learning.

# 17. WHAT NOT TO DO

- Do not treat KudaGo `actual_since` as update watermark.
- Do not use `publication_date` as update timestamp.
- Do not infer unlimited rate capacity.
- Do not cancel/delete after one missing run.
- Do not let a failed reconcile mark unseen data missing.
- Do not derive immutable occurrence ID only from time.
- Do not merge fuzzy titles automatically.
- Do not map UNKNOWN coordinates to Moscow center.
- Do not map unknown time to 00:00.
- Do not map blank price to free.
- Do not call Event-level price Occurrence-specific.
- Do not let ranking rescue hard FAIL.
- Do not shared-cache identity/preferences/personalized output.
- Do not freeze wide INCLUDE indexes without benchmark.
- Do not use PG19 beta / PostGIS RC.
- Do not add Redis/search engine/Kafka/LLM for scale theatre.
- Do not use the old test-deck roadmap to reopen P0.

# 18. SELF-CRITIQUE / RED TEAM

## “PostgreSQL only” could still be wrong
If representative feed + geo + FTS + typo + ranking produces unacceptable P95, CPU contention or poor relevance after sane tuning, an external engine may be justified.

**Response:** benchmark gate, not dogma.

## PostGIS could be unavailable
A managed host may not expose required extensions.

**Response:** verify host early; prefer a capable PostgreSQL host over an ad-hoc geo service unless hosting constraints are fixed.

## Reconciliation can still miss changes
A scoped window can miss edits to older/ongoing records.

**Response:** overlap/broad sweep, source detail refresh and runtime observation of actual mutation patterns.

## Price parser can give false confidence
Regex success does not prove the full payable cost.

**Response:** confidence + conditional/fee/deposit states + raw text + evidence scope.

## Condition revision can be overengineering
Two counters are probably unnecessary for hackathon P0.

**Response:** one condition fingerprint/revision is the simplest safe mechanism.

## Quality monitoring can become observability theatre
Dozens of metrics with no response path add work.

**Response:** P0 metrics protect truth: sync completeness, validation, UNKNOWN/drift, freshness.

## Search projection can drift
A denormalized projection can be stale.

**Response:** keep it inside PostgreSQL and update transactionally/deterministically; it remains derived, never source of truth.

## Exact retention can create legal/storage risk
Keeping raw provider content forever is not automatically safer.

**Response:** retention must be minimal/justified and legally reviewed.

## External engines are not “bad”
Meilisearch, Typesense, OpenSearch and Elasticsearch are active capable projects.

**Response:** they are deferred only because current P0 does not demonstrate a need that outweighs synchronization/ops cost.

## Redis “no” is conditional
At high repeated-read cost, cache may help.

**Response:** benchmark first; if added later, use a patched version, private network and explicit invalidation/tenant keys.

## Legal conclusion cannot be inferred from technical link behavior
A URL opening correctly is not the same as satisfying “open for indexing”.

**Response:** preserve evidence and route to legal/manual owner.

## Biggest weakness of this final verification
The canonical files themselves were not retrievable. The report can preserve rules supplied directly by the user but cannot prove there are no additional clauses in those files.

**Response:** synthesis/Codex must perform a direct line-level patch/diff when those files are available.

# 19. MISSING AREAS CHECK

## Areas that could have been forgotten and were additionally checked

- PG17 vs PG18 generated columns;
- covering-index limitations;
- partial-index parameter/planner behavior;
- JSONB raw-fidelity issue;
- materialized-view currentness;
- PostGIS release-candidate/security patch status;
- KudaGo `actual_since` exact wording;
- KudaGo price evidence scope;
- absence of KudaGo per-date IDs;
- KudaGo licence/indexability and ad-token clauses;
- current licences/maintenance of Redis/search alternatives;
- untrusted provider HTML/SSRF implications;
- keyset pagination;
- page-run completeness before absence inference;
- search relevance, not only speed.

## Still impossible to close here

- current KudaGo runtime;
- actual provider throttling;
- current cancellation/update patterns;
- legal interpretation in MAX;
- real DB benchmark;
- target host extension support;
- line-level canonical-file verification.

## Requires runtime
See section 13 and `RUNTIME_VERIFICATION_REQUIRED.md`.

## Requires human/manual
- SLO/freshness policy;
- strict-budget UNKNOWN UX;
- search relevance acceptance;
- retention horizon;
- source-link presentation.

## Requires legal
- KudaGo link/indexability;
- advertising-token handling;
- commercial/data-transfer implications.

## Requires Codex/host
- repo mapping;
- migrations;
- adapter;
- fixtures;
- live receipt;
- benchmark/EXPLAIN;
- evidence storage.

## Closed
- P0 should not gain Redis/search engine/Kafka/LLM.
- Event != Occurrence.
- no fake coordinate/time/price.
- PostgreSQL/PostGIS/FTS/trigram is the first implementation path.
- KudaGo is a reconciliation source, not a documented CDC source.
- price scope must not be overstated.
- exact numeric tuning values remain proposals until measured.

# 20. SOURCE MANIFEST

The complete machine-readable source list is in:
- `SOURCE_MANIFEST.csv`
- `SOURCE_MANIFEST.json`

Primary-source priority was used. No major conclusion depends on Reddit, SEO pages, random blogs or star counts.

GitHub repositories were checked for current activity/default branch/archived state/release/licence where relevant.

# 21. FINAL CHECKLIST

- [x] Major claims mapped to evidence/status.
- [x] Current PostgreSQL versions checked.
- [x] PG19 beta status checked.
- [x] PostGIS stable/RC status checked.
- [x] KudaGo official docs/licence checked.
- [x] Search/cache alternative repositories checked for activity/licence.
- [x] Runtime claims separated from documentation claims.
- [x] No live KudaGo behavior claimed as verified.
- [x] No benchmark result invented.
- [x] P0 not expanded by architecture research.
- [x] Non-canonical deck conflict with frozen P0 identified.
- [x] Redis/search-engine/Kafka/LLM options explicitly deferred/rejected.
- [x] Exact tuning numbers downgraded where unverified.
- [x] Source manifest completed.
- [x] Decision delta completed.
- [x] Runtime/manual/legal gaps completed.
- [x] Codex handoff completed.
- [x] Machine summary completed.
- [x] Archive contents tested after creation.

**Final status: FINAL WITH OPEN BLOCKERS.**
