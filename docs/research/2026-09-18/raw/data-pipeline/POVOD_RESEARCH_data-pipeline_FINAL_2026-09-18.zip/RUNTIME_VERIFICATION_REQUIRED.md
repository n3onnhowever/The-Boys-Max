# RUNTIME VERIFICATION REQUIRED

No item below is considered verified merely because documentation exists.

## Provider runtime receipt — KudaGo

**Status: NOT RUN successfully in this research chat.** A current v1.4 request was attempted through the available research web environment, but the API endpoint was not accessible through that tool.

Run from the actual host/Codex environment and save sanitized evidence:

1. `GET /public-api/v1.4/events/` for `location=msk`, small `page_size`, explicit fields and `expand=dates,place,location`.
2. Repeat with `page_size=100`.
3. Capture status, response time, response headers, count/next/previous and schema — no secrets/cookies.
4. Capture whether ETag, Last-Modified, Retry-After or rate-limit headers are actually present. Do not assume.
5. Test `text_format=text`.
6. Verify `site_url` behavior on MAX web/mobile surfaces.
7. Find a known ongoing/continuous event whose start is before “now”; compare broad request and `actual_since=now`.
8. Run two sequential complete page crawls to observe ordering/duplicate stability.
9. Observe a known updated event if possible: title/description-only edit, time change, venue change, price change, disappearance/cancellation. Save before/after payload hashes and normalized output.
10. Do **not** deliberately hammer the provider to discover a rate limit; only record naturally observed 429/Retry-After behavior.

## Target database / extension verification

Save:
- `SELECT version();`
- `SELECT current_setting('server_version');`
- `SELECT postgis_full_version();`
- installed extension versions;
- whether `pg_trgm`, `postgis`, `pg_stat_statements` can be enabled;
- managed-host restrictions.

## Query benchmark

Use representative real Moscow data first.

Required queries:
1. city + date/date-range feed;
2. city + date + category;
3. city + date + strict budget tri-state;
4. geo radius via `ST_DWithin`;
5. exact title;
6. participant/artist;
7. venue;
8. typo via trigram;
9. occurrence detail by ID;
10. keyset next page;
11. provider-page UPSERT/reconcile batch;
12. provenance/source lookup.

For hot queries save:
- SQL/query shape;
- `EXPLAIN (ANALYZE, BUFFERS)`;
- returned rows;
- p50/p95/p99 API latency under an agreed concurrency;
- DB CPU/load if available;
- index sizes;
- write/reconcile latency;
- plan before/after each candidate index.

## Search relevance verification

Create labelled fixtures before changing engines:
- exact title;
- artist name;
- venue name;
- typo;
- Cyrillic/Latin;
- `ё/е`;
- punctuation/quotes;
- abbreviations;
- ambiguous generic query.

“PostgreSQL supports FTS” is not proof that Povod relevance is good.

## Occurrence reconciliation tests

Fixtures:
- same date unchanged;
- exact time correction;
- small time shift;
- date changed to another day;
- venue changed;
- price changed;
- one date removed from multi-date event;
- one date added;
- complete event disappears;
- duplicated/reordered dates array;
- ambiguous two dates collapse into one.

Expected behavior must never silently map an ambiguous change to the wrong saved/social occurrence.

## Cache/ETag verification if implemented

- condition change invalidates old ETag/revision;
- user-specific endpoints are not shared-cached;
- stale event conditions are not served beyond the approved policy;
- metadata cache does not leak identity/preferences.

## Release evidence to retain

- timestamp;
- commit SHA;
- schema migration version;
- database/extension versions;
- adapter version;
- parser version;
- provider contract version;
- sanitized request/response samples;
- test output;
- benchmark report;
- EXPLAIN plans;
- source-link screenshots/manual result;
- unresolved failures.
