# DECISION DELTA — Previous Analysis → Final Verified Conclusion

| Area | PREVIOUS CONCLUSION | FINAL VERIFIED CONCLUSION | Why | Project impact |
|---|---|---|---|---|
| PostgreSQL sufficiency | PostgreSQL is sufficient for P0/v1. | **Recommended baseline, but Povod-specific sufficiency is NEEDS RUNTIME VERIFICATION.** | Capabilities are documented; no Povod benchmark was run. | Architecture stays simple without inventing a performance claim. |
| PostgreSQL version | 17.11 / 18.6. | **UNCHANGED AFTER VERIFICATION.** PG19 Beta 3 is rejected. | Official release + beta documentation. | Pin a supported stable patch. |
| Generated columns | Generic PG17+ recommendation. | PG17 supports stored generated columns; PG18 adds virtual generated columns/default behavior. | Version-specific docs. | Avoid silently depending on PG18-only behavior. |
| Hot covering index | Presented as an exact recommended index. | **Candidate only.** `INCLUDE` must be benchmarked on mutable occurrence rows. | Index-only scans depend on visibility-map state; wide payloads enlarge indexes. | Smaller safer initial index set. |
| Partial ACTIVE index | Treated as straightforward. | **Candidate only; actual ORM/query predicate must be checked.** | Planner must prove query predicate implies partial-index predicate. | Use `EXPLAIN` before migration freeze. |
| Raw payload | Raw JSONB was sufficient. | Parsed JSONB is useful, but exact raw evidence needs `raw_body` text/bytea/object + hash. | JSONB normalizes representation. | Better parser regression/debug/audit fidelity. |
| KudaGo `actual_since` | Activity/window filter. | Exact documented meaning is **started after** supplied UTC moment. | Official Events API. | Naive `actual_since=now` can omit already-started ongoing events. |
| KudaGo update cursor | No update cursor. | **UNCHANGED, with tighter wording:** no `updated_since`/change cursor is documented. | Primary docs review. | Rolling/broad reconciliation remains required. |
| KudaGo rate limit | Operationally bounded/unknown. | **UNKNOWN:** no published rate-limit contract found in reviewed docs. | Primary docs. | Start conservatively; observe natural 429/headers, do not infer “unlimited”. |
| KudaGo licence | Provenance/source mainly product/data rule. | **New legal gate:** direct specific source link must be open for indexing and not nofollow/noindex; advertising-token restriction exists. | Current open licence. | Manual/legal validation before release. |
| Price scope | Parser types only. | Add explicit `price_scope`; documented KudaGo price is Event-level while dates are separate. | Official schema. | Prevents overclaiming per-occurrence price truth. |
| Occurrence provider identity | Stable occurrence ID strategy was too absolute. | KudaGo dates have no documented ID; continuity is a conservative matching problem. | Expanded dates schema. | Ambiguous edit → new/superseded occurrence rather than unsafe merge. |
| Condition revision | `source_revision` + `condition_revision`. | For P0 a **single condition fingerprint/revision** may be enough; dual counters optional. | Red-team simplification. | Less schema/logic without losing safety. |
| Missing twice → withdrawn | Proposed as rule. | Exact `N=2` is **not evidence-backed**. | No deletion feed/runtime behavior proves it. | Keep MISSING/SUSPECT; calibrate policy. |
| Sync cadence | 30m / 4h / daily. | **PROPOSAL only; runtime/product SLO calibration required.** | No provider SLA/rate contract supports constants. | Removes false precision. |
| Stale thresholds | 2h / 12h / 48h examples. | **PROPOSAL only; configuration pending product SLO and observed provider behavior.** | No provider SLA/change-frequency measurement. | Honest stale handling stays; numbers not frozen. |
| Retry policy | 4 attempts, 500ms base, 30s cap. | Retry pattern verified; exact values are **configuration**. | RFC/AWS support pattern, not those numbers. | Keep bounded jittered retry, tune safely. |
| Ranking | Fixed sample weights. | **Exact weights rejected as unsupported precision.** | No labels/user calibration. | Simpler deterministic P0. |
| Cache | No Redis P0; example TTLs. | **No Redis P0 unchanged; exact TTLs become configuration/proposal.** | No cache benchmark; Redis adds service/licence/security surface. | Simpler runtime. |
| Search engine | No separate engine P0. | **UNCHANGED AFTER VERIFICATION**, but capability is not benchmark proof. | All alternatives add a second index; no measured blocker. | Benchmark gate before adoption. |
| PostGIS | Use PostGIS. | **UNCHANGED**, pin stable 3.6.x; reject 3.7.0rc2. | Current release notes. | Avoid pre-release/breaking changes. |
| Materialized views | Possible optimization. | **DEFER for live P0 truth.** | Data can be stale until refresh. | Prefer ordinary maintained relational/search projection. |
| Project deck roadmap | Could be read as MVP context. | **CONFLICT WITH CURRENT SOURCE OF TRUTH:** deck says 2–3 cities/map/subscriptions/invite; current P0 is narrower. | Current explicit project context is newer/higher priority. | Do not reopen scope from the deck. |

## UNCHANGED AFTER VERIFICATION

- Event != Occurrence.
- UNKNOWN is first-class.
- Conditional price remains conditional.
- Raw price text is retained.
- Fake coordinates are forbidden.
- Unknown time must not become fake midnight.
- Hard FAIL cannot be offset by recommendation score.
- Provenance/source is mandatory.
- Separate search engine is not justified for P0.
- Redis is not justified for P0.
- PostGIS is the preferred geo path if available on the target host.
- Cross-provider fuzzy auto-merge is deferred until a second provider and labelled validation exist.
