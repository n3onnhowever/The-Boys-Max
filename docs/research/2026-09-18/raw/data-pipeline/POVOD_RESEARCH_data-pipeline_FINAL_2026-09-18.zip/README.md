# POVOD Research Archive — Data Pipeline

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** Production-quality data pipeline  
**Research version:** FINAL-2026-09-18  
**Date:** 2026-09-18  
**Previous result:** production-quality data pipeline analysis in this research chat, 18.09.2026  
**Verification status:** **FINAL WITH OPEN BLOCKERS**

## Main verdict

For the frozen P0, keep **PostgreSQL as the single source of truth**, with **stable PostGIS** for geo and PostgreSQL **FTS + pg_trgm** for text retrieval. Do **not** add Redis, Kafka, a vector database, an LLM recommender, or a separate search engine without measured evidence.

The main correction to the previous result is epistemic rather than architectural: PostgreSQL capabilities are well-supported by official documentation, but **Povod-specific performance and relevance have not been benchmarked in this research chat**. Therefore hot covering/partial indexes, exact sync cadence, stale thresholds, cache TTLs, retry constants and ranking weights are configuration proposals—not verified production constants.

KudaGo's documented API has page pagination and `actual_since/actual_until`, but no documented change cursor. Its current open licence also creates an unresolved **legal/manual gate** around direct source links that must be open for indexing, plus advertising-material restrictions.

## What is inside

- `FINAL_REPORT.md` — complete verified research report.
- `EXECUTIVE_VERDICT.md` — short decision summary.
- `FACT_CHECK_MATRIX.csv` — major claims with type/status/evidence.
- `SOURCE_MANIFEST.csv` / `SOURCE_MANIFEST.json` — sources actually used.
- `DECISION_MATRIX.csv` — PostgreSQL / Redis / search-engine decision comparison.
- `DECISION_DELTA.md` — what changed from the previous analysis.
- `GAPS_AND_OPEN_QUESTIONS.md` — remaining unknowns.
- `RECOMMENDATIONS.md` — actionable Povod actions only.
- `RISKS.md` — P0/technical/security/legal/UX/operational risks.
- `RUNTIME_VERIFICATION_REQUIRED.md` — tests that require an actual host/provider/runtime.
- `CODEX_ACTIONS.md` — concrete coding-agent handoff.
- `CLAIMS_EVIDENCE.csv` — compact claim → evidence mapping.
- `machine_summary.json` — synthesis-friendly summary.
- `evidence/` — derived verification notes and checks, not copyrighted source dumps.

## Source-of-truth limitation

The seven named canonical project files were searched by exact name in File Library but were not retrievable in this research chat. This archive therefore does **not** claim a line-by-line diff against those files. It uses the frozen canonical rules supplied directly in this chat as the highest-priority project context, plus the available non-canonical `POVOD_TEST_DECK_V1.pptx` as corroborating material.

The test deck explicitly marks runtime/provider/measured results as unconfirmed and its pilot as `NOT RUN`. Its older roadmap contains 2–3 cities/map/subscriptions/invite in MVP and therefore conflicts with the current explicit P0 freeze. The current freeze wins.

## Final status

**FINAL WITH OPEN BLOCKERS**

Open blockers/gates:
1. KudaGo licence applicability for the MAX Mini App / bot linking/indexability pattern.
2. Current KudaGo runtime behavior has not been captured in this verification.
3. PostgreSQL search/feed/geo sufficiency has not been benchmarked on the real Povod runtime/dataset.
4. Exact line-level reconciliation with the named canonical project files remains unavailable until those files are directly accessible.
