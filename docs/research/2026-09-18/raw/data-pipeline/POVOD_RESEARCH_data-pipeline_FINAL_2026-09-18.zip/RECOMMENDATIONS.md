# RECOMMENDATIONS — Actionable Only

## P0 — KEEP

1. **PostgreSQL single source of truth.**
2. **Stable PostGIS 3.6.x** for nullable venue `geography(Point,4326)` and `ST_DWithin`.
3. **PostgreSQL FTS + GIN** for title/artist/venue/category retrieval.
4. **pg_trgm** for typo/fuzzy candidate retrieval if the host supports it.
5. Event and Occurrence separate; provider IDs remain source mappings, not canonical IDs.
6. UNKNOWN/conditional/no-fabrication invariants.
7. Source/provenance on every publishable Event/Occurrence.
8. Idempotent provider writes and a durable sync-run/checkpoint ledger.
9. Hard constraints evaluated before soft ranking.
10. Deterministic ordering and keyset pagination.

## P0 — CHANGE / ADD

### Ingestion

- Add `provider_sync_run` with `started_at`, `completed_at`, `status`, scope, counts and failure reason.
- Add durable checkpoint advancement only after successful page processing/commit.
- Mark incomplete runs; incomplete runs **must never** drive absence/deletion inference.
- For KudaGo use page pagination, conservative concurrency and rolling/broad reconciliation.
- Periodically run a complete reconciliation of the exact publish/display scope.
- Prefer `text_format=text` unless formatted provider HTML is genuinely required.

### Raw/source evidence

Persist:
- provider;
- entity type;
- provider object ID;
- request/source URL;
- fetched_at;
- sync_run_id;
- adapter/schema version;
- payload hash;
- parsed payload JSONB;
- optional retention-limited `raw_body` when exact representation is needed;
- observed HTTP metadata only when it actually exists.

### Identity

- Unique `event_source(provider_id, provider_event_id)`.
- Unique venue source mapping when provider venue ID exists.
- Do **not** invent a KudaGo provider occurrence ID.
- Reconcile date entries conservatively. Ambiguous mutation creates a new/superseding occurrence instead of unsafe reuse.
- Add one `condition_revision` or `condition_fingerprint` for user-relied fields: date/time/place/price/status. A single mechanism is enough for P0.

### Price

Add:
- `price_kind`: EXACT | FROM | RANGE | FREE | CONDITIONAL | UNKNOWN;
- `price_scope`: EVENT | OCCURRENCE | UNKNOWN;
- min/max minor units + currency;
- raw price text;
- parser version + confidence;
- deposit state/amount;
- service-fee state/amount if parsed.

Rules:
- blank + not-free/unknown → UNKNOWN;
- `is_free=true` with contradictory paid text → anomaly, not silent override;
- FROM/conditional/unknown fee cannot silently PASS a strict maximum budget;
- Event-level price must not be described as occurrence-specific.

### Time

Store:
- exact instant `timestamptz` only when exact;
- source local date/time;
- `time_precision` = EXACT | DATE_ONLY | UNKNOWN;
- raw provider timezone string;
- normalized IANA zone only when a controlled mapping is known.

Never create midnight to stand in for unknown time.

### Geo

- `position geography(Point,4326) NULL`;
- GiST index on known positions;
- no fallback coordinate to city center;
- if geocoding is later added, store geocoder provenance/confidence.

### Categories

- normalized `category`;
- `event_category`;
- `provider_category_map`;
- raw provider slug retained;
- monitor unmapped-category rate.

### Search

- PostgreSQL search projection bounded to title, participant/artist, venue and category text;
- GIN FTS;
- trigram fallback/candidate set;
- relational hard filters before personalized soft ordering;
- stable keyset cursor with explicit null/date-only semantics.

### Quality / freshness

Track per provider/run:
- fetched/new/changed/missing;
- page count/duration/error classes;
- schema validation failures;
- UNKNOWN rate by field;
- price-parser outcomes/version;
- coordinate/venue/time null rates;
- unmapped categories;
- source age and last verified.

Use baseline-relative alerts; do not freeze arbitrary percentages before observing data.

## P0 — BENCHMARK BEFORE FREEZE

Do not call these “exact recommended” until measured:
- hot occurrence composite index order;
- partial ACTIVE index;
- `INCLUDE` payload columns;
- retry attempt/base/cap values;
- sync cadence;
- stale thresholds;
- cache TTLs;
- ranking weights.

## DEFER

- Redis.
- Materialized views for live occurrence truth.
- Meilisearch.
- Typesense.
- Elasticsearch.
- OpenSearch.
- Cross-provider fuzzy auto-merge until a second provider exists.
- Event/Occurrence partitioning.
- ML/LLM ranking, dedup or parsing.
- Kafka/Redpanda/Temporal.

## REJECT FOR P0

- PostgreSQL 19 Beta 3.
- PostGIS 3.7.0rc2.
- Fake coordinates.
- Fake midnight.
- Empty price → zero/free.
- `publication_date` → update watermark.
- One missing run → cancellation.
- Hard-filter FAIL rescued by recommendation score.
- API + external search dual-write.
