# RISKS

## P0 risks

### R1 — KudaGo source-link legal ambiguity
**Status:** NEEDS LEGAL VERIFICATION

KudaGo requires a direct specific-material link that is open for indexing and not marked nofollow/noindex. Whether the MAX Mini App/bot presentation satisfies that exact requirement is not established here.

**Mitigation:** preserve `site_url`; show source visibly; manual/legal review in actual MAX surfaces; do not launch on an assumption.

### R2 — `actual_since` can create false coverage
**Status:** VERIFIED DOC SEMANTICS / NEEDS RUNTIME VERIFICATION

The official definition is “events that started after” the supplied moment, not “currently active/updated since”. A naive sync may omit long-running events that began earlier.

**Mitigation:** broad/overlap reconciliation; runtime fixture with an ongoing event.

### R3 — No documented provider update cursor
**Status:** VERIFIED BY OFFICIAL DOCS

No documented `updated_since`/change cursor exists for Events.

**Mitigation:** idempotent rolling + complete scoped reconciliation; no false CDC claim.

### R4 — Provider page churn
**Status:** INFERENCE

Page-based listings can change while a crawl runs. A run may see duplicates/skips if ordering/data changes.

**Mitigation:** provider IDs, idempotent writes, run completeness, duplicate tolerance, broad repeat reconciliation.

## Technical risks

### R5 — Over-indexing
Too many partial/covering indexes can inflate writes/storage and still fail to help parameterized queries.

**Mitigation:** start with uniqueness + FTS/trigram/GiST; add hot-feed index only after `EXPLAIN (ANALYZE, BUFFERS)`.

### R6 — Search relevance, not only latency
Russian proper names, aliases, Cyrillic/Latin and `ё/е` may make a technically fast query poor for users.

**Mitigation:** labelled fixtures and relevance assertions; only then consider synonyms/transliteration or a second engine.

### R7 — Ambiguous occurrence continuity
KudaGo dates do not expose per-date IDs.

**Mitigation:** conservative matching; never derive immutable identity solely from timestamp; ambiguous edit produces new/superseded occurrence.

### R8 — Raw representation loss
JSONB alone normalizes representation.

**Mitigation:** optional `raw_body` + hash when exact evidence/debugging is required.

### R9 — Extension availability
PostGIS/pg_trgm may be unavailable or restricted on the selected host.

**Mitigation:** verify host before schema freeze. Prefer a capable PostgreSQL host rather than inventing a second geo stack unless hosting is fixed.

## Security risks

### R10 — Provider content is untrusted input
Descriptions, URLs and image metadata are external input.

**Mitigation:** request KudaGo `text_format=text` for P0 where possible; parameterize SQL; escape output; never inject provider HTML unsanitized.

### R11 — Provider URL/image SSRF path
If the backend later proxies/fetches provider URLs/images, arbitrary fetch behavior can become SSRF.

**Mitigation:** do not server-fetch arbitrary provider URLs in P0; if proxying becomes required, enforce scheme/host/size/time limits and a separate downloader policy.

### R12 — Unbounded payloads/retry storms
Unexpected payload sizes and multi-layer retries can amplify outages.

**Mitigation:** response size/timeouts; bounded retry with jitter at one layer; provider-health metrics.

### R13 — Redis future exposure
Redis security guidance says it should not be exposed directly to the Internet.

**Mitigation:** Redis is deferred; if later used, patched version, private networking, auth/ACL and least privilege.

## Legal risks

### R14 — KudaGo advertising materials/tokens
The open licence restricts use of certain advertising-material tokens obtained without user participation.

**Mitigation:** provider/legal gate; exclude unknown advertising-marked content until representation/compliance is clear.

### R15 — Terms can change
KudaGo licence may change unilaterally.

**Mitigation:** record terms review date/reference in release readiness; recheck before production/public demo where provider data is used.

### R16 — Future commercial transfer
The current licence restricts commercial transfer of KudaGo materials to third parties.

**Mitigation:** legal review before monetization/B2B/data resale; not a P0 feature.

## UX / data-truth risks

### R17 — Event-level price shown as occurrence price
KudaGo Event price is free-form at event level.

**Mitigation:** `price_scope`; wording and filtering must not imply per-session certainty.

### R18 — UNKNOWN hidden by scoring
Unknown price/distance/time could appear as a perfect match if encoded as zero/default.

**Mitigation:** explicit PASS/FAIL/UNKNOWN hard-filter contract and warnings.

### R19 — Stale conditions hidden by cache
Long cache/SWR could display old price/time/place.

**Mitigation:** no long stale caching of condition truth; condition revision/ETag; source-unavailable UI.

## Operational risks

### R20 — False deletion from failed reconcile
A failed page/run can make many IDs appear “missing”.

**Mitigation:** only complete reconciliations may feed missing policy.

### R21 — Arbitrary freshness thresholds
Unmeasured thresholds can either hide useful data too early or leave bad data visible too long.

**Mitigation:** product SLO + observed provider behavior; keep thresholds configurable.

### R22 — Test-deck scope drift
The available deck contains older 2–3-city/map/subscription/invite MVP wording.

**Mitigation:** current P0 freeze wins; never use the deck roadmap to reopen scope.
