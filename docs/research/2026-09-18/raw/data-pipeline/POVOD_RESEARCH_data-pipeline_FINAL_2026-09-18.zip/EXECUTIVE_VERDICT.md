# EXECUTIVE VERDICT

## Verdict

Use **PostgreSQL 17.11 or 18.6** as the single system of record for P0. Add a **stable PostGIS 3.6.x** line for geo and use PostgreSQL **FTS + GIN** plus **pg_trgm** for name/artist/venue typo support.

Keep the data flow explicit:

`Provider raw → source mapping → Event → Occurrence → Venue → Price/UNKNOWN → provenance → quality/freshness`

For KudaGo, use **page-based rolling/broad reconciliation plus periodic complete scoped reconciliation**. Do not describe `actual_since` as an update watermark: the official API defines it as a filter for events that **started after** the supplied moment.

## Keep

- Event != Occurrence.
- UNKNOWN is first-class.
- Conditional price remains conditional.
- Raw price text is retained.
- No fake coordinates and no fake midnight.
- Hard constraints run before ranking.
- Provenance/source is mandatory.
- PostgreSQL remains source of truth.
- PostGIS handles radius search.
- Ranking stays deterministic/explainable.

## Change

- Add `price_scope = EVENT | OCCURRENCE | UNKNOWN`.
- If exact raw evidence is required, store `raw_body` separately from parsed `jsonb`.
- Treat KudaGo occurrence continuity as conservative reconciliation, not a guaranteed provider occurrence identity.
- Treat covering/partial hot indexes as benchmark candidates, not proven exact indexes.
- Make stale thresholds, retries, cache TTLs and ranking weights configuration pending evidence.
- Prefer `text_format=text` from KudaGo for P0 unless formatted provider HTML is actually required.

## Do not recommend for P0

- Redis.
- Meilisearch / Typesense / Elasticsearch / OpenSearch.
- Kafka / Redpanda.
- Vector database / embeddings.
- LLM dedup/ranking/price parsing.
- Event/Occurrence partitioning.
- PostgreSQL 19 Beta 3.
- PostGIS 3.7.0rc2.

## Main blockers / gates

- **NEEDS LEGAL VERIFICATION:** KudaGo's direct-link “open for indexing” requirement inside MAX, plus advertising-token restrictions.
- **NEEDS RUNTIME VERIFICATION:** current KudaGo responses/pagination/edit/removal behavior.
- **NEEDS RUNTIME VERIFICATION:** PostgreSQL feed/search/geo latency and Russian search relevance on the real stack.
- **PROJECT ARTIFACT GAP:** seven canonical files were not directly retrievable for a line-level diff.

## Next actions

1. Codex implements the minimal reconciliation/raw/source-map/price-scope contract behind safe migrations.
2. Run one controlled KudaGo runtime receipt and store sanitized response/headers.
3. Run PostgreSQL `EXPLAIN (ANALYZE, BUFFERS)` + end-to-end benchmark on representative Moscow data.
4. Manually/legal-review KudaGo source-link implementation in MAX.
5. Only then freeze exact hot indexes, sync cadence and freshness thresholds.
