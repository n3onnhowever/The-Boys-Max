# CODEX ACTIONS — Data Pipeline Handoff

## Non-negotiable project rules — DO NOT CHANGE

- Event != Occurrence.
- UNKNOWN is first-class.
- Conditional price stays conditional.
- Raw price text is retained.
- Fake coordinates are forbidden.
- Unknown time is not midnight.
- Hard constraints cannot be compensated by recommendation score.
- Provenance/source is mandatory.
- P0 remains solo-first with Moscow as the real demo city.
- Social is optional continuation.
- Do not add a second search engine, Redis, Kafka, vector DB or LLM-based ranking/parsing for P0.

The actual repository paths were not available to this research pass. **First map these actions onto existing project conventions; do not invent a parallel architecture because filenames below are conceptual.**

## 1. Inspect before editing

Find:
- current ORM/schema/migration system;
- provider client/adapter code;
- Event/Occurrence/Venue/Price types;
- current search/feed queries;
- API contracts;
- provenance/source handling;
- deployment PostgreSQL version/extensions.

Produce a compact diff plan against existing code.

## 2. Schema/migration — minimal set

### Provider sync ledger
Create/extend `provider`, `provider_sync_run`, `provider_checkpoint` with:
- provider/run ID;
- scope/city/window;
- started/completed timestamps;
- status;
- pages/items fetched;
- new/changed/missing counts;
- failure class/message;
- `complete_reconciliation`;
- adapter/schema version.

Invariant: **incomplete/failed run cannot drive absence/deletion inference.**

### Raw/source layer
Create/extend:
- `provider_raw_object_version`;
- `event_source`;
- `venue_source`;
- occurrence source/reconcile mapping that supports providers both with and without occurrence IDs.

Raw source record:
- provider;
- entity type;
- provider object ID;
- fetched_at;
- sync_run_id;
- source/request URL;
- payload_hash;
- parsed JSONB;
- optional `raw_body` if exact representation is retained;
- adapter/schema version;
- only HTTP metadata actually observed.

### Domain additions
Add only if absent:
- time precision;
- source/raw timezone;
- normalized timezone if controlled;
- price kind;
- price scope;
- raw price text;
- parser version/confidence;
- deposit/service-fee states as needed;
- `last_seen_at` / `last_verified_at`;
- one `condition_revision` or `condition_fingerprint`;
- provenance/source reference.

Do not add both source revision and condition revision unless existing logic clearly needs both.

## 3. ProviderAdapter

Conceptual capability contract:

```ts
type PaginationMode = "PAGE" | "CURSOR" | "NONE";
type SyncMode = "INCREMENTAL" | "ROLLING_RECONCILE" | "FULL_RECONCILE";

interface ProviderCapabilities {
  paginationMode: PaginationMode;
  maxDocumentedPageSize?: number;
  supportsUpdatedSince: boolean;
  supportsDeletionFeed: boolean;
  supportsOccurrenceIds: boolean;
  documentedRateLimit?: unknown;
}

interface ProviderPage<T> {
  items: T[];
  nextPage?: number;
  nextCursor?: string;
  complete: boolean;
  requestUrl: string;
  fetchedAt: string;
  observedHeaders?: Record<string, string>;
}
```

KudaGo capability fixture:
- pagination = PAGE;
- max documented page size = 100;
- documented updated-since = false;
- documented rate limit = UNKNOWN;
- event-date occurrence ID = not documented;
- preferred P0 text format = text;
- sync = rolling/broad reconcile + complete scoped reconcile.

Adapter must not perform canonical fuzzy cross-provider merge.

## 4. KudaGo runtime spike before cadence is frozen

Write a one-shot non-destructive spike:
- current v1.4 Moscow event fetch;
- explicit fields;
- expand dates/place/location;
- small page + page_size=100;
- `text_format=text`;
- sanitized headers/payload fixture;
- no high concurrency or deliberate rate-limit probing.

If live payload disagrees with docs: preserve response, flag contract mismatch, do not silently code around it.

## 5. Reconciliation — tests first

Rules:
- provider event ID maps to canonical Event source mapping;
- KudaGo dates do not get an invented provider occurrence ID;
- page write is idempotent;
- checkpoint advances only after durable processing;
- failed/incomplete run never marks unseen objects missing;
- one missing complete run does not mean CANCELLED;
- explicit cancellation only if provider evidence is known;
- ambiguous date mutation => new/superseded occurrence rather than unsafe continuity.

Keep occurrence candidate matching small, deterministic and high-precision-biased.

## 6. Price parser

Golden fixtures:
- `1500 ₽`
- `1 500 руб.`
- `от 1500`
- `1500–2500 ₽`
- `вход свободный`
- `бесплатно`
- `бесплатно по регистрации`
- `депозит 3000 ₽`
- `2000 ₽ + сервисный сбор`
- `цена уточняется`
- blank string
- malformed values
- contradictory `is_free=true` + paid text

Output:
- kind;
- scope;
- min/max;
- currency;
- raw text;
- confidence;
- deposit/service-fee state;
- anomaly flags.

Never use an LLM in the P0 parser.

## 7. Hard constraints

Implement one tri-state: `PASS | FAIL | UNKNOWN`.

Tests:
- FAIL always excluded;
- UNKNOWN never becomes PASS because score is high;
- strict max-budget with FROM / unknown fee / ambiguous price scope follows explicit product policy;
- missing coordinates under hard radius become UNKNOWN, never distance=0.

## 8. Search / geo

Check/enable `postgis` and `pg_trgm`.

Strong baseline indexes:

```sql
CREATE UNIQUE INDEX ... ON event_source(provider_id, provider_event_id);
CREATE UNIQUE INDEX ... ON event_category(event_id, category_id);
CREATE INDEX ... ON event_category(category_id, event_id);
CREATE INDEX ... USING GIN(search_vector);
CREATE INDEX ... USING GIN(search_text_normalized gin_trgm_ops);
CREATE INDEX ... USING GIST(position) WHERE position IS NOT NULL;
```

Do **not** blindly add the earlier wide `INCLUDE` occurrence index. Put hot-feed indexes in a benchmark/spike branch first and inspect the actual ORM SQL/query plan.

Use keyset pagination rather than large OFFSET pagination for the product feed.

## 9. Quality / observability

Emit provider-run metrics:
- fetched/new/changed/missing;
- page count;
- duration;
- HTTP status/error class;
- validation failures;
- UNKNOWN price/time/geo rate;
- parser outcome distribution;
- unmapped categories;
- source age;
- incomplete run count.

Alert thresholds must be config/baseline-driven, not hardcoded from earlier research examples.

## 10. Benchmark suite

Add a reproducible command/script for:
- feed;
- category;
- budget;
- geo;
- exact text;
- participant/venue;
- typo;
- detail;
- next page;
- sync UPSERT.

Persist:
- dataset seed/version;
- SQL;
- `EXPLAIN (ANALYZE, BUFFERS)`;
- latency summary;
- index size;
- DB/extension versions.

The team defines acceptance targets before interpreting results.

## 11. Evidence for MAX/KudaGo legal gate

Do not make legal conclusions in code. Prepare evidence:
- exact KudaGo `site_url` shown on occurrence/detail;
- tap opens concrete source;
- screenshots in MAX web/mobile where available;
- link rendering/indexability facts for manual/legal reviewer;
- advertising-marked/tokenized-content handling result.

## 12. Do not implement now

- Redis;
- Meilisearch;
- Typesense;
- Elasticsearch;
- OpenSearch;
- Kafka/Redpanda;
- vector DB;
- embeddings/LLM recommendation;
- LLM price parser/dedup;
- Event/Occurrence partitioning;
- materialized-view live truth;
- PostgreSQL 19 beta;
- PostGIS 3.7 RC;
- second city solely for architecture validation.

## 13. Definition of done

- migrations pass;
- idempotent adapter tests pass;
- price golden fixtures pass;
- hard-constraint tri-state tests pass;
- occurrence reconciliation mutation fixtures pass;
- live KudaGo receipt saved;
- database/version receipt saved;
- representative benchmark saved;
- no P0 scope expansion;
- legal/manual KudaGo link gate explicitly recorded as approved or unresolved.
