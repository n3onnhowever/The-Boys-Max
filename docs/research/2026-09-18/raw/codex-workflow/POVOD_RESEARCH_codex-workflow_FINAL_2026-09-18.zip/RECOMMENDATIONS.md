# ACTIONABLE RECOMMENDATIONS FOR «ПОВОД»

## 1. Keep the repository-native hierarchy simple

Persistent context order:

1. system/developer/user request;
2. applicable `AGENTS.md` chain;
3. current ticket;
4. changed code + nearest tests;
5. only the canonical domain docs needed for this ticket;
6. invoked Skill references/scripts;
7. external docs only when a version-specific uncertainty remains.

Never bulk-load old decks, research archives or all `/docs`.

## 2. Root `AGENTS.md`: durable rules only

Keep it concise and practical. Include:

- mission: implement frozen hackathon MVP, do not redesign product;
- source hierarchy and “current ticket + canonical contracts outrank decks/research”;
- frozen P0 / solo-first rule;
- `Event != Occurrence`;
- `UNKNOWN` is first-class; no fabricated date/time/place/price/coords;
- provenance/source survives ingestion/transforms/UI;
- MAX identity is validated server-side;
- minimal-diff/no opportunistic-refactor rule;
- deterministic verification and runtime-claim rules;
- 2–3 high-value `## Code Review Rules` for domain invariants;
- handoff/evidence requirement for substantial work.

Do **not** put tutorials, all project history, a library manual, duplicated Product Spec, or long task procedures there.

## 3. Stage custom Skills instead of installing a catalogue

### Phase 1

- `scope-guard`
- `test-and-verify`
- `runtime-evidence`

### Phase 2, after trigger smoke

- `data-safety`
- `provider-adapter`
- `max-integration`

Each Skill should own one repeatable job, use progressive disclosure, and avoid generic framework advice.

## 4. Custom Skill contract

Each Skill must define:

- exact trigger and negative trigger;
- minimal files/contracts it reads;
- commands discovered from the real repository rather than invented;
- Definition of Done;
- explicit “must not” section;
- evidence shape;
- optional references/scripts only where deterministic automation adds value.

Use `policy.allow_implicit_invocation: false` for any Skill that is risky or too easy to trigger broadly.

## 5. One writer; review independently

For normal tickets:

- one implementation agent owns writes;
- use `/review` before adding a custom reviewer agent;
- optional read-only explorer only for unclear impact radius;
- avoid concurrent writers unless ownership is demonstrably disjoint.

Do not claim this saves tokens: subagents use extra tokens. The reason is independent review/parallel investigation, not context magic.

## 6. Config posture

After host smoke, project config can use:

```toml
approval_policy = "on-request"
sandbox_mode = "workspace-write"

[sandbox_workspace_write]
network_access = false
```

Do **not** set a model in repo config by default.  
Do **not** enable `danger-full-access`/`--yolo` as normal workflow.  
Treat `allow_login_shell = false` as optional hardening after compatibility testing.

Read-only review/exploration should use `sandbox_mode = "read-only"`; inherit `on-request` unless a deliberately noninteractive job needs `never`.

## 7. Browser/runtime evidence

Prefer, in order:

1. existing Playwright Test suite;
2. Playwright CLI using the project's existing browser package/version;
3. add the official `playwright-cli` Skill only if it improves repeated use;
4. Playwright MCP only for genuinely stateful/exploratory debugging.

Do not globally install a second Playwright stack before checking the repo.

## 8. External Skills security

For every third-party Skill:

1. inspect licence;
2. `gh skill preview` if available;
3. inspect full tree, scripts, hooks, install commands, env/secrets, network/MCP dependencies;
4. pin exact commit SHA;
5. project-local install;
6. no silent update-all;
7. trigger smoke;
8. remove if value is not measurable.

## 9. ExecPlans

Do not require an ExecPlan for every ticket.

Create one only when work is truly multi-step/multi-file/long enough that a future agent must resume from the plan alone. Prefer extending the current task document rather than adding a parallel roadmap unless repeated use proves `PLANS.md` worthwhile.

## 10. Reusable prompts

Do not build the workflow around `~/.codex/prompts` or project `.codex/prompts`.

Reusable repository behavior belongs in:

- `AGENTS.md` for always-on invariants;
- Skills for detailed task procedures;
- ticket templates for task-local scope;
- `PROMPTS.md` only if humans want copy/paste examples.

## 11. Handoffs

Use a durable handoff for substantial/multi-session tasks, not every typo.

Minimum fields:

- `Status: VERIFIED | PARTIAL | BLOCKED`;
- base SHA / HEAD;
- exact scope completed;
- commands + exit results + what each proves;
- runtime environment/artifacts where required;
- changed files/contracts;
- not verified;
- residual risks;
- exact next action.

Automate fact collection, never automate the word `VERIFIED`.

## 12. CI

First make local verification deterministic. Then wrap the exact same commands in CI.

Recommended lanes once the repo is inspected:

- quality: locked install + lint + typecheck + unit/integration + build;
- domain-contracts: Event/Occurrence, UNKNOWN, provenance, price/location, hard constraints, MAX identity/session tests;
- one bounded P0 browser smoke;
- secret/dependency scan using existing native tooling first;
- live-provider smoke manual/scheduled, not a flaky mandatory PR gate;
- optional Codex review after GitHub/Codex Cloud is actually configured.

## 13. Version discipline

At start of each implementation day or after tool updates, record `codex --version`. During the final demo window, keep a known-working version stable unless an upgrade fixes a blocking/security issue and passes the full smoke.
