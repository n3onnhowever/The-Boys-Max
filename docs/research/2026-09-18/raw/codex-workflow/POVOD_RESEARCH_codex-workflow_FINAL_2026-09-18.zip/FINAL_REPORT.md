# FINAL REPORT — Agentic coding / Codex workflow for «Повод»

**Project:** «Повод»  
**Team:** The Boys  
**Research version:** `FINAL-2026-09-18`  
**Previous result:** agentic coding / Codex workflow analysis from this research chat, 18.09.2026  
**Verification status:** **FINAL WITH OPEN BLOCKERS**

> This is a verification and packaging pass over the existing research, not a product redesign. It preserves the frozen P0 and uses the project context supplied in this research request as authoritative in this environment. Direct byte-level copies of the four named canonical repository files and the actual `The-Boys-Max` working tree were not available here; that limitation is carried as an explicit blocker rather than filled with assumptions.

---

# 1. EXECUTIVE SUMMARY

The previous direction is substantially correct and survives verification, but the safest 2026 setup for «Повод» is **smaller** than the first recommendation.

The recommended operating model is:

```text
ticket
→ native repository context
→ short bounded plan
→ one implementation writer
→ targeted tests
→ deterministic lint/typecheck/build gates
→ runtime evidence only where the claim requires runtime
→ independent read-only review
→ git diff review
→ commit
→ compact evidence-backed handoff
```

The durable always-on layer should be a concise root `AGENTS.md`. Repeated procedures should move into a small repository-local Skill set using progressive disclosure. Start with only three Skills (`scope-guard`, `test-and-verify`, `runtime-evidence`), verify their triggers, and only then add the three Povod-domain Skills (`data-safety`, `provider-adapter`, `max-integration`). This is a project recommendation, not an OpenAI-prescribed magic number. OpenAI's current Skill mechanism exposes metadata first and loads the full `SKILL.md` only when invoked; the initial Skill discovery list itself has a bounded context budget. [S04]

The strongest correction to the first pass is that **subagents are not a token-saving mechanism**. Current OpenAI documentation explicitly notes that subagent workflows can consume more tokens than comparable single-agent runs. Use them only when independence, parallel read-heavy investigation, or a fresh review perspective earns that cost. [S05]

The second major correction is to remove unnecessary lifecycle machinery from the initial rollout: no mandatory hooks, no legacy custom-prompt dependency, no always-on MCP servers, and no WSL migration. Hooks, MCP and remote documentation tools remain useful optional capabilities, but each creates additional execution, permission, network or context surface. [S06][S09][S17][S18]

For browser evidence, the current Microsoft Playwright Test/CLI stack is the strongest fit if the repository already uses it. Microsoft now maintains both `microsoft/playwright` and a separate `microsoft/playwright-cli`; the CLI is explicitly oriented to coding-agent automation and is positioned as more token-efficient than the MCP variant for routine coding-agent browser work. Playwright MCP remains a powerful exploratory option but is not a security boundary and should not be an always-on P0 dependency. [S26][S27][S28][S29]

No product-scope change follows from this research. The required solo-first flow, server-validated MAX identity, Event/Occurrence separation, honest `UNKNOWN`, source/provenance and optional save remain non-negotiable process guardrails for coding agents.

---

# 2. FINAL VERDICT

**Status: FINAL WITH OPEN BLOCKERS.**

## Adopt now

- A short root `AGENTS.md` containing only durable repository invariants, scope rules, verification/evidence rules and handoff expectations.
- One implementation writer by default.
- Built-in/local read-only code review before declaring substantial work verified.
- Three Phase-1 project Skills: `scope-guard`, `test-and-verify`, `runtime-evidence`.
- Three Phase-2 domain Skills only after trigger evaluation: `data-safety`, `provider-adapter`, `max-integration`.
- Deterministic verification before LLM review.
- Existing Playwright Test/CLI where runtime/browser evidence is required.
- Default implementation posture equivalent to `approval_policy = "on-request"`, `sandbox_mode = "workspace-write"`, outbound network disabled, **only after host compatibility smoke**. [S07][S08]
- Compact handoff receipts for substantial/multi-session work, with exact commands, results, environment and unresolved risks.

## Do not adopt now

- Whole Skill marketplaces or catalogues.
- Multiple overlapping writer agents.
- Superpowers as the project framework.
- Serena as a new P0 navigation/editing layer.
- Docker Agent as an alternate coding-agent harness.
- Playwright MCP as an always-on browser layer.
- Context7 automatically for every code question.
- Project hooks before a measured lifecycle/compaction problem exists.
- Legacy `~/.codex/prompts` as a repository workflow contract.
- WSL migration during the hackathon if the current Windows host already runs the project.
- `danger-full-access` / `--yolo` as the normal mode.

## Main blocker

The repository itself was not available in this research environment. Therefore the exact current `AGENTS.md`, package manager, commands, test stack, current Playwright setup, CI, `.codex` state, installed Codex version and the byte-level contents of the four canonical product files remain **NEEDS HOST VERIFICATION**.

---

# 3. WHAT WAS VERIFIED

The final pass rechecked the following areas against current primary sources as of 18.09.2026:

- OpenAI Codex `AGENTS.md` hierarchy and instruction limits. [S03]
- Current Agent Skills discovery/progressive-disclosure behavior and repository-local placement. [S04]
- Current custom subagent configuration and token-cost caveat. [S05]
- Project config trust behavior, sandbox/approval/network posture and optional shell hardening. [S06][S07][S08]
- Current Codex hooks model and its context/execution implications. [S09]
- Local/GitHub Codex code review model and the role of `## Code Review Rules`. [S10][S11]
- OpenAI guidance on reducing over-scaffolding/oversized Skills and prompts. [S12]
- ExecPlan/`PLANS.md` status as an optional convention for long-running work. [S13][S14]
- Current stable `openai/codex` release state at verification end: 0.155.1, with 0.155.0 security/reliability notes also reviewed. [S15][S16]
- Current limitations/regressions around legacy custom prompts. [S17][S18]
- GitHub's current Agent Skill installation/security guidance. [S19]
- Exact current metadata/activity/licensing of the requested GitHub collections and tools. [S20-S42]
- Current Playwright CLI/MCP state and agent Skill. [S26-S29]
- Current Serena licensing and the patched status of the two previously cited advisories. [S34-S36]
- Current larger reference collections including Trail of Bits and GitHub Awesome Copilot. [S38][S39]
- The supplied project context and a noncanonical Povod presentation artifact for detecting stale scope language. [S01][S02]

**Not verified by runtime:** the Povod application, MAX runtime, Codex execution on the user host, browser flow, provider calls, Skill trigger behavior, CI, or any actual repository command.

---

# 4. CURRENT STATE AS OF 18.09.2026

## Codex platform state

**FACT — VERIFIED BY OFFICIAL DOCS:** Codex supports hierarchical project instructions through `AGENTS.md`; closer directory instructions take precedence. The documented default combined project instruction ceiling is 32 KiB. This is a ceiling, not a recommended target size. [S03]

**FACT — VERIFIED BY OFFICIAL DOCS:** repository-local Skills under `.agents/skills` and custom subagents under `.codex/agents` are supported primitives. Skill content follows progressive disclosure rather than loading every Skill body eagerly. [S04][S05]

**FACT — VERIFIED BY OFFICIAL DOCS:** project `.codex/config.toml` and project MCP configuration require a trusted project context. [S06][S07]

**FACT — VERIFIED BY OFFICIAL DOCS:** `workspace-write` supports a network-off posture and `on-request` approvals; a read-only sandbox is suitable for reviewers/explorers. Disabling sandbox/approvals through `--yolo` is not the recommended normal posture. [S07][S08]

**FACT — VERIFIED BY OFFICIAL DOCS:** subagent workflows consume additional tokens. Custom agents can still be valuable for isolation and parallelism, but there is no basis for claiming they are intrinsically cheaper. [S05]

**FACT — VERIFIED BY OFFICIAL SOURCES:** at the end of this verification, the latest non-prerelease GitHub release visible for `openai/codex` was `0.155.1`, published 18.09.2026 20:03 UTC. `0.155.0` had landed the previous day and included WSL sandbox hardening, credential handling and compaction/recovery fixes. [S15][S16]

## Skills ecosystem state

The ecosystem is now large enough that catalogue size itself is a risk signal for a small P0 project. The following counts are repository-tree measurements taken during this verification; they describe **source surface**, not content automatically injected into a Codex context:

| Repository | Current tree `SKILL.md` blobs | Total Skill bytes | Median Skill bytes | Interpretation |
|---|---:|---:|---:|---|
| `microsoft/skills` | 201 | 1,959,894 | 8,993 | Very broad; Microsoft itself says to select Skills narrowly. |
| `scarletkc/agents` | 11 | 86,167 | 6,323 | Small reference set; some useful process patterns. |
| `gohypergiant/agent-skills` | 32 | 726,060 | 19,560 | Strong procedures but broad for this P0. |
| `ever-just/agentskills` | 173 | 1,986,596 | 8,576 | Large procedural library; reference-only by default. |
| `GitGuardian/agent-skills` | 12 | 167,696 | 17,446 | Security-specific; only `scan-secrets` is plausibly relevant now. |
| `trailofbits/skills` | 92 | 1,090,136 | 11,363 | Strong security/testing reference, large privileged tool surface. |
| `github/awesome-copilot` | 436 | 3,902,494 | 6,668 | Excellent discovery catalogue, absolutely not a Povod bundle. |
| `obra/superpowers` | 14 | 138,578 | 7,053 | Full process methodology, not a lightweight Povod addition. |

Codex does **not** load all those bodies at once when using a normal Skill mechanism; however, discovery metadata still has a bounded context budget, and every installed Skill adds routing/maintenance/supply-chain responsibility. [S04]

## Project state known in this research environment

The current supplied canonical context says P0 remains frozen and solo-first. The mandatory path is MAX → validated MAX identity → interests/constraints → live events → specific Occurrence → date/time/place → price or honest UNKNOWN → source/provenance → source link → optional save. [S01]

A presentation artifact from 17.09 contains broader/older presentation language (including multi-city/map framing) and is therefore treated as **secondary, noncanonical evidence only**. It must never override the current scope freeze. [S02]

---

# 5. KEY FINDINGS

## KF-1 — Use native primitives before adding frameworks

**FACT:** Codex already supplies the core primitives required for the proposed workflow: repository instructions, Skills, custom agents/subagents, sandbox/approval configuration and code review. [S03-S11]

**INFERENCE:** introducing another agent framework into a two-week hackathon adds more coordination, configuration and failure modes than it removes.

**RECOMMENDATION:** build the Povod workflow with native Codex primitives plus existing repository tools. External projects should be references or narrowly vendored capabilities, not a new control plane.

## KF-2 — Short `AGENTS.md` + progressive disclosure is the right context architecture

**FACT:** `AGENTS.md` is always-on repository instruction context; Skills are loaded progressively. [S03][S04]

**INFERENCE:** stable invariants belong in `AGENTS.md`; procedure detail belongs in Skills/runbooks; historical explanations belong in ordinary docs.

**RECOMMENDATION:** target a root `AGENTS.md` that is compact enough to read quickly and reason over—roughly 4–8 KiB is a project target, **not** a platform requirement. Do not approach the 32 KiB documented ceiling merely because it exists.

## KF-3 — One writer is the safe default

**FACT:** subagent orchestration increases token use; custom agents are useful for specialized tasks. [S05]

**INFERENCE:** shared-file parallel writing has a high coordination cost in a small, fast-moving P0.

**RECOMMENDATION:** one writer; optional read-only explorer for uncertain impact radius; fresh read-only reviewer for substantial diffs. Parallel implementation writers only when the surfaces are truly independent and ownership is explicit.

## KF-4 — Verification must distinguish static, deterministic and runtime evidence

**FACT:** build/test/lint results establish only what those checks actually execute. Browser/MAX/provider behavior is a different evidence class.

**RECOMMENDATION:** every completion receipt should state both the command/result and **what the evidence proves**. If a runtime was not executed, say `NOT RUN` / `NEEDS RUNTIME VERIFICATION`; never upgrade source inspection to a runtime claim.

## KF-5 — Playwright Test/CLI is the strongest browser evidence path, conditional on the repo

**FACT:** Playwright is active, Apache-2.0, and its current CLI is explicitly designed for coding-agent browser automation. Microsoft maintains a dedicated CLI repo and an agent Skill. [S26][S27][S28]

**FACT:** Playwright MCP is also active but its own documentation states it is not a security boundary. [S29]

**RECOMMENDATION:** detect the existing browser/e2e stack first. If Playwright already exists, reuse it. Prefer Test/CLI for bounded evidence. Add the agent Skill only if it meaningfully improves agent operation. Add MCP only for a proven stateful exploratory need.

## KF-6 — External Skills are code/supply-chain inputs, not prompt snippets

**FACT:** GitHub's current Agent Skills guidance warns that third-party Skills are not verified by GitHub and can contain hidden instructions/scripts; preview and pinned references are supported. [S19]

**RECOMMENDATION:** inspect exact Skill tree/content/scripts/hooks/network/env access and license, pin an immutable upstream SHA, install project-local, then run trigger smoke. No wholesale marketplaces.

## KF-7 — Handoff should be durable facts, not prompt history

**INFERENCE:** chat history and compaction are poor durable sources of project truth; source-controlled task/handoff/evidence files are inspectable and diffable.

**RECOMMENDATION:** hand off only the state needed to resume: base/HEAD, exact scope, changed files, checks, runtime evidence, contracts touched, unknowns/risks, and one next action. Do not archive chain-of-thought or raw prompt transcripts as canonical documentation.

---

# 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

The detailed delta is in `DECISION_DELTA.md`. Material changes are:

1. **Subagents:** previous wording allowed a token/speed interpretation. Final: use for independence/wall-clock quality only; they consume more aggregate tokens. [S05]
2. **Skill rollout:** keep the six-domain shape but install/project-author three first, evaluate triggers, then add three.
3. **Hooks:** remove from initial rollout. A SessionStart hook that repeats native context is not justified until a real resume/compaction failure is observed. [S03][S09]
4. **Reusable prompts:** do not make legacy custom prompts a project dependency. Current Skills/task files are more durable; `~/.codex/prompts` had 2026 regressions and project-scoped prompts were not planned. [S04][S17][S18]
5. **ExecPlan:** keep only for genuinely substantial work. It is an optional convention, not a universal repository ceremony; Codex also has a system Exec Plan Skill now. [S04][S13][S14]
6. **Reviewer approval:** read-only does not imply `approval_policy = "never"`. Use normal `on-request` for human-interactive review unless intentionally noninteractive.
7. **`allow_login_shell=false`:** downgrade from baseline recommendation to optional hardening after command compatibility smoke.
8. **WSL:** reject migration during hackathon unless the existing environment is blocking work.
9. **Playwright CLI:** separate official `microsoft/playwright-cli` repository confirmed; prior uncertainty is resolved. [S27]
10. **Serena security statement:** current v1.7.0 is patched for both cited advisories; the tool is still deferred for complexity/licensing/privilege reasons, not because those fixed CVEs remain open. [S34-S36]
11. **Additional references:** Trail of Bits and GitHub Awesome Copilot are stronger current catalogues for security/Skill hygiene patterns, but are still not installation recommendations. [S38][S39]
12. **Codex version discipline:** because stable releases are moving quickly, record the host version and avoid surprise auto-upgrades during the demo-critical window. [S15][S16]

---

# 7. CONFIRMED FACTS

The full claim/evidence set is in `FACT_CHECK_MATRIX.csv` and `CLAIMS_EVIDENCE.csv`. The key confirmed facts are:

- `AGENTS.md` hierarchy and documented combined limit: **VERIFIED BY OFFICIAL DOCS**. [S03]
- Skill progressive disclosure and discovery budget: **VERIFIED BY OFFICIAL DOCS**. [S04]
- `.agents/skills` and `.codex/agents` as native project locations: **VERIFIED BY OFFICIAL DOCS**. [S04][S05]
- Subagent token cost caveat: **VERIFIED BY OFFICIAL DOCS**. [S05]
- Project config/MCP trusted-project condition: **VERIFIED BY OFFICIAL DOCS**. [S06][S07]
- Workspace-write/network/approval behavior: **VERIFIED BY OFFICIAL DOCS**. [S07][S08]
- Hooks as executable lifecycle extensions: **VERIFIED BY OFFICIAL DOCS**. [S09]
- ExecPlan as optional OpenAI convention for longer work: **VERIFIED BY OFFICIAL SOURCE**. [S13][S14]
- Current stable Codex release metadata: **VERIFIED BY OFFICIAL GITHUB RELEASE**. [S15]
- Current Playwright/CLI/MCP repository state: **VERIFIED BY OFFICIAL GITHUB SOURCES**. [S26-S29]
- Third-party Skill risk/pinning guidance: **VERIFIED BY OFFICIAL GITHUB DOCS**. [S19]
- Serena current licensing and patched status of cited advisories: **VERIFIED BY OFFICIAL REPO/ADVISORIES**. [S34-S36]
- Exact GitHub repo activity/license/default-branch/current-release metadata in the source manifest: **VERIFIED BY OFFICIAL GITHUB API/REPOSITORIES** on 18.09.2026.

No runtime behavior of «Повод», MAX, provider integrations or the user's Codex host is included in this confirmed-facts category.

---

# 8. RECOMMENDATIONS

## 8.1 Recommended Codex setup

Start with the smallest native layout:

```text
/
├─ AGENTS.md
├─ .agents/
│  └─ skills/
│     ├─ scope-guard/
│     ├─ test-and-verify/
│     └─ runtime-evidence/
├─ docs/
│  ├─ tasks/          # use existing location if already established
│  ├─ runbooks/       # only if equivalent docs do not already exist
│  └─ handoffs/       # only for substantial/multi-session work
└─ existing project files
```

Only after Phase-1 Skill triggers work correctly:

```text
.agents/skills/
├─ data-safety/
├─ provider-adapter/
└─ max-integration/
```

Only after a concrete repeated review/exploration need:

```text
.codex/agents/reviewer.toml
.codex/agents/explorer.toml
```

Do not create empty framework directories merely to match this diagram; preserve existing repository organization where it already solves the need.

## 8.2 Recommended `AGENTS.md` structure

The following is a structure, not a replacement to apply blindly before auditing the real file:

```md
# AGENTS.md

## Repository mission
- Implement the frozen hackathon MVP «Повод».
- Work from current repository contracts and the active ticket.
- Do not redesign the product unless the ticket explicitly authorizes it.

## Authority and scope
- P0 is frozen.
- Current canonical project contracts outrank old decks, archives and prompt history.
- Social behavior remains optional continuation; do not make it an entry requirement.
- Prefer the smallest diff satisfying the ticket.

## Non-negotiable domain invariants
- Event != Occurrence.
- UNKNOWN is a first-class state.
- Never invent price, time, place or coordinates.
- Preserve source/provenance through normalization and UI/API surfaces.
- MAX identity authority is server-side validation, not client assertion.
- Hard eligibility constraints must not be silently offset by recommendation score.

## Change discipline
- Read the active ticket and nearest code/tests before editing.
- No opportunistic refactors or future abstractions.
- No new provider/city/map/social/infrastructure/tooling layer outside ticket scope.
- Do not change unrelated files just to make checks pass.

## Verification and evidence
- Run affected tests first, then applicable repository gates.
- A build is not runtime evidence.
- Runtime claims require matching runtime observation.
- Record commands/results and what each result proves.
- If a required check cannot run, report PARTIAL/BLOCKED rather than VERIFIED.

## Review and handoff
- Review final diff for scope, domain semantics, security and missing tests.
- Substantial/multi-session work needs a compact evidence-backed handoff.

## Code Review Rules
- Flag scope expansion.
- Flag Event/Occurrence collapse or fabricated UNKNOWN values.
- Flag source/provenance loss.
- Flag client-trusted MAX identity.
- Flag runtime claims unsupported by runtime evidence.
```

### What must stay out of `AGENTS.md`

- full Product Spec content;
- project history/chat summaries;
- library tutorials;
- generated API docs;
- long command transcripts;
- temporary task detail;
- generic style rules already enforced by formatter/linter;
- instructions duplicated in task docs or Skills.

## 8.3 One-task workflow

```text
TICKET
  ↓
READ-ONLY PREFLIGHT
  ↓
SCOPE / INVARIANTS
  ↓
SHORT PLAN
  ↓
REPRODUCTION OR ACCEPTANCE TEST WHERE USEFUL
  ↓
IMPLEMENT (ONE WRITER)
  ↓
TARGETED TESTS
  ↓
LINT / TYPECHECK / BUILD AS APPLICABLE
  ↓
RUNTIME IF ACCEPTANCE REQUIRES RUNTIME
  ↓
SCREENSHOT / TRACE / LOG / RESPONSE RECEIPT AS NEEDED
  ↓
READ-ONLY SEMANTIC REVIEW
  ↓
GIT DIFF / DIFF-CHECK
  ↓
COMMIT
  ↓
HANDOFF IF SUBSTANTIAL OR MULTI-SESSION
```

The agent should not run the entire repository test universe after every small edit; use targeted feedback first, broader gates before completion.

---

# 9. REJECTED / DEFERRED OPTIONS

## REJECT for P0

### Wholesale `microsoft/skills`

**FACT:** MIT, active on 18.09.2026, ~175 published catalogue Skills and 201 `SKILL.md` blobs measured in the current tree. Microsoft explicitly advises selective use because loading too many Skills creates context rot. [S20]

**VERDICT:** reference or one exact audited Skill only.

### Wholesale `ever-just/agentskills`

**FACT:** MIT root repo, active on 18.09.2026, README advertises 168 published procedures while current tree measurement found 173 `SKILL.md` blobs. [S23]

**VERDICT:** reference-only by default. Individual imported content/dependencies still need their own review.

### Superpowers framework

**FACT:** MIT, current release v6.3.0; supports Codex and implements a broad process framework. [S30]

**INFERENCE:** its process/trigger ceremony competes with the already frozen Povod workflow and current OpenAI lean-scaffolding direction.

**VERDICT:** borrow TDD/debug/review concepts, do not adopt the framework for P0.

### Docker Agent

**FACT:** `docker/docker-agent` is active, Apache-2.0, release v1.141.0 dated 16.09.2026. It is a full alternate agent runtime with multi-agent/MCP/RAG capabilities, not a small “Docker Skill”. [S37]

**VERDICT:** reject for P0.

### Multiple overlapping writer agents

**FACT:** subagents cost extra tokens. [S05]

**INFERENCE:** shared-write coordination adds merge/rework risk.

**VERDICT:** one writer default.

## DEFER / ON DEMAND

### Playwright MCP

Powerful for exploratory stateful browser work, but larger permission/tool surface and explicitly not a security boundary. Use only after Test/CLI is insufficient. [S29]

### GitGuardian `scan-secrets`

High-quality narrow capability, MIT, release v0.6.2. But it requires `ggshield`, authentication/account/network for the complete workflow and can add hook surface. Check the repo's existing secret scanning first. [S24][S25]

### Serena

Current v1.7.0 patches the two cited High/Critical advisories. Its present rejection is **not** “Serena is currently vulnerable to those fixed bugs”; it is that a new GPL-3.0-or-later app + LSP/MCP/process layer is unnecessary P0 complexity and privilege surface. [S34-S36]

### Context7

Useful for current version-specific library docs, but remote/network dependency and additional context/tool surface are not justified until a real docs-version problem appears. [S33]

### Repomix

Useful for narrow external handoffs/snapshots. v1.18.0 added MCP sandbox/security hardening, reinforcing that broad filesystem/repository packing is itself a security/context decision. [S32]

### Trail of Bits Skills / GitHub Awesome Copilot

Excellent reference/discovery sources; too broad to install wholesale. Trail of Bits root licence is CC-BY-SA-4.0 and includes many executable security helpers; Awesome Copilot is a huge mixed-use catalogue. [S38][S39]

---

# 10. RISKS

## P0 / process risks

1. **Scope drift by a capable agent.** The agent may “clean up” adjacent code or add abstractions/providers/features outside P0. Mitigation: active ticket + scope guard + minimal diff + review.
2. **False completion claims.** Static inspection or green build may be described as runtime success. Mitigation: evidence taxonomy and environment-qualified receipts.
3. **Context debt.** Long `AGENTS.md`, broad Skills and chat history can dilute current task constraints. Mitigation: progressive disclosure and narrow source hierarchy.
4. **Agent orchestration overhead.** More agents can increase token cost and integration rework. Mitigation: one writer; subagents only for bounded independent work.

## Security risks

5. **Third-party Skill supply chain.** Skills can contain scripts, hooks, hidden instructions, network behavior or install logic. Mitigation: exact-tree audit, immutable pin, project-local install, least privilege. [S19]
6. **MCP/tool privilege expansion.** Browser/file/network tools expand attack and data-exfiltration surface. Mitigation: default-off; enable narrowly; treat external content as untrusted.
7. **Artifact leakage.** Browser traces/screenshots/logs can include tokens, PII or provider payloads. Mitigation: redact/review artifacts before commit/upload.
8. **Over-broad Codex permissions.** `danger-full-access`/`--yolo` eliminates important guardrails. Mitigation: on-request + appropriate sandbox. [S08]

## Operational risks

9. **Fast Codex release cadence.** A same-week upgrade can fix security issues or introduce workflow regressions. Mitigation: record version, smoke upgrade, keep a known-good pin during demo-critical period. [S15][S16]
10. **Environment migration risk.** Moving to WSL or replacing browser/tooling during hackathon can consume more time than it saves. Mitigation: keep a working host unless actually blocked.
11. **Handoff bureaucracy.** Excessive documents can slow P0. Mitigation: only substantial/multi-session tasks get durable handoff; small tasks can rely on ticket + commit/PR evidence.

## Legal/licence risks

12. **Vendoring third-party prose/scripts.** Root licence does not always describe every imported subdirectory. Mitigation: check exact Skill licence and attribution before copy/vendor.
13. **Trail of Bits content:** CC-BY-SA-4.0 implications require consideration before copying/adapting content into project-owned Skills. [S38]
14. **Serena:** GPL application licensing matters if redistributed/integrated, even though SolidLSP is MIT. [S34]
15. **Anthropic Skills:** mixed licensing means no blanket “repo is MIT/Apache” conclusion. [S40]

---

# 11. BLOCKERS

## B1 — Actual working tree unavailable

**STATUS:** BLOCKER FOR EXACT ROLLOUT, not for the general research conclusion.

Cannot verify:
- current `AGENTS.md` / overrides;
- package manager/lockfile;
- actual test/lint/typecheck/build scripts;
- existing Playwright/e2e stack;
- existing `.agents` / `.codex` / hooks / MCP configuration;
- CI workflows and current scanners;
- branch/HEAD/dirty state;
- Git remote/Codex Cloud availability.

**Required action:** Gate 0 in `CODEX_ACTIONS.md`.

## B2 — Direct byte-level canonical files unavailable

The research request names four canonical project files but this environment did not retrieve their direct copies. The supplied canonical context is authoritative for this report, but an exact file conflict audit remains host-required.

**Required action:** Codex must hash/read the four files before editing the agent harness. If they contradict this archive, report `CONFLICT WITH CURRENT SOURCE OF TRUTH` before changing anything.

## B3 — Runtime not executed

No claim that the proposed Codex config, Skill trigger, browser flow, MAX runtime, provider path or CI currently works in `The-Boys-Max` is made.

---

# 12. OPEN QUESTIONS

1. What repository instructions already exist, and which are stale/duplicated?
2. What is the current active ticket/branch/HEAD?
3. Which package manager and exact scripts are authoritative?
4. Does the repo already have Playwright or another sufficient browser-evidence stack?
5. Is secret scanning already provided by GitHub/CI/another tool?
6. Is a GitHub remote connected and is Codex Cloud review usable?
7. What Codex version is installed on the host, and is auto-update enabled?
8. Do any current commands rely on login-shell profile initialization?
9. Are there existing project hooks/MCP servers that should be removed or retained?
10. Does any current task actually require a subagent, or will built-in `/review` cover the need?
11. Is any remote MCP acceptable under the project's data-handling constraints?

---

# 13. REQUIRED RUNTIME TESTS

The following cannot be converted into `VERIFIED BY RUNTIME` without execution.

## RT-1 Codex host/config smoke

Record:
- OS/shell;
- `codex --version`;
- trust state;
- current config path/effective relevant settings;
- one harmless read/write/test cycle under the proposed sandbox/approval posture.

## RT-2 `AGENTS.md` scope smoke

Give the agent a deliberately tempting out-of-scope request embedded in a valid ticket context and verify it flags scope rather than silently expanding P0.

## RT-3 Skill trigger evaluation

For each project Skill run:
- positive trigger prompt;
- negative near-miss;
- ambiguous prompt.

Record which Skill was invoked. Narrow descriptions until routing is acceptable.

## RT-4 Deterministic repository gates

Execute the actual discovered:
- targeted tests;
- lint;
- typecheck;
- build;
- any contract checks.

Record exact commands/exit status. Do not copy generic commands from this report.

## RT-5 Browser evidence

Only for UI/browser acceptance criteria:
- run current app at exact HEAD;
- exercise the relevant flow;
- capture small screenshot/trace/log evidence;
- inspect console/network failure evidence where relevant;
- label the environment exactly (`local web`, `MAX web`, `MAX mobile`, etc.).

## RT-6 MAX-specific runtime

A local Chrome run is not MAX evidence. Any claim about MAX identity, bridge, startapp/deep-link or mobile/web MAX behavior requires the corresponding MAX environment/test harness.

## RT-7 Provider runtime

If provider ingestion changes, validate a real provider response separately from fixtures/mocks. Record source, timestamp and error behavior. Do not make live-provider availability a flaky mandatory PR gate unless reliability is proven.

## RT-8 Reviewer behavior

Run built-in `/review` on a representative diff before investing in a custom reviewer agent. Create project reviewer config only if repeated project-specific misses justify it.

---

# 14. REQUIRED MANUAL / LEGAL CHECKS

## Manual

- Review the existing `AGENTS.md` before replacement/editing.
- Review every external Skill's exact files, scripts, hooks, install path, network/env/secrets behavior.
- Decide whether to pin the Codex CLI during the final demo-critical period after a successful smoke.
- Review browser evidence artifacts for PII/secrets before storing/uploading.
- Decide whether remote MCP/doc-service queries may include project-sensitive names/code.

## Legal / licence

- Check exact licence/attribution of any third-party Skill actually copied into the repository.
- If borrowing Trail of Bits Skill prose/scripts, assess CC-BY-SA-4.0 share-alike/attribution implications. [S38]
- If Serena is reconsidered later, assess GPL-3.0-or-later implications for the exact deployment/distribution architecture. [S34]
- If borrowing from Anthropic Skills, inspect each specific Skill's licence; the repository is mixed. [S40]

No legal check is currently required merely to follow the workflow recommendations without vendoring third-party materials.

---

# 15. EXACT CHANGES FOR «ПОВОД»

These are **PROPOSED changes pending Gate 0**, not claims that the files do not already exist.

## Change A — audit/trim root `AGENTS.md`

Keep:
- frozen P0 / solo-first authority;
- Event/Occurrence semantics;
- UNKNOWN and no fabricated data;
- provenance/source;
- validated MAX identity boundary;
- smallest-diff discipline;
- verification/evidence vocabulary;
- review/handoff rule.

Move elsewhere:
- long technical procedures → Skills/runbooks;
- task-specific detail → task;
- old history → ordinary docs/archive;
- library docs → links/runbooks.

## Change B — Phase-1 Skills

### `scope-guard`

**Purpose:** prevent accidental P0 expansion and unrelated refactors.

**Trigger:** changing product behavior, API/routes/schema/contracts/dependencies/provider/auth, or a ticket whose implementation appears wider than requested.

**Reads:** applicable `AGENTS.md`; active ticket; only canonical documents referenced by the ticket; `git status`/diff; closest affected interfaces/tests.

**Commands:** safe Git inspection only (`git status --short`, `git diff --stat`, `git diff --check`, relevant diff). Do not invent package commands.

**Definition of Done:** every changed surface maps to acceptance criteria; no unrequested P1/stretch; non-goals remain untouched; any source-of-truth conflict is explicitly raised.

**Must not:** add new city/provider/map/social/infrastructure/tooling layer, opportunistic refactor, or future abstraction merely because it seems cleaner.

### `test-and-verify`

**Purpose:** make “done” evidence-based.

**Trigger:** before any code task is called complete.

**Reads:** changed files, nearest tests, package manifests/scripts, current verification runbook.

**Commands:** real repository commands only: targeted tests → relevant wider tests → applicable lint/typecheck/build → `git diff --check` → final diff inspection.

**Definition of Done:** receipt lists command, result/exit status, and what that result actually proves; required unrun checks are explicitly marked.

**Must not:** say tests passed when not run; hide failures by changing configuration; install a dependency merely to make a gate disappear; conflate pre-existing and introduced failures without evidence.

### `runtime-evidence`

**Purpose:** prevent fake runtime claims and create small reproducible evidence.

**Trigger:** changed user-visible, browser, integration, provider or MAX behavior.

**Reads:** acceptance criteria, existing runtime runbook, affected route/flow, environment definition.

**Commands:** only the project's verified start/dev/e2e/browser commands. Prefer existing Playwright Test/CLI where present.

**Definition of Done:** evidence tied to HEAD identifies environment, observed behavior, artifacts/logs and any failed check.

**Must not:** treat localhost as MAX, mock data as live provider, stale screenshot as current build, or static inspection as runtime verification.

## Change C — Phase-2 domain Skills

### `data-safety`

**Purpose:** preserve Povod domain semantics across models/ranking/filtering/serialization/UI.

**Trigger:** domain types, dedupe, ranking/eligibility, price/place/time/coordinate handling, API serializers or UI interpretation of missing values.

**Reads:** canonical data/product contract, affected types/transforms/serializers/tests.

**Commands:** real targeted invariant tests discovered in the repo; no hardcoded imaginary test names.

**Definition of Done:** Event/Occurrence separation preserved; UNKNOWN not silently converted to false/zero/fabricated value; no fake coordinates; hard constraints remain hard; provenance survives.

**Must not:** improve UX by inventing missing data; collapse distinct Occurrences; replace unknown conditional/raw price semantics with a convenient scalar.

### `provider-adapter`

**Purpose:** keep provider normalization honest and provider-specific complexity behind the adapter.

**Trigger:** ingestion/provider API/schema/normalization/event-occurrence/venue/price/source handling.

**Reads:** provider interface, concrete adapter, relevant provider contract/docs snapshot, domain types, fixtures/tests.

**Commands:** provider/unit/contract/smoke commands actually present in the repo.

**Definition of Done:** source/provenance retained, provider missing fields remain honest, occurrence identity remains correct, provider unavailable/error state does not become fabricated data.

**Must not:** add a second provider, scrape new surfaces or redesign the core schema without ticket authority.

### `max-integration`

**Purpose:** preserve MAX identity/session/deeplink/bridge security and evidence boundaries.

**Trigger:** initData/identity validation, session, startapp/deep-link, Bot API, Mini App bridge or MAX runtime changes.

**Reads:** MAX integration contract, auth/session implementation, current relevant official MAX docs snapshot/runbook, tests/threat notes.

**Commands:** real signature/auth/session/deep-link tests and runtime smoke available in repo/environment.

**Definition of Done:** server-side identity authority preserved; invalid/tampered inputs follow contract; secrets are not logged; environment-qualified runtime evidence exists where acceptance requires it.

**Must not:** weaken validation for demo convenience, trust client identity, or call a local browser run “verified in MAX”.

## Change D — reviewer only after native review trial

Use built-in `/review` first. Only if project-specific domain misses repeat, add `.codex/agents/reviewer.toml` with read-only sandbox and concise domain/scope/security instructions.

## Change E — runbooks derived from reality

Only create/update `docs/runbooks/verification.md` and `docs/runbooks/local-runtime.md` if equivalent authoritative files do not exist. Populate them only after the commands have actually succeeded on the host.

---

# 16. IMPACT ON P0 / P1 / STRETCH

| Layer | Impact |
|---|---|
| **P0** | **No product scope change.** Only implementation-process guardrails: scope preservation, verification, evidence and handoff. |
| **P1** | No new feature recommendation. A future lightweight reviewer/explorer or stronger security tooling may be enabled if proven useful. |
| **Stretch** | None required. MCP, semantic navigation servers, alternate agent runtimes and large skill ecosystems remain post-hackathon/needs-driven options. |

### CONFLICT WITH CURRENT SOURCE OF TRUTH

**No final recommendation in this archive intentionally conflicts with the canonical context supplied in this request.**

However, an exact byte-level comparison against the four named canonical files could not be performed here. Therefore the first host action must check them. If the files differ from this supplied context, that is a **`CONFLICT WITH CURRENT SOURCE OF TRUTH`** and the host files take precedence after human confirmation of their currency.

The noncanonical test deck contains presentation language that could tempt an agent toward broader multi-city/map scope. That language is **not** authority for implementation and must be ignored when it conflicts with P0 freeze. [S02]

---

# 17. WHAT NOT TO DO

- Do not install tens/hundreds of Skills because they exist.
- Do not let an installer select/update all Skills automatically.
- Do not run unreviewed install scripts, `curl | sh`, hooks or MCP servers with broad privileges.
- Do not make outbound network access default-on for coding tasks.
- Do not use `--yolo`/danger-full-access as normal workflow.
- Do not deploy multiple writers into overlapping files.
- Do not migrate the project to WSL solely for Codex during the hackathon.
- Do not add Playwright if an equivalent existing e2e/browser stack already covers acceptance.
- Do not add Playwright MCP when Test/CLI is sufficient.
- Do not turn Context7 into an automatic dependency for every implementation prompt.
- Do not depend on legacy custom prompt folders for project-critical workflow.
- Do not create an ExecPlan for every small bug.
- Do not create duplicate roadmap/context/memory files that compete with canonical docs.
- Do not store raw chat transcripts or hidden reasoning as project source of truth.
- Do not call a task `VERIFIED` from a green build if required runtime did not run.
- Do not call localhost MAX evidence.
- Do not call mock provider data live-provider evidence.
- Do not let LLM code review replace tests/lint/typecheck/security checks.
- Do not copy third-party Skill content without exact licence/provenance review.
- Do not upgrade Codex/tooling automatically during demo-critical work without smoke testing.

---

# 18. SELF-CRITIQUE / RED TEAM

This section intentionally tries to disprove the report's own recommendations.

## RT-F1 — Six custom Skills may still be too many

**Attack:** even six repository Skills may create routing overhead and maintenance burden for a short hackathon.

**Assessment:** valid. The six are not required all at once.

**Mitigation/final ruling:** phase them: start with three. If a proposed domain Skill is not reliably triggered by real tickets or merely restates `AGENTS.md`, do not add it.

## RT-F2 — A custom reviewer may duplicate native `/review`

**Attack:** creating reviewer config adds another file/model/rule surface with no evidence it improves results.

**Assessment:** valid.

**Mitigation/final ruling:** use built-in `/review` first. Create a custom reviewer only after repeated Povod-specific misses are observed.

## RT-F3 — Playwright CLI may be unnecessary

**Attack:** the repo may already have Playwright Test or another sufficient e2e system; adding CLI/Skill duplicates tooling.

**Assessment:** valid; repository state is currently unknown.

**Mitigation/final ruling:** detect existing stack first. “Playwright is a good tool” does not authorize a new dependency.

## RT-F4 — Network-off can slow provider/package work

**Attack:** a strict network-off default may cause constant approval friction for npm/package/provider tasks.

**Assessment:** true for network-dependent tasks.

**Mitigation/final ruling:** keep network off as normal posture, enable narrowly for explicit tasks/run commands. Security posture must not become ceremony that blocks actual work.

## RT-F5 — Handoff files can become bureaucracy

**Attack:** writing a Markdown handoff after every tiny edit costs more than it saves.

**Assessment:** valid.

**Mitigation/final ruling:** durable handoff only for substantial/multi-session/branch-boundary work. Small tasks use ticket + commit/PR evidence.

## RT-F6 — No hooks means less automatic recovery after compaction

**Attack:** avoiding hooks may make resumed sessions less automatic.

**Assessment:** possible, but native AGENTS and explicit task/handoff files already provide durable recovery paths.

**Mitigation/final ruling:** add a hook only if real compaction/resume tests show repeated context loss that native mechanisms do not solve.

## RT-F7 — Pinning Codex can miss security fixes

**Attack:** a fixed version during final days could leave a known bug unfixed.

**Assessment:** valid.

**Mitigation/final ruling:** “pin” means controlled known-good version, not “never update.” Monitor release/advisory notes, upgrade through a smoke, then repin.

## RT-F8 — One writer can be slower than parallelism

**Attack:** truly independent frontend/backend work may finish faster with multiple writers.

**Assessment:** true for disjoint ownership.

**Mitigation/final ruling:** one writer is the default, not a ban. Use multiple writers only with non-overlapping surfaces, explicit integration owner and evidence that parallelism earns its additional tokens/review burden.

## RT-F9 — Root `AGENTS.md` could still become stale

**Attack:** even a short invariant file can drift from actual contracts.

**Assessment:** valid.

**Mitigation/final ruling:** keep only durable invariants and link to canonical docs; changes to canonical semantics should include review of agent instructions.

## RT-F10 — Third-party Skills might outperform custom Povod procedures

**Attack:** custom Skills take authoring effort and may be worse than mature external ones.

**Assessment:** possible for generic tasks such as secret scanning or browser operation.

**Mitigation/final ruling:** external exact Skills are acceptable when they solve a demonstrated gap and pass the security/licence/pin gate. Domain invariants remain project-owned because no general library knows Povod's frozen semantics.

## RT-F11 — The research cannot prove token savings

**Attack:** the entire proposed setup is marketed as “less tokens/context”, but no Povod A/B benchmark was run.

**Assessment:** correct.

**Final ruling:** the report does **not** claim a measured token saving. It recommends choices structurally aligned with smaller context/routing surface. Actual token/time/rework effect must be measured if the team needs an efficiency claim.

---

# 19. MISSING AREAS CHECK

## What could have been forgotten?

Checked additionally in the final pass:
- current Codex stable release cadence and security/reliability changes;
- custom prompt state/regressions;
- hooks as an executable/context surface rather than a free convenience;
- trusted-project requirement for project config/MCP;
- current Serena patch status rather than repeating stale vulnerability wording;
- separate official Playwright CLI repository;
- third-party Skill installation/pinning guidance from GitHub;
- larger security/reference collections (Trail of Bits, Awesome Copilot);
- per-repository Skill source footprint and executable/script surface.

## What remains impossible to close here?

- exact current Povod repository layout/commands/config;
- byte-level canonical file conflict audit;
- installed Codex host version/config;
- actual Skill trigger quality;
- actual token/time/rework savings;
- runtime evidence for app/MAX/provider/browser;
- current CI/remote integration.

## What requires a runtime test?

- Codex sandbox/network/approval behavior on the host;
- project commands under that sandbox;
- each custom Skill trigger;
- local browser flow when acceptance requires UI;
- MAX-specific flow separately;
- provider live path when modified;
- CI and artifact handling.

## What requires a human/manual decision?

- whether current `AGENTS.md` instructions are still wanted;
- whether a Codex version should be pinned during the final days;
- whether any remote MCP/doc service may receive project-sensitive queries;
- whether a third-party Skill's marginal value justifies its supply-chain surface.

## What requires legal consultation/check?

No lawyer is required to execute the proposed native workflow. A licence review is required before vendoring/adapting third-party Skill content with CC-BY-SA, GPL or mixed licences, or if a future integration changes distribution obligations.

## What requires Codex/host?

Gate 0 read-only repository preflight, all real command derivation, config smoke, Skill trigger tests, and runtime evidence.

## What can be considered closed?

- native architecture direction: concise instructions + progressive Skills + bounded specialized agents;
- rejection of wholesale Skill catalogues for P0;
- no assumption that subagents save tokens;
- optional—not mandatory—ExecPlan;
- no mandatory hooks/MCP/custom prompts;
- browser evidence preference for existing Playwright Test/CLI over always-on MCP;
- exact security caveat that runtime claims require matching runtime evidence.

---

# 20. SOURCE MANIFEST

The complete machine-readable source manifest is in `SOURCE_MANIFEST.csv` and `SOURCE_MANIFEST.json`.

## Primary OpenAI / GitHub sources

- **S03-S12:** current OpenAI Codex documentation covering AGENTS, Skills, subagents, MCP, config, sandbox/approvals, hooks and review.
- **S13-S14:** OpenAI-maintained ExecPlan examples/convention.
- **S15-S18:** official `openai/codex` releases/issues for current version and custom prompt state.
- **S19:** official GitHub Agent Skill installation/security guidance.

## GitHub repositories checked

| Source | Repository | Licence | Latest release / activity checked | Archived? | Povod use |
|---|---|---|---|---:|---|
| S20 | `microsoft/skills` | MIT | active 18.09; no formal latest release | no | Reference / exact Skill only |
| S21 | `scarletkc/agents` | Apache-2.0 | active 14.09 | no | Small process reference |
| S22 | `gohypergiant/agent-skills` | Apache-2.0 | active 11.09 | no | Testing/TS/security reference |
| S23 | `ever-just/agentskills` | MIT root | active 18.09 | no | Procedural reference only |
| S24 | `GitGuardian/agent-skills` | MIT | v0.6.2, 31.08; active Sept | no | Optional `scan-secrets` |
| S26 | `microsoft/playwright` | Apache-2.0 | v1.63.0, 04.09; active 18.09 | no | Existing Test/CLI preferred |
| S27 | `microsoft/playwright-cli` | Apache-2.0 | v0.1.20, 14.09 | no | Conditional browser evidence tool |
| S29 | `microsoft/playwright-mcp` | Apache-2.0 | v0.0.81, 14.09; active 18.09 | no | Defer/on-demand |
| S30 | `obra/superpowers` | MIT | v6.3.0, 12.08 | no | Borrow patterns, reject framework P0 |
| S31 | `Phelan164/codex-howto` | MIT | v0.6.0; active 15.09 | no | Evidence/orchestration reference |
| S32 | `yamadashy/repomix` | MIT | v1.18.0, 08.08; active Sept | no | Emergency/narrow packing only |
| S33 | `upstash/context7` | MIT | MCP 4.1.1, 14.09; active 18.09 | no | Defer until version-doc need |
| S34 | `oraios/serena` | GPL-3.0-or-later app; SolidLSP MIT | v1.7.0, 09.08; active 18.09 | no | Defer post-hackathon |
| S37 | `docker/docker-agent` | Apache-2.0 | v1.141.0, 16.09; active 18.09 | no | Reject alternate harness P0 |
| S38 | `trailofbits/skills` | CC-BY-SA-4.0 | active 16.09 | no | Strong security reference only |
| S39 | `github/awesome-copilot` | MIT repo | active 18.09 | no | Discovery/reference catalogue |
| S40 | `anthropics/skills` | mixed/per-skill | active 10.09 | no | Reference; exact licence per Skill |
| S41 | `workersio/skills` | MIT | latest meaningful commit May 2026 | no | Not needed |
| S42 | `SteveVitali/agent-skills` | MIT | active 11.09 | no | Handoff/evidence reference |

### Required repository security/context observations

- Large catalogues contain executable/script material; installation is not merely copying prose.
- “Skill bytes” in this report measure repository source surface and are **not** an active token count.
- Stars are recorded only as a weak ecosystem signal and are not used as the decision criterion.
- Required permissions/network/runtime differ per exact Skill and must be audited at the exact pinned tree, not inferred from the repository name.

---

# 21. FINAL CHECKLIST

## Research quality gate

- [x] Major previous conclusions re-evaluated rather than accepted by inertia.
- [x] Time-sensitive OpenAI/Codex facts checked against current official sources.
- [x] Required GitHub repositories rechecked for URL/owner/default branch/licence/activity/releases where available.
- [x] Additional stronger reference projects considered.
- [x] Stars treated only as weak secondary signal.
- [x] Runtime claims separated from static/docs/source evidence.
- [x] No Povod runtime success claimed.
- [x] P0 not expanded.
- [x] Source-of-truth conflict handling made explicit.
- [x] Material corrections to the first answer captured in `DECISION_DELTA.md`.
- [x] Rejected/deferred choices documented.
- [x] Security/supply-chain implications documented.
- [x] Serena fixed-advisory wording corrected.
- [x] Missing areas/runtime/manual/legal checks documented.
- [x] Claim/evidence matrix populated.
- [x] Decision matrix populated.
- [x] Source manifest populated.
- [x] `machine_summary.json` populated.
- [x] `CODEX_ACTIONS.md` populated.

## Open blockers carried honestly

- [ ] Actual working tree read-only Gate 0 — **HOST REQUIRED**.
- [ ] Direct byte-level canonical four-file audit — **HOST REQUIRED**.
- [ ] Real project command verification — **HOST REQUIRED**.
- [ ] Codex host/version/config smoke — **HOST REQUIRED**.
- [ ] Skill trigger tests — **HOST REQUIRED**.
- [ ] Runtime browser/MAX/provider evidence — **TASK-DEPENDENT HOST REQUIRED**.

## Final verified research position

The research is complete enough to guide the next implementation pass without expanding P0. It is **not** a substitute for the repository preflight or runtime evidence. The first Codex session should therefore execute `CODEX_ACTIONS.md` Gate 0, reconcile the archive against the actual working tree/canonical files, and only then apply the minimal agent-workflow changes that are still needed.
