# CODEX ACTIONS

This file is the handoff from research to implementation. It intentionally does **not** invent package/test commands because the working tree was unavailable during research.

## Gate 0 — READ ONLY. Establish truth before edits.

Codex must first inspect the actual repository and return a short evidence receipt containing:

1. repository root, branch, `HEAD`, `git status --short`;
2. all applicable `AGENTS.md` / `AGENTS.override.md` files and their scopes;
3. whether these files exist and their current hashes/status:
   - `POVOD_FINAL_SCOPE_FREEZE_MVP.md`
   - `POVOD_PRODUCT_SPEC_V1.md`
   - `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`
   - `POVOD_PRODUCT_CONTRACT_V1.json`;
4. current package manager/lockfiles/manifests;
5. scripts for test/lint/typecheck/build/dev/start;
6. existing test frameworks and test directories;
7. existing Playwright/package/browser config;
8. existing `.agents/skills`, `.codex/config.toml`, `.codex/agents`, `.codex/hooks.json` / hooks config;
9. CI workflow files and current secret/dependency scanning;
10. Git remote status and whether a GitHub PR workflow exists;
11. host `codex --version`, OS and shell.

**Stop condition:** if the four canonical files contradict the project context used in this archive, report `CONFLICT WITH CURRENT SOURCE OF TRUTH` before changing any harness file.

## Gate 1 — Audit existing `AGENTS.md`, do not replace blindly

Classify every existing instruction:

- `KEEP_ALWAYS_ON`
- `MOVE_TO_SKILL`
- `MOVE_TO_CANONICAL_DOC`
- `MOVE_TO_RUNBOOK`
- `DELETE_DUPLICATE_OR_STALE`
- `CONFLICT_REQUIRES_HUMAN`

Then propose the minimal diff. The final root file must preserve frozen P0 and domain invariants while removing duplicated history/tutorial content.

## Gate 2 — Add only Phase-1 Skills

Create or conservatively update:

```text
.agents/skills/scope-guard/SKILL.md
.agents/skills/test-and-verify/SKILL.md
.agents/skills/runtime-evidence/SKILL.md
```

Do not install an external marketplace in this gate.

### Skill: `scope-guard`

**Trigger:** product behavior, routes/API/schema/contracts/dependencies/providers/auth, or task looks wider than current ticket.  
**Reads:** applicable `AGENTS.md`, active ticket, only canonical docs referenced by the ticket, diff/status.  
**Commands:** safe Git status/diff only; no product runtime.  
**Definition of Done:** every changed surface maps to acceptance criteria; no unrequested P1/stretch; non-goals remain untouched.  
**Must not:** add future abstractions/providers/cities/social/map/features opportunistically.

### Skill: `test-and-verify`

**Trigger:** before a code task is called complete.  
**Reads:** changed files, nearest tests, real repo scripts/runbook.  
**Commands:** discovered project commands only; targeted tests first, then relevant wider checks, lint/typecheck/build, `git diff --check`, diff review.  
**Definition of Done:** evidence records command, exit/result and what it actually proves.  
**Must not:** claim tests ran when they did not, alter config to suppress failure, or install dependencies to make a gate disappear.

### Skill: `runtime-evidence`

**Trigger:** user-visible/integration/browser/provider/MAX behavior changes.  
**Reads:** acceptance criteria, existing runtime runbook, affected route/flow.  
**Commands:** existing start/dev and browser/test tools.  
**Definition of Done:** environment-qualified observation tied to HEAD plus compact screenshot/log/trace where needed.  
**Must not:** upgrade localhost evidence to MAX evidence, mocks to live-provider evidence, or stale screenshots to current-build evidence.

## Gate 3 — Trigger evaluation

Run a small positive/negative/ambiguous prompt matrix for each Phase-1 Skill. Fix descriptions until they trigger narrowly. Do not add more Skills until this passes.

## Gate 4 — Codex project config spike

Only after existing config is known, test a minimal config equivalent to:

```toml
approval_policy = "on-request"
sandbox_mode = "workspace-write"

[sandbox_workspace_write]
network_access = false
```

Do **not** add a model pin.  
Do **not** add hooks.  
Do **not** add MCP.  
Do **not** set `allow_login_shell=false` until normal project commands pass without login-shell dependencies.

Evidence must show normal edit/test behavior and expected approval/network behavior.

## Gate 5 — Reviewer

Use built-in `/review` against a representative diff first.

Only if project-specific review behavior is repeatedly needed, create:

```text
.codex/agents/reviewer.toml
```

Required properties:

- `name`, `description`, `developer_instructions`;
- `sandbox_mode = "read-only"`;
- focus on scope, correctness, security, domain semantics and missing tests;
- no style-only flood;
- no application writes.

Do not pin a model unless the team has a reproducibility reason and accepts maintenance.

Optional `.codex/agents/explorer.toml` comes later and only if impact-radius discovery is genuinely expensive.

## Gate 6 — Add Phase-2 domain Skills only after Phase-1 works

```text
.agents/skills/data-safety/SKILL.md
.agents/skills/provider-adapter/SKILL.md
.agents/skills/max-integration/SKILL.md
```

### `data-safety`

Trigger on domain models, ranking/filtering, serialization, dedupe, UI interpretation of missing data. Preserve `Event != Occurrence`, UNKNOWN, raw/conditional price, no fake coordinates, hard constraints, provenance.

### `provider-adapter`

Trigger on ingestion/provider normalization. Preserve provider source, occurrence identity, honest missing values and unavailable/error mapping. Do not add a second provider unless ticket-authorized.

### `max-integration`

Trigger on init data/identity/session/startapp/deeplinks/bot/Mini App bridge. Server-side validation is authority. Never claim MAX runtime from ordinary local browser.

## Gate 7 — Verification/runbooks

Create or update **only if equivalent docs do not already exist**:

```text
docs/runbooks/verification.md
docs/runbooks/local-runtime.md
```

Populate from commands actually executed successfully. Never copy generic commands from this research archive.

## Gate 8 — Browser tooling

Detect existing Playwright first.

- If present: use/pin existing stack; add only a narrow P0 smoke if ticket justifies it.
- If absent: present a separate tooling diff/cost before adding it.
- Prefer Playwright Test/CLI.
- Do not add Playwright MCP unless a stateful exploratory use case has already failed with simpler tools.

Evidence should include current commit and environment. Redact secrets in traces/screenshots/logs.

## Gate 9 — CI

Only after local commands are stable:

- mirror those exact commands in CI;
- add domain-contract test lane if it materially shortens failures;
- one bounded P0 UI smoke;
- use existing secret/dependency scanners first;
- keep live-provider smoke manual/scheduled until proven non-flaky;
- do not make LLM review the enforcement layer.

## Gate 10 — Third-party skill rule

Do not install third-party Skills unless a concrete missing capability is demonstrated.

If approved:

- verify exact licence;
- preview exact tree/content;
- review scripts/hooks/installers/env/network/MCP/secrets;
- pin exact upstream SHA;
- install project-local;
- run trigger smoke;
- record provenance in handoff.

The only external Skill likely to earn its cost before hackathon end is the official Playwright CLI Skill **if** browser evidence is needed and the repository does not already provide an equivalent workflow.

GitGuardian `scan-secrets` remains optional after checking existing secret scanning.

## Gate 11 — Handoff

For every substantial/multi-session task, write/update a compact handoff (existing project location if one already exists; otherwise `docs/handoffs/<ticket>.md`):

```text
Status: VERIFIED | PARTIAL | BLOCKED
Base: <sha>
HEAD: <sha>
Scope: <one sentence>
Done: <facts>
Evidence: <command/result/what it proves>
Runtime: <environment + artifact or NOT RUN>
Changed: <paths>
Contracts: <invariants touched/preserved>
Not verified: <items>
Residual risks: <items>
Next exact action: <one action>
```

A script may populate hashes/status/changed-file lists. It must never auto-label a task `VERIFIED`.

## Decisions Codex must NOT change

- P0 freeze and solo-first path.
- Required identity validation boundary.
- `Event` / `Occurrence` semantics.
- honest `UNKNOWN` semantics.
- provenance/source requirements.
- no fabricated coordinates/price/time/place.
- social flow remains optional continuation.
- no new provider/city/map/social/infrastructure/tooling layer merely because an agent thinks it is cleaner.
- no claim of MAX/provider/runtime success without matching runtime evidence.
