# Archive quality gate

Status: PASS

## Checks
- FACT_CHECK_MATRIX.csv: 30 data rows, 10 columns
- SOURCE_MANIFEST.csv: 42 data rows, 17 columns
- DECISION_MATRIX.csv: 25 data rows, 11 columns
- CLAIMS_EVIDENCE.csv: 30 data rows, 9 columns
- Sources: 42
- Suspicious marker hits (manual review): []

## Errors
- None
