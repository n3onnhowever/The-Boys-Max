# Verification notes

- Verification date: 2026-09-18.
- The OpenAI/Codex surface is fast-moving: GitHub API showed stable Codex 0.155.1 released at 20:03 UTC on the same date.
- Repository metadata was fetched from GitHub API; stars were recorded only as a weak signal and never used as a verdict criterion.
- `SKILL.md` file counts/bytes were measured from recursive Git trees. These figures represent source/repository surface, **not** the prompt context Codex loads at once. Current Codex progressive disclosure loads metadata first; the initial skill listing is itself bounded.
- No Povod runtime, MAX runtime, provider runtime, Playwright run, Codex host command, install command or third-party Skill execution was performed in this research pass.
- File Library search did not retrieve direct byte-level copies of the four canonical Povod files named by the user. The authoritative project constraints stated in the research request were used. A host preflight is mandatory before changing the repository.
- The uploaded `POVOD_TEST_DECK_V1.pptx` was treated as a secondary presentation artifact, not a source of truth.
