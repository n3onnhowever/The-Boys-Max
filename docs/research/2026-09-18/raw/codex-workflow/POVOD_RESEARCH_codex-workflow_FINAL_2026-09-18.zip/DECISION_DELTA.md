# DECISION DELTA

## Previous conclusion vs final verified conclusion

| Previous conclusion | Final verified conclusion | Delta | Why | Evidence / impact |
|---|---|---|---|---|
| Short root `AGENTS.md` | **UNCHANGED AFTER VERIFICATION**, but make it even more compact | Refined | Current OpenAI guidance emphasizes concise durable instructions and progressive disclosure | S03, S04, S12. Keep well below the 32 KiB combined ceiling; the ceiling is not a target. |
| About six repo-local custom Skills | **UNCHANGED IN SHAPE, CHANGED IN ROLLOUT**: stage 3 first, then 3 | Refined | Trigger quality matters more than count; six is a project proposal, not an OpenAI magic number | S04. Reduces context/routing and authoring risk. |
| One primary writer + read-only reviewers | **UNCHANGED AFTER VERIFICATION** | Confirmed | OpenAI supports specialized custom agents, while subagents cost extra tokens | S05, S11. |
| Subagents can help speed/parallelize | **QUALIFIED**: they can improve wall-clock/independence but consume more tokens | Material correction | Official docs explicitly warn subagent workflows use more tokens | S05. Do not sell orchestration as token optimization. |
| `.codex/agents/explorer.toml` / `reviewer.toml` supported | **CONFIRMED** | Verified | Current official docs document project custom agents under `.codex/agents/` | S05. |
| Reviewer config `read-only + never` | **CHANGED**: default interactive reviewer should inherit/use `on-request`; `never` only for intentionally noninteractive jobs | Material correction | Official security examples use both patterns for different goals | S07, S08. Avoid unnecessarily disabling escalation. |
| `approval_policy=on-request`, `workspace-write`, network off | **UNCHANGED**, but host compatibility must be smoke-tested | Confirmed | Official config/security docs | S07, S08. |
| `allow_login_shell=false` in baseline | **DOWNGRADED TO OPTIONAL HARDENING** | Material correction | Supported key, but can break profile-dependent workflows | S07, S08. Test first. |
| SessionStart hook to re-read `AGENTS.md`/ticket/handoff | **REJECT INITIAL** | Material correction | AGENTS is native; hooks can inject duplicate context and add executable lifecycle surface | S03, S09. Add only if a measured compaction/resume problem appears. |
| ExecPlan only for large tasks | **UNCHANGED, better grounded** | Verified | OpenAI Cookbook says ExecPlan is an arbitrary convention; OpenAI repos use it for substantial multi-step work; current Codex has a system Exec Plan skill | S04, S13, S14. |
| Separate `PLANS.md` not needed for normal Povod tickets | **UNCHANGED** | Confirmed | `PLANS.md` is optional convention, not platform requirement | S13. Add only after repeated need. |
| Reusable prompt files are useful | **CHANGED: do not depend on legacy custom prompts** | Material correction | 2026 prompt-discovery regressions and rejected project-scoped prompt feature; Skills are current reusable primitive | S04, S17, S18. `PROMPTS.md` may be human documentation only. |
| Playwright CLI/Test preferred to MCP | **UNCHANGED AND STRONGLY CONFIRMED** | Verified | Microsoft now explicitly positions CLI as more token-efficient for coding agents | S26-S29. |
| `microsoft/playwright-cli` separate canonical repo uncertain | **CORRECTED: separate repo is confirmed** | Correction | Official GitHub repo exists and released v0.1.20 on 14.09.2026 | S27. |
| Playwright MCP optional | **UNCHANGED, with stronger security caveat** | Refined | Official README says it is not a security boundary | S29. |
| GitGuardian `scan-secrets` optional | **UNCHANGED, more conditional** | Refined | Full workflow requires ggshield/account/auth and can add hooks/network | S24-S25. Prefer existing native CI scanner if present. |
| Serena rejected partly because recent security issues | **CHANGED WORDING**: current v1.7.0 patches both cited advisories; still defer for P0 on complexity/licence/privilege grounds | Material correction | Critical SSTI patched 1.7.0; dashboard issue patched 1.5.2+ | S34-S36. Never call current v1.7.0 vulnerable to those fixed issues. |
| Context7 on-demand | **UNCHANGED, default now even stricter: defer unless version-specific docs pain is proven** | Refined | Remote dependency and tool/context surface are not needed for core P0 | S33. |
| Repomix narrow/emergency only | **UNCHANGED AFTER VERIFICATION** | Confirmed | Recent sandbox hardening reinforces that broad packing/MCP access is a real security/context decision | S32. |
| Superpowers not installed | **UNCHANGED AFTER VERIFICATION** | Confirmed | Strong methodology but broad routing/ceremony remains overkill | S30, S12. |
| Docker Agent not installed | **UNCHANGED; licence/currentness corrected** | Refined | It is active, Apache-2.0, v1.141.0, but is a full alternate runtime/harness | S37. |
| WSL may be worth considering | **REJECT DURING HACKATHON** | Material correction | Current Codex releases include WSL hardening and there are recent WSL regressions; environment migration adds risk | S16 plus current official issue/release evidence. Keep working host unless blocked. |
| Pin a current model in repo configs | **DO NOT PIN MODEL BY DEFAULT** | New correction | Model availability/current best choice moves faster than repo invariants | S05, current Codex docs. Keep role/model tuning operator-level unless reproducibility requires a pin. |
| Whole external skill libraries are too much | **UNCHANGED AND STRONGER** | Verified | Measured trees now show 201 Microsoft, 173 Ever-Just, 92 Trail of Bits, 436 Awesome Copilot `SKILL.md` blobs, etc. | S04, S20, S23, S38, S39. These totals are source surface, not all-at-once context. |
| Trail of Bits / Awesome Copilot were not highlighted | **ADDED AS STRONG REFERENCE SOURCES** | New | Both are current, maintained, and especially useful for security/skill-hygiene patterns | S38, S39. Still reference-only. |
| Codex version not central | **NEW OPERATING NOTE**: stable was 0.155.1 at verification end; host version must be recorded/pinned during final days | New | Codex is shipping rapidly, including same-day stable releases | S15, S16. Avoid surprise upgrades. |

## Net effect

No product-scope expansion. The verified configuration is **smaller** than the previous recommendation: fewer lifecycle automations, less reliance on host-specific prompt mechanisms, no environment migration, and clearer separation between deterministic verification, runtime evidence and LLM review.
