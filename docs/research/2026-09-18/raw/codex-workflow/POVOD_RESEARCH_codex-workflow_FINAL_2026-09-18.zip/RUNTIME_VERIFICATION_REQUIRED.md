# RUNTIME VERIFICATION REQUIRED

No Povod application runtime and no local Codex host runtime was executed during this research verification. The following claims therefore remain explicitly unverified until run on the project host.

## R1 — Host baseline

Record:

- `codex --version`;
- OS/shell;
- repository root;
- `git status --short`;
- `git rev-parse HEAD`;
- active branch;
- existing `.codex/`, `.agents/`, `AGENTS.md` files.

**Pass:** exact values are saved in the task handoff/evidence receipt.  
**Do not infer:** upstream 0.155.1 being current does not prove that version is installed or appropriate for this host.

## R2 — Canonical instruction chain

Open a clean Codex session from the repository root and from any important subdirectory after auditing applicable `AGENTS.md` files.

**Pass:** the agent can identify the correct root/local rules without reading stale decks or research archives as authority.  
**Evidence:** applicable file paths + a small test task that should trigger one invariant and one negative control.

## R3 — Skill discovery and trigger evaluation

For each repo-local Skill, run at least:

- 3 positive prompts that should trigger it;
- 3 negative prompts that should not;
- 1 ambiguous prompt.

**Pass:** no broad accidental triggering, no missing critical trigger, no skill discovery warning.  
**Do not optimize for:** maximum skill count.

## R4 — Sandbox and permissions

Smoke proposed config on the actual host.

Verify:

- normal source edits work in workspace;
- `.git`/protected operations prompt as expected;
- outbound command network is blocked when not required;
- a read-only reviewer cannot mutate tracked files;
- legitimate build/test commands do not depend on login-shell profile state before setting `allow_login_shell=false`.

## R5 — Custom reviewer

Run `/review` first. Only create a custom reviewer agent if it adds project-specific value.

**Pass:** review is read-only, cites changed files/lines/symbols, prioritizes correctness/security/test/scope findings and does not flood style comments.

## R6 — Deterministic project gates

Discover real commands from the working tree; then run:

1. affected tests;
2. broader relevant tests;
3. lint;
4. typecheck;
5. build;
6. `git diff --check`;
7. diff inspection.

The actual commands are **UNKNOWN** until host inspection and must not be copied from generic examples.

## R7 — Playwright / browser evidence

Before installing anything, detect existing Playwright dependencies/config.

If Playwright already exists, use it. If not, make installation a separately approved tooling change.

For a UI/integration ticket, prove only the relevant path. A P0 example after implementation might be:

`launch → personalized/feed state → concrete Occurrence → detail → source`

Capture:

- commit SHA;
- environment (`local web`, `MAX web`, `MAX mobile` — exact);
- start command;
- test/CLI command;
- screenshot for acceptance-critical state;
- console/network failure summary;
- trace on failure/first retry as needed.

**Important:** local browser evidence never upgrades to “VERIFIED BY MAX RUNTIME”.

## R8 — Live provider evidence

If the task changes provider integration, execute a bounded provider smoke with a known query and record raw response metadata safely.

**Pass:** the normalized result preserves `Occurrence`, UNKNOWN, price conditions and provenance; provider failure maps to an honest unavailable/error state.  
**Do not claim:** live provider coverage/stability from unit fixtures alone.

## R9 — Codex upgrade pin

If host Codex is older than the desired version, upgrade only in a disposable/clean state and run R1–R6 again. Once a version is proven during the final hackathon window, avoid surprise auto-upgrades before demo-critical work.

## R10 — Third-party skill smoke

Only if a third-party skill is approved:

- preview exact source tree;
- verify licence;
- verify pin/SHA;
- inspect scripts/install hooks/network/env access;
- install project-local;
- run a harmless positive/negative trigger test;
- remove it if value is not measurable.
