# GAPS AND OPEN QUESTIONS

## BLOCKERS for exact rollout

1. **Working tree unavailable here.** The actual `The-Boys-Max` repository could not be read in this research environment.
2. **Canonical files unavailable byte-for-byte here.** The four named source-of-truth files were not found as direct File Library resources. Their current project constraints were supplied authoritatively in the user request, but Codex must still read the exact working-tree files before editing.
3. **Current `AGENTS.md` unknown.** The final file must be an edit/audit of the real existing file, not a blind replacement generated from this archive.
4. **Package/test commands unknown.** Package manager, scripts, test runner, build command and current CI must be discovered from manifests.
5. **Current Playwright state unknown.** Do not add a second browser stack before checking dependencies/config/tests.
6. **Current Codex host version/config unknown.** Research verified current upstream state, not the user's installed runtime.

## OPEN QUESTIONS

- Does the repository already contain `.agents/skills`, `.codex/config.toml`, `.codex/agents`, hooks, or third-party skill material?
- Is the repository currently a clean Git repository with a valid baseline/HEAD?
- What is the actual active ticket after baseline work (T010 or a later task)?
- Which deterministic commands are authoritative for unit tests, integration tests, lint, typecheck and build?
- Is Playwright Test already installed? If yes, which version and which project/browser config?
- Does CI/hosting already provide secret scanning, dependency auditing or CodeQL/Semgrep, making GitGuardian unnecessary?
- Is a GitHub remote connected and is Codex Cloud Code Review available to the team?
- Do any current tasks truly span enough time/sessions to justify an ExecPlan file?
- Are there repository directories whose local rules differ enough to justify nested `AGENTS.md` files?

## Human/manual decisions

- Approve any new third-party skill after preview, licence review and script/network/secret audit.
- Decide whether to pin the current Codex CLI version for the remaining hackathon window after a smoke test.
- Decide whether GitGuardian external account/network dependency is acceptable if existing scanning is insufficient.
- Decide whether any remote documentation MCP (Context7 or similar) may receive library queries from the repo context.

## Legal checks

No new product licensing dependency is required by the recommended core workflow. Manual licence review is required only if third-party skill content is copied/vendored:

- Playwright / Playwright CLI: Apache-2.0.
- GitGuardian agent skills: MIT.
- Trail of Bits skills: CC-BY-SA-4.0; share-alike implications matter if content is copied/adapted.
- Serena application: GPL-3.0-or-later; SolidLSP: MIT; combined distribution GPL.
- Anthropic skills: mixed/per-skill licences; do not infer root-level permission.

## What requires runtime verification

See `RUNTIME_VERIFICATION_REQUIRED.md`.

## What can be considered closed

- Native Codex locations/mechanics for `AGENTS.md`, repo-local Skills, custom agents, MCP and hooks.
- Progressive-disclosure model and skill discovery cap.
- Subagent token-cost caveat.
- Current upstream repo status/licences/releases listed in this archive.
- The decision **not** to install broad skill catalogues for P0.
- The decision **not** to introduce an alternate agent harness for P0.
- The decision **not** to claim MAX/provider/browser runtime behavior without runtime evidence.
