# POVOD RESEARCH — Codex workflow / agentic coding

**Project:** «Повод»  
**Team:** The Boys  
**Research version:** `FINAL-2026-09-18`  
**Previous result:** agentic coding / Codex workflow analysis from the same research chat, 18.09.2026  
**Verification status:** **FINAL WITH OPEN BLOCKERS**

## What this archive is

This is the final verification archive for the research topic **agentic coding / Codex workflow**. It does not redesign the product and does not change the frozen P0. It verifies the previous recommendations against current OpenAI/Codex documentation, official GitHub repositories/releases, security advisories, and the project context available in this research environment.

## Final status

The central previous recommendation **survives verification**, with several simplifications and corrections:

- one implementation writer by default;
- concise root `AGENTS.md` as the durable always-on contract;
- a **small staged set of repository-local Skills**, not a marketplace dump;
- deterministic tests/lint/typecheck/build first;
- runtime evidence only for claims that require runtime;
- independent read-only review before a verified commit;
- compact durable handoff for substantial/multi-session work;
- MCP, hooks, remote docs tools, semantic-code servers and additional agent frameworks remain **off by default**.

The largest deltas from the previous answer are: no mandatory hooks, no dependency on legacy custom prompts, no assumption that subagents save tokens, no WSL migration, and a stricter distinction between an optional ExecPlan convention and native Codex primitives.

## Main open blockers

1. The actual working tree of `The-Boys-Max` was not accessible from this research environment.
2. Byte-level copies of the four named canonical project files were not retrievable here; the current authoritative project context supplied in this chat was used instead.
3. Therefore the real package manager, existing test/build commands, current `AGENTS.md`, existing `.codex` config, current Playwright setup and CI cannot be truthfully declared verified until a read-only host preflight.
4. No Povod runtime or Codex-host runtime was executed in this research pass.

These blockers do **not** invalidate the research verdict; they block only exact repo-local rollout details and runtime claims.

## Files

- `FINAL_REPORT.md` — complete verified research report.
- `EXECUTIVE_VERDICT.md` — short decision summary.
- `FACT_CHECK_MATRIX.csv` / `CLAIMS_EVIDENCE.csv` — claim → evidence → status matrices.
- `SOURCE_MANIFEST.csv` / `SOURCE_MANIFEST.json` — all sources used.
- `DECISION_MATRIX.csv` — evaluated options without artificial ranking.
- `DECISION_DELTA.md` — previous conclusion vs final verified conclusion.
- `GAPS_AND_OPEN_QUESTIONS.md` — unresolved areas.
- `RECOMMENDATIONS.md` — only actionable recommendations.
- `RISKS.md` — technical/security/operational risks.
- `RUNTIME_VERIFICATION_REQUIRED.md` — what still needs a real run.
- `CODEX_ACTIONS.md` — exact next implementation/harness actions for Codex.
- `machine_summary.json` — machine-readable synthesis.
- `evidence/` — research metadata snapshots generated during verification.

## Core caution

The repository should never let stale presentations, old research archives, prompt history or generic external skills override the current ticket and the canonical Povod contracts. The most important Codex rule is not “use more agent tooling”; it is **preserve the frozen scope and prove the behavior that changed**.
