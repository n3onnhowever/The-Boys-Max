# RISKS

## P0 process risks

### RISK-P0-01 — Context authority drift
**Severity:** High  
Stale decks, old research, prompt history or third-party skills can silently outrank the current ticket in the model's attention even if they are not authoritative.

**Mitigation:** explicit source hierarchy in `AGENTS.md`; narrow file reads; `scope-guard`; never bulk-load `/docs`.

### RISK-P0-02 — “Verified” without evidence
**Severity:** High  
An agent can conflate code inspection, green build or fixture tests with actual MAX/provider/browser behavior.

**Mitigation:** `runtime-evidence`; closed status vocabulary; evidence receipts; environment-qualified claims.

### RISK-P0-03 — Tooling work displaces product work
**Severity:** High  
Installing frameworks/MCP servers/marketplaces can consume the remaining hackathon time without improving P0.

**Mitigation:** default-off; one concrete pain must exist before adding a tool.

## Technical risks

### RISK-T-01 — Overgrown AGENTS/Skills
More persistent instructions increase context and rule conflicts. The 32 KiB AGENTS limit is a ceiling, not a target; initial skill metadata also has a hard discovery budget.

### RISK-T-02 — Parallel writer conflicts
Subagents cost additional tokens; overlapping writers can create inconsistent domain contracts and merge/review work.

### RISK-T-03 — Stale hardcoded commands
A Skill that embeds generic `npm test`/`pnpm build` commands without matching the real repo will fail or mutate the wrong surface.

### RISK-T-04 — Fast Codex release cadence
Stable 0.155.0 and 0.155.1 landed within roughly a day of this research. Unpinned auto-upgrades can change behavior during a critical demo window; old versions can miss security fixes.

## Security risks

### RISK-S-01 — Third-party Skill supply chain
Skills may include scripts, hidden instructions, hooks, installers and secret/network access. GitHub explicitly does not verify them.

### RISK-S-02 — Browser automation privilege
Playwright CLI/MCP can interact with real browser state, files and network. MCP itself is not a security boundary.

### RISK-S-03 — Remote MCP/docs leakage
Queries to Context7/other services can contain sensitive library/code context if the agent formulates them poorly.

### RISK-S-04 — Hooks
Hooks are executable lifecycle code and can inject context or run concurrently. A plugin can ship hooks too.

### RISK-S-05 — Secrets in evidence
Screenshots, traces, console output and network logs can capture tokens, session data and provider credentials.

## Licence / legal risks

- Do not copy CC-BY-SA Trail of Bits skill text into proprietary/project files without satisfying terms.
- Serena's application is GPL-3.0-or-later; avoid vendoring/combining casually.
- Anthropic skill licences are per-skill/mixed.
- A GitHub repository's root licence does not automatically settle embedded third-party assets/components.

## Operational risks

### RISK-O-01 — Environment migration
Moving to WSL or another harness during the hackathon changes paths, shells, browser/runtime integration and sandbox behavior.

### RISK-O-02 — CI flakiness from live providers
External provider checks should not be mandatory PR gates unless isolated/stable; use scheduled/manual live smoke instead.

### RISK-O-03 — Evidence artifact growth
Always-on traces/videos produce noise, storage cost and possible secrets. Prefer failure/acceptance artifacts only.
