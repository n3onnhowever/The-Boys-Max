# POVOD_RESEARCH_hackathon-compliance_FINAL_2026-09-18

**Topic:** Hackathon compliance, jury verifiability and evidence packaging for «Повод».  
**Project / team:** «Повод» / The Boys  
**Research version:** `FINAL-2026-09-18`  
**Previous result:** strict hackathon compliance audit in this chat, 2026-09-18  
**Verification status:** **FINAL WITH OPEN BLOCKERS**

## What is inside

- `FINAL_REPORT.md` — canonical verified report.
- `EXECUTIVE_VERDICT.md` — short decision summary.
- `FACT_CHECK_MATRIX.csv` / `CLAIMS_EVIDENCE.csv` — claim/evidence registers.
- `SOURCE_MANIFEST.csv` + `.json` — all used sources and reliability notes.
- `DECISION_MATRIX.csv` — keep/defer/reject decisions.
- `DECISION_DELTA.md` — previous vs final verified conclusions.
- `GAPS_AND_OPEN_QUESTIONS.md` — remaining unknowns.
- `RECOMMENDATIONS.md` — practical Povod actions only.
- `RISKS.md` — P0/technical/security/legal/integrity risks.
- `RUNTIME_VERIFICATION_REQUIRED.md` — exact tests that still require execution.
- `CODEX_ACTIONS.md` — source/code/config/test/evidence handoff.
- `machine_summary.json` — synthesis-ready machine summary.
- `evidence/` — evidence index and non-copyrighted verification notes.

## Final status

The research is packaged and cross-checked, but **release compliance is not certified** because major primary/runtime blockers remain. The most important one is the inability to reopen the exact official case PDF during this pass; the largest implementation/evidence gap is the absence of a same-SHA Docker + API + real MAX + provider acceptance bundle.

## Main conclusion

Do not add product scope. Convert the existing core into one reproducible, evidence-backed release and make the final presentation say only what that evidence proves.
