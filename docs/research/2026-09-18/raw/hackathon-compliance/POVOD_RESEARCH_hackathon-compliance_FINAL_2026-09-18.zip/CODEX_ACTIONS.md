# CODEX_ACTIONS — Hackathon Compliance Handoff

## Guardrails

- Do **not** change frozen P0, city scope, product entry flow or source-of-truth semantics.
- Do **not** implement second city, group-first flow, automatic group member add, new queue/orchestrator, or Smart Povod until P0 acceptance is green.
- Do **not** fabricate `DATA-API.yaml`; wait for exact official case content.
- Do **not** call source presence a runtime pass.
- Preserve UNKNOWN/source-unavailable/provenance behavior.

## Step 0 — current-state receipt before any edits

Run on the actual host/repository:

```powershell
$ErrorActionPreference = 'Stop'
Set-Location 'D:\Dev\Repos\The-Boys-Max'
git rev-parse HEAD
git status --porcelain=v1
git branch --show-current
git remote -v
git ls-files | Sort-Object
Get-ChildItem package-lock.json,pnpm-lock.yaml,yarn.lock -ErrorAction SilentlyContinue | Select-Object FullName,Length,LastWriteTime
Get-ChildItem DATA-API.yaml -ErrorAction SilentlyContinue | Select-Object FullName,Length,LastWriteTime
node --version
npm --version
docker version
docker compose version
```

Save output as evidence. Stop if tree is unexpectedly dirty; do not auto-clean user work.

## Step 1 — repository/reproducibility audit

Inspect exactly:
- `package.json`, `.npmrc`, any lockfile, Node/package-manager declarations;
- `README.md`, `.env.example`;
- `Dockerfile`, `compose.yaml`, `compose.release.yaml`;
- `scripts/openapi.ts`, `scripts/seed-test.ts`;
- API routes/health/readiness;
- `packages/platform/auth.ts`, platform base URL/auth handling;
- source URL handling and provider adapter;
- tests for security/error/UNKNOWN.

If no lockfile exists, identify the actual configured package manager first. Generate one through that manager, review diff, then prove frozen install. Do not switch package managers.

## Step 2 — MAX compatibility patch only if code requires it

Static search:

```powershell
rg -n "platform-api\.max\.ru|platform-api2\.max\.ru|access_token=|WebAppData|initDataUnsafe|auth_date|/chats/.*/members|X-Max-Bot-Api-Secret" .
```

Required outcomes:
- no runtime dependency on old `platform-api.max.ru`;
- token sent through `Authorization`, not query;
- WebAppData signature validation matches official algorithm including duplicate-param/hash rejection;
- startapp is context only, never authorization;
- no P0 dependency on `POST /chats/{chatId}/members`;
- if webhook P1 is attempted, verify secret header and idempotency/replay defense.

Freshness TTL/replay window is project hardening. Do not label a specific TTL as an official MAX requirement unless new docs state it.

## Step 3 — evidence runner

Prefer `scripts/evidence/collect.ps1` plus small test scripts, not a new service.

Expected directory:

```text
artifacts/evidence/<UTC>-<shortSHA>/
  manifest.json
  checksums.sha256
  00-meta/git-sha.txt
  00-meta/git-status.txt
  01-dependencies/package-manager.txt
  01-dependencies/lockfile.sha256
  02-build/docker-build.log
  02-build/docker-build-duration.json
  02-build/image-inspect.json
  03-startup/compose-config.yaml
  03-startup/compose-ps.txt
  03-startup/runtime.log
  03-startup/health.json
  04-api/api-smoke.json
  04-api/openapi.json
  04-api/openapi-validation.txt
  04-api/DATA-API.yaml
  05-max/initdata-valid.json
  05-max/initdata-invalid.json
  05-max/max-mobile-receipt.json
  05-max/max-web-receipt.json
  06-provider/MOSCOW_DATA_GATE_RECEIPT.json
  06-provider/provider-receipt.json
  07-ui/happy-path-360.png
  07-ui/happy-path-390.png
  07-ui/happy-path-430.png
  07-ui/happy-path-max-web.png
  07-ui/state-loading.png
  07-ui/state-empty.png
  07-ui/state-error.png
  07-ui/state-source-unavailable.png
  07-ui/state-unknown.png
  07-ui/state-conditional-price.png
  07-ui/state-saved.png
  07-ui/state-repeat-login.png
  08-tests/test-summary.json
  09-security/security-summary.json
  10-submission/claims.json
```

`DATA-API.yaml` is listed as an expected final evidence artifact only after the official case is recovered; until then the collector should mark it `MISSING_CASE_SPEC`, not generate placeholder content.

## Step 4 — Docker acceptance

First inspect base images. If case explicitly excludes first base-image download, pre-pull them in a separately logged preparation step. Then perform timed release build.

```powershell
$sw=[Diagnostics.Stopwatch]::StartNew()
docker build --progress=plain -t "povod:$env:BUILD_ID" . 2>&1 | Tee-Object $BuildLog
if ($LASTEXITCODE -ne 0) { throw 'docker build failed' }
$sw.Stop()
```

Record elapsed seconds and the exact case threshold only after primary case re-verification.

Then:

```powershell
docker compose -f compose.release.yaml config
docker compose -f compose.release.yaml up -d --wait
docker compose -f compose.release.yaml ps --all
docker compose -f compose.release.yaml logs --no-color
```

Do not invent a `/health` path; use the actual route discovered in source.

## Step 5 — API/OpenAPI

- Generate OpenAPI from the actual release code.
- Unless the recovered case says otherwise, target `openapi: 3.1.0`, not 3.2.x.
- Validate syntax and compare documented routes with running routes.
- Run external HTTPS smoke from outside the local Docker network.

## Step 6 — deterministic tests to add/execute

Named acceptance IDs:

```text
E2E-001 valid MAX launch/identity
E2E-002 tampered hash rejected
E2E-003 duplicate WebAppData/hash parameter rejected
E2E-004 interests/conditions → eligible feed
E2E-005 hard constraint cannot be overridden by ranking
E2E-006 occurrence detail has date/time/place/price-or-UNKNOWN
E2E-007 provenance/source link
E2E-008 UNKNOWN semantics
E2E-009 conditional price semantics
E2E-010 save
E2E-011 close/relaunch/repeat-login
E2E-012 loading
E2E-013 empty
E2E-014 controlled API error
E2E-015 provider unavailable
E2E-016 real MAX Web happy path
E2E-017 real MAX mobile happy path
E2E-018 deprecated MAX endpoint/config scan
```

Playwright may cover deterministic browser states, but mark those artifacts `BROWSER_EVIDENCE`, not `MAX_RUNTIME_EVIDENCE`.

## Step 7 — presentation source fixes (after evidence)

Do not redesign. Update factual content only:
- remove `2–3 города` from hackathon/MVP;
- remove/qualify Saint Petersburg `BETA` until its own gate passes;
- move subscriptions/invite to P1/stretch per source of truth;
- remove/relabel `NO-CODE CONCEPT`;
- preserve `NOT RUN` on validation until actually run;
- only show Smart Povod as runtime-working if bot evidence exists.

## Evidence protection

- Never save real bot token, cookies, raw personal initData or production secrets.
- Redact user identifiers in shareable evidence.
- Hash artifacts and produce `checksums.sha256`.
- One evidence bundle certifies one SHA only; code change => new build ID and affected tests rerun.
