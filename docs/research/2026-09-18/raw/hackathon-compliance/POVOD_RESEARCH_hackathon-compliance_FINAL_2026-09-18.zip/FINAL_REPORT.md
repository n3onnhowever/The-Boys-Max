# POVOD Hackathon Compliance — Final Verification Report

**Research version:** FINAL-2026-09-18  
**Verification status:** FINAL WITH OPEN BLOCKERS  
**Current verification date:** 2026-09-18  
**Topic:** hackathon-compliance  
**Project:** «Повод»  
**Team:** The Boys

> Fail-closed rule: no item is marked done merely because code/files exist. Runtime claims require direct runtime evidence. Case-specific claims whose exact official PDF could not be reopened are explicitly downgraded to prior-extraction status.

## 1. EXECUTIVE SUMMARY

The frozen product direction remains sound: **solo-first, Moscow-first, occurrence-first, honest UNKNOWN, visible provenance/source, optional save; social only after the solo result.** No verification finding justifies expanding P0.

The research itself can be packaged as a final verification pass, but release compliance **cannot** be certified yet. The controlling blocker is source integrity: the exact official 22-page case used earlier could not be reopened from the current File Library or recovered from public search. Therefore exact case statements (including submission format/deadline, scoring, bonus and DATA-API semantics) remain `PREVIOUSLY EXTRACTED / NEEDS PRIMARY RE-VERIFICATION` rather than `CONFIRMED`.

Current primary MAX documentation adds several material facts that were underweighted in the previous result: a Mini App is structurally attached to a chatbot; HTTPS is mandatory; WebAppData has an explicit HMAC validation algorithm; public placement is governed by a licence agreement and legal/content requirements; and `POST /chats/{chatId}/members` is being removed on **2026-09-30**. The last change strongly supports keeping group automation out of P0.

Local evidence was also tightened. Docker itself runs successfully on the workstation, but the Povod project image/compose stack is still not runtime-proven. The latest verified Git baseline from 2026-09-16 contains the expected source surface but had **no dependency lockfile and no DATA-API.yaml**, had `REMOTE=NONE`, and explicitly disclaims build/Docker/browser/MAX/provider/E2E acceptance.

## 2. FINAL VERDICT

**FINAL WITH OPEN BLOCKERS.**

Research verdict:
- The main prior recommendation — **do not broaden P0; turn implementation into judge-verifiable evidence** — is **UNCHANGED AFTER VERIFICATION**.
- Several details were corrected/strengthened: structural chatbot requirement, MAX legal placement obligations, Sep-30 group-member API removal, official-vs-recommended `auth_date` freshness distinction, current OpenAPI 3.2.1 existence, and broader presentation conflicts.
- The project should **not** claim submission compliance yet.

Release gate:
- `SUBMISSION_READY = false` until all P0 blockers in section 11 close on one release SHA/build ID.

## 3. WHAT WAS VERIFIED

Verified with primary/current evidence:
- Official MAX Mini App connection requirements, HTTPS, chatbot attachment and `startapp` constraints.
- Official MAX WebAppData signature validation algorithm and duplicate parameter/hash checks.
- MAX API domain/auth breaking changes and September 2026 group-member deprecation/removal.
- MAX placement/legal/content/security requirements currently published on dev.max.ru.
- Current OpenAPI published version (3.2.1, 2026-09-10) and OAI repository licence/activity.
- Local Git baseline inventory and SHA/status from 2026-09-16.
- Local Docker host runtime from 2026-09-13.
- Full test deck content from 2026-09-17.

Not directly reverified:
- The exact official hackathon case PDF and its current revision.
- The current repository HEAD after the 2026-09-16 baseline.
- Exact contents/semantics of project source files (only inventory/path evidence is available here, not a fresh host code read).
- Project Docker build/start, API runtime, MAX runtime, provider runtime, browser E2E.
- Provider legal approval and live-data gate.

## 4. CURRENT STATE AS OF 18.09.2026

### 4.1 Frozen product contract

P0 remains:
`MAX → validated MAX identity → interests/conditions → live events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → open source → optional save.`

No finding requires converting this to group-first. Any group/social mechanism remains optional continuation.

### 4.2 Verified source baseline

The final T002 host log records source baseline `d48f01eafa23ef4a0a2b98cb20b74e5052423a74` and docs-only handoff `4f9a198d4fa2b18686efa19a59b6ac78281d341d`, clean status, prohibited-path pass and `REMOTE=NONE`. Tracked files include Dockerfile, Compose files, `.env.example`, README, API/Mini App/worker source, OpenAPI generator, seed/test fixtures and security/integration tests.

That same handoff explicitly says it **does not establish npm/build, Docker, PostgreSQL, Redis, browser, MAX, live-provider, live-AI or E2E acceptance**. This caveat controls every runtime status in this report.

### 4.3 Docker environment

Host Docker is runtime-verified: Engine 29.7.2, Docker Desktop 4.90.0, Compose 5.5.1, WSL2, and a successful `hello-world`. This only proves the workstation container runtime; it is not evidence that Povod builds/runs or meets a time limit.

### 4.4 MAX platform current state

Key official facts:
- Mini Apps work only inside chatbots and require HTTPS.
- `startapp` Mini App payload is up to 512 allowed characters; bot `start` payload is up to 128.
- WebAppData authenticity is checked by the documented HMAC-SHA256 scheme; duplicate platform params/hash must be rejected by the algorithm.
- API requests should use `platform-api2.max.ru`; token-in-query is no longer supported.
- From 2026-09-09 adding group members via `POST /chats/{chatId}/members` is limited; the method is removed 2026-09-30, after which the API exposes no ready replacement.
- MAX placement rules require an applicable licence agreement and user-facing legal/support obligations. Whether a hackathon-specific exception/path applies is an open manual question.

### 4.5 Presentation state

The test deck is admirably explicit that runtime/providers/measured results are not confirmed and the validation pilot is `NOT RUN`. However it conflicts with frozen P0 in several places: slide 9 labels Moscow and Saint Petersburg `BETA`; slide 13 puts `2–3 cities`, subscriptions and invite in hackathon/MVP; and slide 1 says `NO-CODE CONCEPT` despite a substantial code baseline. These are final-deck integrity fixes, not reasons to expand implementation.

## 5. KEY FINDINGS

### 5.1 Full compliance matrix

| Requirement | Source | Exact need | Povod component | Status | Current evidence | Missing | Acceptance criterion | Severity |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Primary solo-first happy path | CASE-PREV p.8/p.17 + SOT | Complete one useful scenario | Frozen flow through occurrence/source/save | NEEDS RUNTIME VERIFICATION | SOT + source tree presence | Real E2E in MAX | MAX launch → validated identity → preferences → live Moscow occurrence → source → optional save succeeds | P0 |
| MAX Mini App | MAX-001 + case wording unresolved | Run as MAX mini-app | apps/miniapp + host bot | NEEDS RUNTIME VERIFICATION | Source path exists; docs current | Real attachment and launch | Launch from actual MAX bot on mobile/web | P0 |
| Structural chatbot host | MAX-001 | Mini-app must be attached to chatbot | Bot resource/config | NEEDS RUNTIME VERIFICATION | Official docs only | Actual bot/partner config receipt | Mini-app opens through configured bot | P0 |
| Smart Povod bot notifications | Project P1 / optional | Optional return mechanism | Bot notification flow | DEFER | Concept deck only | Real webhook/send/deeplink if attempted | Only claim after same-build E2E | P1 |
| MAX mobile | Case exact page unresolved + MAX service | Actual client path | Responsive mini-app | NEEDS RUNTIME VERIFICATION | No release-tied screenshot | Real mobile capture | Happy path + abnormal states on real MAX mobile | P0 |
| MAX Web | Case exact page unresolved + MAX rules mention web | Actual web client path | Same mini-app | NEEDS RUNTIME VERIFICATION | No release-tied screenshot | Real MAX Web capture | Happy path on web.max.ru/MAX Web same build | P0 |
| Validated MAX identity | MAX-002 + SOT | Server authenticates WebAppData | packages/platform/auth.ts exists | NEEDS RUNTIME VERIFICATION | Path exists; algorithm not source-audited here | Implementation + negative tests | Valid signature accepted; tampered/duplicate params rejected; own session issued | P0 |
| Docker files | CASE-PREV p.9 | Containerized reproducibility | Dockerfile + compose*.yaml | VERIFIED BY RUNTIME (presence only) | Git baseline tracked files | Project build/start | Clean checkout builds and starts documented stack | P0 |
| Docker host | Operational prerequisite | Working local Docker | Docker Desktop/Engine | VERIFIED BY RUNTIME | hello-world log | None for host | Host can run containers | P2 |
| Build time | CASE-PREV p.9 | Previously extracted <=5 min excluding initial base image pull | Release image | NEEDS RUNTIME VERIFICATION | No project timing | Timed build receipt | Warm-base/defined case method <=300s | P0 |
| README | CASE-PREV p.9 | Reproduction instructions | README.md | VERIFIED BY RUNTIME (presence only) | Tracked; only 11 lines in baseline stat | Content audit | Fresh reviewer can build/run/test solely from README + supplied secrets/test data | P0 |
| Lockfile | CASE-PREV p.9 | Reproducible dependencies | Expected package manager lock | REJECTED at verified baseline | No lockfile in tracked inventory | Current HEAD check + create if absent | Clean deterministic install without tree mutation | P0 |
| .env.example | CASE-PREV p.9 | Non-secret env template | .env.example | VERIFIED BY RUNTIME (presence only) | 20-line tracked template | Completeness/secret audit | All mandatory vars documented, no real secrets | P0 |
| Own API | CASE-PREV p.10 | Working project API | apps/api | VERIFIED BY RUNTIME (presence only) | API source paths | Live smoke | Release HTTPS endpoint passes contract smoke | P0 |
| HTTPS | CASE-PREV p.10 + MAX-001/MAX-006 | Public secured endpoints | Deployment ingress | NEEDS RUNTIME VERIFICATION | Official MAX requires HTTPS; no project TLS receipt | External TLS/URL test | Judge network reaches valid HTTPS endpoints | P0 |
| OpenAPI | CASE-PREV p.10 | OpenAPI 3.0/3.1 (previous extraction) | scripts/openapi.ts | VERIFIED BY RUNTIME (generator presence only) | Tracked script | Generated snapshot + validator + live match | Use case-compatible OAS (recommend 3.1.0) and match live API | P0 |
| DATA-API.yaml | CASE-PREV p.10 | Required artifact per prior extraction | Missing at baseline | REJECTED at verified baseline | Tracked inventory | Exact case schema + file | File exists and validates exactly as case requires | P0 |
| Test data | CASE-PREV p.10 | Judge reproducibility | seed-test.ts + fixtures | VERIFIED BY RUNTIME (presence only) | Tracked scripts/fixtures | Execute fresh seed/reset | Documented deterministic judge path | P0 |
| Test account/access | CASE-PREV p.10 | Judge can enter if auth needed | Judge access procedure | UNKNOWN | No receipt | Manual live check | Incognito/clean device succeeds without author help | P0 |
| Loading | SOT + MAX-008 error resilience | Visible async state | UI | NEEDS RUNTIME VERIFICATION | No screenshot | Fixture/E2E screenshot | No blank/ambiguous wait on major async flows | P1 |
| Empty | SOT | Honest zero results | UI | NEEDS RUNTIME VERIFICATION | No screenshot | Fixture/E2E screenshot | Empty != error and gives recovery | P1 |
| Error | SOT + MAX-008 §4.4 | Controlled errors | UI/API | NEEDS RUNTIME VERIFICATION | Source error module exists only by path | Fault injection | Readable safe error + retry/recovery | P1 |
| Source unavailable | SOT | Do not invent data on provider failure | Provider/UI | NEEDS RUNTIME VERIFICATION | No failure capture | Injected provider outage | Source unavailable shown; no fabricated result | P1 |
| UNKNOWN | SOT | Missing facts stay UNKNOWN | Domain/UI | NEEDS RUNTIME VERIFICATION | Relevant paths exist | Unit + screenshot | No zero/free/fake geo/date substitution | P1 |
| Conditional price | SOT | Price semantics preserved | Price domain/UI | NEEDS RUNTIME VERIFICATION | Price paths exist | Fixture + screenshot | Conditional/raw/unknown price represented honestly | P1 |
| Provenance/source | SOT | Every live item has visible source/origin | Provider/UI | NEEDS RUNTIME VERIFICATION | Source-related paths exist | Live link check | Occurrence shows source and link opens correct primary/allowed source | P0 |
| Moscow live data | Moscow Data Gate | Live provider with gate | Provider adapter/data gate | BLOCKED | Current context: provider not approved | Runtime receipt + legal approval | Gate PASS on release config | P0 |
| Save/repeat login | SOT | Saved state survives return | Persistence/UI | NEEDS RUNTIME VERIFICATION | Persistence source paths exist | Real repeat-login E2E | Save → close → relaunch same MAX user → saved item remains | P1 |
| MAX API compatibility | MAX-003/MAX-004 | Current API endpoint/auth/cert | Platform transport/config | NEEDS SOURCE + RUNTIME VERIFICATION | Official docs current; exact source config not inspected | Static scan + live request | No deprecated platform-api.max.ru; token header; required trust chain works | P1 |
| Group member automation | MAX-005 | Do not rely on removed endpoint | Optional social | REJECTED FOR P0 | Removal 2026-09-30 | None | No P0 dependency; optional share/deeplink only | P0 risk avoided |
| Legal placement agreement | MAX-007 | Valid licence agreement for placement | Partner account/org | UNKNOWN / NEEDS LEGAL VERIFICATION | Official rule | Manual account/legal confirmation | Actual publishing entity eligible and agreement active or documented hackathon exception | P0 if public placement required |
| Legal info/privacy/terms/support | MAX-008/MAX-009 | Mandatory user-facing legal/support info | Mini-app footer/settings/legal pages | UNKNOWN / NEEDS LEGAL VERIFICATION | Official requirements | Manual legal/content check | Required legal/contact/privacy/terms/support available and accurate | P1/P0 placement |
| Security anti-tamper/duplicate/error | MAX-008 §4 | Platform security baseline | Auth/ingress/idempotency/tests | NEEDS RUNTIME VERIFICATION | Security test path exists; not executed here | Security test report | Tamper/duplicate/replay/invalid inputs controlled and evidenced | P1 |
| Presentation scope integrity | SOT vs LOCAL-DECK | Deck must match frozen P0 | Final deck | BLOCKED UNTIL EDITED | Current deck says 2–3 cities; SPb BETA; subscriptions/invite MVP | Revise + claim audit | No unproven cities/features/runtime/measured claims | P1 |
| Presentation pilot evidence | LOCAL-DECK | Do not imply results | Validation slide | CONFIRMED AS NOT RUN | Deck explicitly says NOT RUN | None unless pilot run | Keep as proposed methodology only | P2 |
| Submission format/deadline | Official case | Exact portal/files/timezone | Submission package | UNKNOWN | Case PDF unavailable | Primary case re-read | All exact fields/files/deadline checked from current official case | P0 |
| Scoring weights/platform bonus | Official case | Exact scoring/bonus wording | Presentation/strategy | UNKNOWN / PREVIOUSLY EXTRACTED | Prior result has weights/+0.15 but page not recovered | Primary case re-read | Use exact current wording only | P1/P3 |

### 5.2 Most important interpretation changes

1. **Bot has two meanings.** A chatbot resource is structurally required to host the Mini App; Smart Povod notification behavior remains optional P1. Do not conflate them.
2. **MAX legal requirements are part of technical delivery risk.** A working UI alone may not be publishable/moderatable without the correct partner/account/licence/legal information.
3. **Group-member automation is not a stable primitive.** It is being removed inside the hackathon period; keep social share/deeplink optional.
4. **Latest spec is not automatically the correct submission spec.** OAS 3.2.1 is current, but prior case extraction says 3.0/3.1. Prefer 3.1.0 until the case is recovered.
5. **Host Docker evidence is not project Docker evidence.** This distinction is now explicit.
6. **DATA-API must not be guessed.** Its absence is real at the verified baseline, but exact content must come from the official case.

## 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

| AREA | PREVIOUS CONCLUSION | FINAL VERIFIED CONCLUSION | WHY | SOURCE | IMPACT |
| --- | --- | --- | --- | --- | --- |
| Official case availability | Case requirements were mapped to pages and treated as provisional official requirements. | Still cannot certify them in the final pass because the exact case PDF could not be reopened; all case-specific requirements are downgraded to PREVIOUSLY EXTRACTED / NEEDS PRIMARY RE-VERIFICATION. | Fail-closed source integrity; public search did not recover the case. | CASE-PRIOR-001 | P0: final submission certification remains blocked. |
| Docker status | Docker/project runtime was generally unproven. | Host Docker itself is now VERIFIED BY RUNTIME (hello-world; exact versions), but Povod Docker build/start/timing remains unproven. | Recovered local Docker runtime log. | LOCAL-DOCKER-001 | Removes workstation-install uncertainty, not project compliance. |
| Bot requirement interpretation | Bot was treated mainly as optional/bonus Smart Povod behavior. | Split into two layers: a chatbot resource is structurally required to host a MAX Mini App; Smart Povod notification behavior remains P1/bonus/optional. | Official MAX Mini App docs. | MAX-001 | P0 operational prerequisite without expanding product behavior. |
| MAX identity freshness | Prior security framing could be read as MAX requiring stale auth_date rejection. | Official MAX docs require signature/duplicate checks but do not specify a freshness TTL. Freshness/replay TTL stays a project security recommendation. | Official validation page. | MAX-002 | Improves factual precision; still recommend replay/freshness defense. |
| Group social API | No critical date-specific group-member removal was in the compliance result. | POST /chats/{chatId}/members is limited since 2026-09-09 and removed 2026-09-30. Do not make auto-add a P0 dependency. | Official MAX changelog/method page. | MAX-004;MAX-005 | Strengthens frozen solo-first decision; social auto-add DEFER/REJECT. |
| MAX legal placement | Prior compliance focused mainly on technical case requirements. | Official MAX rules add an operational/legal gate: valid licence agreement for placement plus legal/contact/privacy/terms/support obligations. | Official MAX legal rules/requirements. | MAX-007;MAX-008;MAX-009 | Potential P0 placement blocker; needs human/legal/account check. |
| OpenAPI version | Previous result focused on case-extracted 3.0/3.1. | Current OAS latest is 3.2.1 (2026-09-10), but that is not a reason to move; recommend case-compatible 3.1.0 until exact case reverified. | Official OAS spec. | OAS-001 | Avoid newest-version compatibility risk. |
| Presentation conflict | Previous result flagged roadmap “2–3 cities”. | Conflict is broader: slide 9 also labels SPb BETA; slide 13 puts subscriptions/invite into MVP; slide 1 says NO-CODE CONCEPT despite code baseline. | Full deck re-read. | LOCAL-DECK-001 | P1 integrity/presentation fix required. |
| GitHub Actions | Suggested as useful evidence automation. | Still useful later, but verified baseline has REMOTE=NONE; local PowerShell is the immediately executable canonical evidence runner. | T002 baseline. | LOCAL-GIT-001 | No need to add remote just for research; defer CI until repo/submission setup is known. |
| DATA-API.yaml action | Previous audit said create missing DATA-API.yaml. | Do not fabricate its structure from memory. First recover official case exact instructions, then implement it. | Case source unavailable. | CASE-PRIOR-001;LOCAL-GIT-001 | Prevents compliance-by-guessing. |
| Core scope | Moscow-first solo-first occurrence/source/UNKNOWN/save core. | UNCHANGED AFTER VERIFICATION. | No official/platform finding requires group-first or wider city coverage. | SOT-001;MAX-005 | Keep P0 frozen. |

## 7. CONFIRMED FACTS

- `FACT / VERIFIED BY RUNTIME`: the 2026-09-16 Git baseline exists with the recorded SHA, clean status and no remote.
- `FACT / VERIFIED BY RUNTIME`: at that baseline, no npm/pnpm/yarn lockfile and no `DATA-API.yaml` were in the tracked file inventory.
- `FACT / VERIFIED BY RUNTIME`: Docker host runtime works; project Docker is not proven.
- `FACT / VERIFIED BY OFFICIAL DOCS`: Mini Apps are attached to chatbots, use HTTPS, and current MAX API uses `platform-api2.max.ru`.
- `FACT / VERIFIED BY OFFICIAL DOCS`: MAX WebAppData signature validation algorithm is documented; the docs do not define an `auth_date` TTL.
- `FACT / VERIFIED BY OFFICIAL DOCS`: group-member add is removed 2026-09-30.
- `FACT / VERIFIED BY OFFICIAL DOCS`: MAX placement/content requirements include licence agreement, rights, legal/support info, anti-tamper/duplicate protections and correct error handling.
- `FACT / VERIFIED BY OFFICIAL DOCS`: OpenAPI 3.2.1 was published 2026-09-10; this does not override hackathon-specific allowed versions.
- `FACT / CONFIRMED`: test deck pilot is `NOT RUN`; final deck currently conflicts with Moscow-first/frozen P0.
- `OPEN QUESTION`: exact official case requirements cannot be final-certified until the case is reopened.

## 8. RECOMMENDATIONS

### P0-first order

1. Recover and hash the exact official case. Re-run page-by-page checks before any speculative compliance work.
2. Ask Codex/host to generate a **current** SHA/inventory receipt before changing anything; the latest verified code baseline is two days old.
3. If the lockfile is still absent, use the repository's actual configured package manager to create/commit one; prove frozen clean install.
4. Implement `DATA-API.yaml` only after the exact official case section/schema is available.
5. Build and run the release stack, time Docker using the case-defined method, preserve logs/health/API/OpenAPI evidence.
6. Complete the real MAX path on mobile and web using the same release build; prove server-side WebAppData validation and negative cases.
7. Close the Moscow provider runtime/legal gate; do not substitute sample/demo data for a “live” claim.
8. Verify MAX publishing account/licence/legal surfaces manually.
9. Update the final deck to the frozen P0 and bind every factual runtime/data/result claim to an evidence ID.

### Evidence architecture

Use immutable bundles:

```text
artifacts/evidence/<UTC>-<shortSHA>/
  manifest.json
  checksums.sha256
  00-meta/
  01-dependencies/
  02-build/
  03-startup/
  04-api/
  05-max/
  06-provider/
  07-ui/
  08-tests/
  09-security/
  10-submission/
```

Use local PowerShell as the first orchestrator because the verified repo has no remote. Playwright is useful for deterministic browser/UI states, but **real MAX mobile/Web captures remain separate mandatory evidence**. GitHub Actions becomes useful after a real remote/submission repo exists; it is not a reason to add infrastructure now.

## 9. REJECTED / DEFERRED OPTIONS

| OPTION | STATUS | ADVANTAGES | DISADVANTAGES | RISKS | COMPLEXITY | P0 FIT | SCALE FIT | LICENCE | MAINTENANCE | VERDICT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Frozen solo-first Moscow P0 | KEEP | Lowest scope/risk; aligns with source-of-truth and new group API deprecation | Requires strong Moscow data/runtime proof | Provider gate still open | LOW | EXCELLENT | GOOD via gated adapters | Project/internal + provider-specific | Current project active | KEEP |
| Automatic add-friends-to-group via MAX API | REJECT FOR P0 | Could have automated social continuation | API limited now and removed 2026-09-30; creates brittle dependency | Breaking API during hackathon window | MEDIUM | POOR | POOR | MAX platform terms/API | Deprecated/removal scheduled | REJECT |
| Share/deeplink optional social continuation | KEEP OPTIONAL | Native, low coupling, consistent with solo-first | Still needs real MAX validation | Payload tampering if treated as auth | LOW | GOOD as optional | GOOD | MAX platform rules | Supported current docs | KEEP P1/STRETCH |
| Smart Povod bot notifications | DEFER UNTIL CORE GREEN | MAX-native retention value | Webhook/security/runtime work beyond core | Distracts from P0 evidence | MEDIUM | MEDIUM | GOOD | MAX platform rules | Supported current API | P1 only |
| OpenAPI 3.1.0 for submission | RECOMMEND | Broad tooling support; fits prior case extraction | Not newest OAS | Exact judge validator unknown until case recovered | LOW | EXCELLENT | EXCELLENT | Apache-2.0 spec | Maintained 3.1 line; 3.2.1 current overall | RECOMMEND |
| OpenAPI 3.2.1 for submission | DEFER | Latest OAS with current clarifications | May fall outside case-extracted 3.0/3.1 acceptance | Judge/parser mismatch | LOW-MEDIUM | POOR/UNKNOWN | EXCELLENT | Apache-2.0 | Latest 2026-09-10 | DEFER |
| Local PowerShell evidence orchestrator | RECOMMEND NOW | Works with verified Windows host; no remote required; easy logs/hashes | Needs scripting discipline | Local-only environment bias | LOW | EXCELLENT | GOOD | N/A | Native toolchain | RECOMMEND |
| Playwright automated screenshots | RECOMMEND AS SUPPLEMENT | Deterministic viewport/state screenshots; repeatable | Does not prove MAX client runtime | False confidence if used alone | LOW-MEDIUM | GOOD | GOOD | Apache-2.0 (if added; verify pinned package) | Active project; exact version must be pinned when adopted | RECOMMEND SUPPLEMENT |
| Real MAX mobile + MAX Web capture | MANDATORY EVIDENCE | Directly proves client integration | Partly manual; harder to automate | Device/account setup | MEDIUM | EXCELLENT | N/A | MAX platform terms | Current platform | MANDATORY |
| GitHub Actions evidence CI | DEFER UNTIL REMOTE | Independent environment and repeatability | Verified repo had REMOTE=NONE; setup could consume time | Scope distraction / secrets | MEDIUM | MEDIUM now | GOOD later | GitHub terms; action licences per dependency | N/A until repo hosted | DEFER |
| Create DATA-API.yaml from remembered structure | REJECT | Fast apparent compliance | High risk of wrong format/semantics | Could fail formal check | LOW coding / HIGH compliance | POOR | N/A | N/A | N/A | REJECT |

## 10. RISKS

| Class | Risk | Impact | Mitigation / closure |
| --- | --- | --- | --- |
| P0 | Official case source unavailable | Exact submission format/deadline/scoring/bonus and exact DATA-API semantics cannot be final-certified. | Recover exact case PDF, hash it, perform page-by-page final check. |
| P0 | Project Docker not runtime-proven | Presence of Dockerfile/Compose cannot satisfy a build/run/time requirement. | Clean project build, timed build, compose start, health, logs tied to SHA. |
| P0 | Reproducibility lockfile absent at latest verified source baseline | `package.json` existed without a tracked npm/pnpm/yarn lockfile. | Inspect current HEAD; create correct lockfile via actual configured package manager; clean deterministic install. |
| P0 | DATA-API.yaml absent at verified baseline | Prior case extraction indicates it is required, but exact structure is unavailable. | Recover case first, then implement/validate exact file. |
| P0 | Real MAX runtime evidence absent | No release-tied mobile/web launch, identity or repeat-login evidence. | Real MAX mobile + MAX Web E2E captures and receipts. |
| P0 | Moscow provider gate open | Cannot claim live/current Moscow data while provider runtime/legal approval is open. | Close Moscow data gate/provider receipt and legal gate. |
| P0 conditional | MAX placement account/legal agreement not verified | Official MAX rules require eligible developer/valid licence agreement; hackathon exception not established. | Manual check partner account/entity/agreement/hackathon terms. |
| P1 | MAX legal info/privacy/support not verified | May block/complicate moderation/placement and creates legal integrity risk. | Legal/manual checklist; add exact user-facing docs/support. |
| P1 | Presentation contradicts frozen scope | 2–3 cities, SPb BETA, subscriptions/invite MVP can overclaim current P0. | Rewrite final deck from source-of-truth; evidence-lock all claims. |
| P1 | Breaking group-member API | Auto-add endpoint is removed 30 Sep 2026. | No P0 dependency; use optional sharing/deeplinks only. |
| P1 | Security evidence gap | Source paths/tests exist, but exact implementation and run results are not proven. | Run tamper/duplicate/IDOR/replay/input tests; preserve reports. |
| P2 | OpenAPI newest-version temptation | Switching to 3.2.1 could exceed judge-supported range despite being current. | Stay on 3.1.0 until official case/validator proves otherwise. |
| Operational | REMOTE=NONE at verified baseline | CI/submission repo assumptions are unproven. | Check official submission format before adding remote; local evidence runner is sufficient now. |
| Integrity | NO-CODE CONCEPT label conflicts with code reality | Can confuse judges about implementation status. | Remove/relabel in final deck. |

## 11. BLOCKERS

### P0 / release certification blockers

1. Exact official case unavailable for final re-read.
2. Current repository HEAD/runtime state after 2026-09-16 not independently evidenced.
3. Dependency lockfile absent at latest verified baseline (must confirm current HEAD).
4. `DATA-API.yaml` absent at latest verified baseline; exact official schema/instructions unavailable.
5. Project Docker build/start/build-time evidence absent.
6. Public HTTPS/API/OpenAPI runtime evidence absent.
7. Real MAX mobile and MAX Web E2E evidence absent.
8. Moscow live provider/data/legal gate open.
9. Judge/test access path not evidenced.
10. MAX publishing account/licence/hackathon exception status unknown if public placement is required.

### P1 blockers to a defensible jury story

- Final deck scope/claim conflicts.
- MAX legal/privacy/support surfaces not verified.
- Security test paths exist but executed release evidence is absent.

## 12. OPEN QUESTIONS

- What is the exact current revision/hash of the official hackathon case?
- What are the exact submission portal fields, repository/public-access expectations, deadline and timezone?
- What is the exact `DATA-API.yaml` schema/content requirement?
- Are OpenAPI 3.0 and 3.1 the only accepted versions, and how is it validated?
- Is there a special MAX partner/licence path for hackathon finalists, or do ordinary placement rules apply unchanged?
- What is the current repository HEAD and has a lockfile/DATA-API been added since 2026-09-16?
- What is the exact current deployment URL/HTTPS certificate state?
- Is a judge/test account needed, or is valid MAX identity enough?
- Has Moscow provider runtime v1.4/legal approval closed in the providers workstream?
- Does the final submission need a remote Git repository? The verified local repo currently has none.

## 13. REQUIRED RUNTIME TESTS

| ID | Test | Procedure | Evidence purpose | Priority |
| --- | --- | --- | --- | --- |
| RT-001 | Current Git state | git rev-parse HEAD; git status --porcelain; git ls-files; dependency lockfile/data-api presence | Proves exact release source identity and closes stale-baseline risk | P0 |
| RT-002 | Deterministic dependency install | Fresh clone/worktree + configured package manager frozen install; ensure no tree diff | Reproducibility | P0 |
| RT-003 | Docker build timing | Pre-pull allowed base images separately; timed release build; record elapsed <= case threshold if confirmed | Case build gate | P0 |
| RT-004 | Docker startup/readiness | docker compose config; up -d --wait; ps; logs; health/readiness | Runtime availability | P0 |
| RT-005 | HTTPS/API smoke | External network TLS + health + core endpoints + failure response | API/HTTPS gate | P0 |
| RT-006 | OpenAPI generation/validation | Generate snapshot; validate OAS 3.1.0; compare listed routes to running API | API documentation integrity | P0 |
| RT-007 | DATA-API validation | Run exact validator/schema from official case once recovered | Formal case artifact | P0 |
| RT-008 | MAX initData valid | Real MAX launch data → server validation → own session | Identity happy path | P0 |
| RT-009 | MAX initData tamper/duplicates | Mutate hash/user/duplicate params; all rejected | Official validation/security requirement | P0/P1 |
| RT-010 | Replay/freshness hardening | Replay same valid launch/session outside chosen policy window | Project security recommendation, not explicit MAX TTL | P1 |
| RT-011 | MAX mobile 360 | Real MAX mobile, core happy path and screenshots | Client proof | P0 |
| RT-012 | MAX mobile 390 | Real MAX mobile, core happy path and screenshots | Client proof | P0 |
| RT-013 | MAX mobile 430 | Real MAX mobile, core happy path and screenshots | Client proof | P0 |
| RT-014 | MAX Web | Real MAX Web, same build/core path | Client proof | P0 |
| RT-015 | Occurrence/source | Live Moscow occurrence has date/time/place/price-or-UNKNOWN/source and link works | Core product truthfulness | P0 |
| RT-016 | Empty/loading/error/source unavailable | Deterministic fixtures/fault injection + screenshots | Required abnormal states/error handling | P1 |
| RT-017 | UNKNOWN/conditional price | Fixtures verify no false free/zero/fake coordinates and correct conditional disclosure | Data safety | P1 |
| RT-018 | Save/repeat login | Save event → close MAX → relaunch → saved state persists | P0 optional save / retention correctness | P1 |
| RT-019 | Provider receipt | Live provider fetch + raw hashes/counts/field coverage/freshness/source-link sampling | Moscow Data Gate | P0 |
| RT-020 | MAX API current config | Static/runtime check for platform-api2, Authorization header, certificate trust; no removed methods | Breaking-change compatibility | P1 |
| RT-021 | Webhook if Smart Povod attempted | HTTPS subscription, X-Max-Bot-Api-Secret verification, replay/idempotency, real notification/deeplink | P1 bot evidence only | P1 |

## 14. REQUIRED MANUAL / LEGAL CHECKS

| ID | Check | Owner | Priority |
| --- | --- | --- | --- |
| MAN-001 | Recover exact official case PDF/revision and rerun all page checks | Owner/team lead | P0 |
| MAN-002 | Confirm exact submission deadline/timezone/portal/package/repo requirements | Owner/team lead | P0 |
| MAN-003 | Confirm whether live MAX placement for hackathon uses normal partner legal/licence rules or special organizer path | Team lead + organizer/MAX support | P0 conditional |
| MAN-004 | Confirm actual publishing entity/account eligibility and active MAX licence agreement | Authorized team member/legal | P0 conditional |
| MAN-005 | Review required developer identity/contact/privacy/terms/support and age classification if applicable | Legal/manual | P1/P0 placement |
| MAN-006 | Provider legal gate (KudaGo/alternative) for actual fields/images/descriptions/deeplinks/cache | Providers/legal workstream | P0 |
| MAN-007 | Final deck claim-by-claim sign-off against evidence manifest | Product/presentation owner | P1 |
| MAN-008 | Judge/test account path from clean device/incognito | Non-developer teammate | P0 |

Important legal precision: this report is a technical/compliance research artifact, **not legal advice**. MAX's published rules are primary evidence of platform obligations, but the project's exact legal posture, publishing entity and provider/content rights require an authorized human/legal check.

## 15. EXACT CHANGES FOR «ПОВОД»

### Code/repository (only after current HEAD inspection)

- Add/commit the actual package-manager lockfile if still missing.
- Add exact `DATA-API.yaml` only from recovered official case instructions.
- Add evidence scripts under a small `scripts/evidence/` surface rather than a new service.
- Ensure current MAX API base URL is `platform-api2.max.ru`; remove/query-token patterns if any.
- Ensure WebAppData validation implements duplicate-key/hash checks and documented HMAC logic; add negative tests.
- Add project-defined freshness/replay/session controls as security hardening, clearly separate from official MAX algorithm.
- Remove any P0 dependency on `POST /chats/{chatId}/members`.
- Ensure source links are allowlisted/validated and provider failures produce `source unavailable`, never fabricated live data.
- Expose deterministic test fixtures for loading/empty/error/UNKNOWN/conditional-price states without presenting fixtures as live provider results.
- Add a build/version endpoint or non-user-facing evidence metadata if needed to bind screenshots/logs to SHA.

### Documentation

- Expand/audit README for clean judge reproduction.
- Keep `.env.example` secret-free and complete.
- Add a one-command release evidence runbook.
- Add legal/privacy/terms/support links/surfaces required for the actual publishing path.

### Presentation

- Replace `2–3 города` MVP with **Москва — proven demo city; additional cities only after data gate**.
- Remove/qualify Saint Petersburg `BETA` unless its gate is independently proven.
- Move subscriptions/invite out of mandatory MVP and into P1/stretch consistent with source-of-truth.
- Remove or relabel `NO-CODE CONCEPT` so it cannot imply the submitted solution lacks code.
- Keep pilot `NOT RUN` until actually executed.
- Only show Smart Povod bot as working if webhook/send/deeplink evidence exists.

## 16. IMPACT ON P0 / P1 / STRETCH

### P0

No new product features. Added/clarified **evidence and platform-operation gates** only:
- structural chatbot attachment for Mini App;
- current MAX API/identity compatibility;
- Docker/API/HTTPS/OpenAPI/DATA-API reproducibility;
- real MAX mobile/Web proof;
- Moscow data gate;
- publishing/legal readiness if needed by submission.

### P1

- Smart Povod bot notification flow after core is stable.
- Basic follow/subscription only after frozen P0 evidence is green.
- Enhanced automated evidence/CI after repository remote exists.

### STRETCH

- second city only after its own data gate;
- optional sharing/invite/deeplink continuation;
- no automated group-member-add dependency.

## 17. WHAT NOT TO DO

- Do not expand to 2–3 cities to match the old deck.
- Do not make group creation/invite the entry scenario.
- Do not rely on the group-member-add API scheduled for removal.
- Do not call browser/Playwright screenshots “MAX mobile proof”.
- Do not call source-file presence “runtime acceptance”.
- Do not fabricate `DATA-API.yaml` from remembered requirements.
- Do not switch to OpenAPI 3.2 merely because it is newer.
- Do not add CI/cloud/queue technology solely for evidence aesthetics.
- Do not claim provider freshness, personalization uplift, speed or scale without the matching measured artifact.
- Do not treat `initDataUnsafe` or `startapp` payload as authorization.
- Do not claim an `auth_date` TTL is an official MAX requirement; define it as project hardening.
- Do not remove `UNKNOWN`/source-unavailable states to make the demo look cleaner.

## 18. SELF-CRITIQUE / RED TEAM

### What if the main recommendation is wrong?

**Counterargument:** perhaps the team should spend all remaining time coding more features instead of evidence.  
**Red-team result:** rejected. The current gap is demonstrability, not conceptual breadth. The verified baseline already has substantial source structure, while T002 itself says runtime/E2E are unproven. New features increase the surface that must be proven.

**Counterargument:** perhaps the missing case PDF is not a real blocker because earlier notes captured it.  
**Red-team result:** rejected for final compliance certification. Earlier extraction is useful, but exact submission deadlines, file formats and schema wording are precisely the areas where a small transcription error can cause formal failure. Primary re-read has higher expected value than more implementation.

**Counterargument:** OpenAPI 3.2.1 is newer, so using it shows modernity.  
**Red-team result:** rejected. Compliance targets the judge's validator, not novelty. The current latest version is evidence of ecosystem change; it does not supersede case-specific accepted versions.

**Counterargument:** Smart Povod bot should become mandatory because Mini Apps require a chatbot.  
**Red-team result:** rejected. The host chatbot is structural infrastructure; notification product behavior is separate. Conflating them silently expands P0.

**Counterargument:** platform rules/licence are outside hackathon scope.  
**Red-team result:** unproven. A hackathon may provide a special path, but no public/primary evidence of an exception was found. Therefore manual confirmation is required rather than assuming either ordinary or exempt treatment.

**Counterargument:** automate all screenshots with Playwright and skip device QA.  
**Red-team result:** rejected. That proves the web app in a browser, not the exact MAX client/bridge integration. Keep automation as supplement.

### Hidden costs checked

- New remote/CI setup can consume time and secret-management effort; defer until submission format is known.
- Real MAX legal/moderation requirements can become late blockers if ignored.
- Provider content rights and MAX third-party rights obligations intersect; keep provider legal gate separate but blocking for live data.
- Group member API removal creates near-term technical debt if implemented now.
- Current repo inventory is stale by two days; all code-specific actions must start with a new host receipt.

## 19. MISSING AREAS CHECK

### Areas that could have been forgotten and were additionally checked

- MAX ordinary placement/licence/legal/support obligations.
- Distinction between structural host bot and optional Smart Povod behavior.
- September 2026 removal of group-member-add API.
- Current OpenAPI spec release vs hackathon-specific allowed version.
- Host Docker runtime vs project Docker runtime.
- Deck claims beyond the already-known `2–3 cities` conflict (SPb BETA, subscriptions/invite MVP, NO-CODE CONCEPT).
- Whether official validation actually requires an `auth_date` TTL (it does not state one).

### Still impossible to close without external evidence

- Exact official case and revision.
- Current HEAD/source semantics after 2026-09-16.
- Runtime build/API/MAX/provider behavior.
- Exact submission portal/deadline/format.
- Partner/licence/hackathon exception/account state.
- Provider licensing approval.

### Requires runtime

All items RT-001–RT-021 as applicable, especially Docker, HTTPS/API/OpenAPI, real MAX identity/mobile/web, provider receipt, state screenshots and repeat login.

### Requires human/manual decision

Publishing entity/account, final deck wording, submission format interpretation, judge account path, whether to attempt P1 Smart Povod after P0 is green.

### Requires legal consultation/authorized review

MAX licence agreement/app legal information/privacy/terms/support; provider rights/caching/images/descriptions; actual personal-data policy. This report does not substitute for counsel.

### Requires Codex/host

Current repo receipt, lockfile/config audit, source-level MAX validation/base-URL review, build/runtime tests, evidence scripts and exact generated artifacts.

### Can be considered closed

- P0 remains solo-first and Moscow-first.
- Social auto-add must not become a P0 dependency.
- Runtime claims require runtime evidence.
- The deck's validation pilot is not a measured result today.
- Docker host itself is usable.
- MAX current API/domain/group-member changes and published legal requirements are verified from official sources.

## 20. SOURCE MANIFEST

See `SOURCE_MANIFEST.csv` and `SOURCE_MANIFEST.json` for the complete machine-readable manifest. Primary-source URLs are preserved there. No copyrighted case PDF or full external docs are copied into this archive.

Source count: **21**.

## 21. FINAL CHECKLIST

### Research quality gate

- [x] Major claims represented in `CLAIMS_EVIDENCE.csv` / `FACT_CHECK_MATRIX.csv`.
- [x] Time-sensitive MAX/OpenAPI facts rechecked on 2026-09-18 using primary sources.
- [x] Official sources preferred.
- [x] Current MAX breaking changes checked.
- [x] OpenAPI GitHub/spec licence/activity checked where relevant.
- [x] No project runtime claim upgraded from source presence.
- [x] Frozen P0 not silently expanded.
- [x] Source-of-truth conflicts called out.
- [x] Recommendations are P0/evidence/risk oriented.
- [x] Rejected/deferred options listed.
- [x] Open questions/runtime/manual/legal checks listed.
- [x] Source manifest + delta + machine summary + CODEX actions included.
- [ ] Exact official case reread — **OPEN BLOCKER**.
- [ ] Current release SHA/runtime evidence — **OPEN BLOCKER**.

### Submission Definition of Done

- [ ] Official case hash/revision recorded; page-by-page matrix has zero mandatory UNKNOWN.
- [ ] Final SHA frozen and clean.
- [ ] Correct lockfile committed; frozen install is deterministic.
- [ ] Docker project build/start passes; timed build meets exact case limit.
- [ ] HTTPS API reachable from external/judge network.
- [ ] Case-compatible OpenAPI snapshot validates and matches live routes.
- [ ] Exact `DATA-API.yaml` exists and validates.
- [ ] Test data/judge access works from clean environment.
- [ ] Moscow provider/data/legal gate PASS.
- [ ] Real MAX mobile 360/390/430 evidence tied to release.
- [ ] Real MAX Web evidence tied to release.
- [ ] Valid/tampered identity tests PASS.
- [ ] Loading/empty/error/source-unavailable/UNKNOWN/conditional-price evidence exists.
- [ ] Source link/provenance works for live occurrence.
- [ ] Save/relaunch/repeat-login works.
- [ ] Security/integration tests PASS on same SHA.
- [ ] MAX publishing/legal readiness confirmed if required.
- [ ] Final deck has zero claims without evidence IDs.
- [ ] Submission package opened/reverified after upload if portal permits.
