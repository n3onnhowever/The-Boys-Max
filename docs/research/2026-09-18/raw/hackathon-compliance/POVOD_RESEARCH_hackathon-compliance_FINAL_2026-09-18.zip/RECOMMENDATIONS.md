# Recommendations

## Now / P0 risk reduction

1. Recover the exact official case PDF, record SHA-256 and revision/date, and rerun the page-level compliance matrix.
2. Capture current repo SHA/status/file inventory before modifying the two-day-old verified baseline.
3. Confirm actual package manager and create/commit its lockfile only if still absent; prove frozen install.
4. Implement `DATA-API.yaml` only after exact case instructions are visible.
5. Build/start the project stack; record timed build, image inspect, compose config/ps/logs, health and API smoke.
6. Generate a case-compatible OpenAPI 3.1.0 snapshot and validate it against running routes.
7. Run real MAX mobile + MAX Web core E2E with server-side WebAppData validation.
8. Close Moscow provider runtime/legal gate and preserve a provider receipt.
9. Verify MAX publishing entity/account/licence/legal information/support path.
10. Rewrite final deck to Moscow-first P0 and evidence-lock each claim.

## Evidence workflow

Use `artifacts/evidence/<UTC>-<shortSHA>/` with immutable manifest and SHA-256 checksums. Use local PowerShell first; Playwright only for supplemental deterministic browser states; real MAX captures separately. CI can be added after a real remote exists and only if it reduces submission risk.

## P1 after P0 green

- Smart Povod bot webhook/notification/deeplink.
- Basic follow/subscription.
- CI mirror of the local evidence runner.

## Defer/reject

- Second city before its own gate.
- Automatic group-member add.
- New infra solely for “scale”.
- OAS 3.2 migration for novelty.
- User-validation outcome claims while pilot is NOT RUN.
