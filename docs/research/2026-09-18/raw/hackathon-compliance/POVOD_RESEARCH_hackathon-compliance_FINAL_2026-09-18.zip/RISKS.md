# Risks

| Class | Risk | Impact | Mitigation / closure |
| --- | --- | --- | --- |
| P0 | Official case source unavailable | Exact submission format/deadline/scoring/bonus and exact DATA-API semantics cannot be final-certified. | Recover exact case PDF, hash it, perform page-by-page final check. |
| P0 | Project Docker not runtime-proven | Presence of Dockerfile/Compose cannot satisfy a build/run/time requirement. | Clean project build, timed build, compose start, health, logs tied to SHA. |
| P0 | Reproducibility lockfile absent at latest verified source baseline | `package.json` existed without a tracked npm/pnpm/yarn lockfile. | Inspect current HEAD; create correct lockfile via actual configured package manager; clean deterministic install. |
| P0 | DATA-API.yaml absent at verified baseline | Prior case extraction indicates it is required, but exact structure is unavailable. | Recover case first, then implement/validate exact file. |
| P0 | Real MAX runtime evidence absent | No release-tied mobile/web launch, identity or repeat-login evidence. | Real MAX mobile + MAX Web E2E captures and receipts. |
| P0 | Moscow provider gate open | Cannot claim live/current Moscow data while provider runtime/legal approval is open. | Close Moscow data gate/provider receipt and legal gate. |
| P0 conditional | MAX placement account/legal agreement not verified | Official MAX rules require eligible developer/valid licence agreement; hackathon exception not established. | Manual check partner account/entity/agreement/hackathon terms. |
| P1 | MAX legal info/privacy/support not verified | May block/complicate moderation/placement and creates legal integrity risk. | Legal/manual checklist; add exact user-facing docs/support. |
| P1 | Presentation contradicts frozen scope | 2–3 cities, SPb BETA, subscriptions/invite MVP can overclaim current P0. | Rewrite final deck from source-of-truth; evidence-lock all claims. |
| P1 | Breaking group-member API | Auto-add endpoint is removed 30 Sep 2026. | No P0 dependency; use optional sharing/deeplinks only. |
| P1 | Security evidence gap | Source paths/tests exist, but exact implementation and run results are not proven. | Run tamper/duplicate/IDOR/replay/input tests; preserve reports. |
| P2 | OpenAPI newest-version temptation | Switching to 3.2.1 could exceed judge-supported range despite being current. | Stay on 3.1.0 until official case/validator proves otherwise. |
| Operational | REMOTE=NONE at verified baseline | CI/submission repo assumptions are unproven. | Check official submission format before adding remote; local evidence runner is sufficient now. |
| Integrity | NO-CODE CONCEPT label conflicts with code reality | Can confuse judges about implementation status. | Remove/relabel in final deck. |
