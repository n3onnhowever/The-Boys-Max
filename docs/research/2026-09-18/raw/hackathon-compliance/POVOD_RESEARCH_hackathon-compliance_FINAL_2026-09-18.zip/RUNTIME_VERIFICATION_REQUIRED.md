# Runtime Verification Required

| ID | Test | Procedure | Evidence purpose | Priority |
| --- | --- | --- | --- | --- |
| RT-001 | Current Git state | git rev-parse HEAD; git status --porcelain; git ls-files; dependency lockfile/data-api presence | Proves exact release source identity and closes stale-baseline risk | P0 |
| RT-002 | Deterministic dependency install | Fresh clone/worktree + configured package manager frozen install; ensure no tree diff | Reproducibility | P0 |
| RT-003 | Docker build timing | Pre-pull allowed base images separately; timed release build; record elapsed <= case threshold if confirmed | Case build gate | P0 |
| RT-004 | Docker startup/readiness | docker compose config; up -d --wait; ps; logs; health/readiness | Runtime availability | P0 |
| RT-005 | HTTPS/API smoke | External network TLS + health + core endpoints + failure response | API/HTTPS gate | P0 |
| RT-006 | OpenAPI generation/validation | Generate snapshot; validate OAS 3.1.0; compare listed routes to running API | API documentation integrity | P0 |
| RT-007 | DATA-API validation | Run exact validator/schema from official case once recovered | Formal case artifact | P0 |
| RT-008 | MAX initData valid | Real MAX launch data → server validation → own session | Identity happy path | P0 |
| RT-009 | MAX initData tamper/duplicates | Mutate hash/user/duplicate params; all rejected | Official validation/security requirement | P0/P1 |
| RT-010 | Replay/freshness hardening | Replay same valid launch/session outside chosen policy window | Project security recommendation, not explicit MAX TTL | P1 |
| RT-011 | MAX mobile 360 | Real MAX mobile, core happy path and screenshots | Client proof | P0 |
| RT-012 | MAX mobile 390 | Real MAX mobile, core happy path and screenshots | Client proof | P0 |
| RT-013 | MAX mobile 430 | Real MAX mobile, core happy path and screenshots | Client proof | P0 |
| RT-014 | MAX Web | Real MAX Web, same build/core path | Client proof | P0 |
| RT-015 | Occurrence/source | Live Moscow occurrence has date/time/place/price-or-UNKNOWN/source and link works | Core product truthfulness | P0 |
| RT-016 | Empty/loading/error/source unavailable | Deterministic fixtures/fault injection + screenshots | Required abnormal states/error handling | P1 |
| RT-017 | UNKNOWN/conditional price | Fixtures verify no false free/zero/fake coordinates and correct conditional disclosure | Data safety | P1 |
| RT-018 | Save/repeat login | Save event → close MAX → relaunch → saved state persists | P0 optional save / retention correctness | P1 |
| RT-019 | Provider receipt | Live provider fetch + raw hashes/counts/field coverage/freshness/source-link sampling | Moscow Data Gate | P0 |
| RT-020 | MAX API current config | Static/runtime check for platform-api2, Authorization header, certificate trust; no removed methods | Breaking-change compatibility | P1 |
| RT-021 | Webhook if Smart Povod attempted | HTTPS subscription, X-Max-Bot-Api-Secret verification, replay/idempotency, real notification/deeplink | P1 bot evidence only | P1 |

## Evidence naming

Each run should create `artifacts/evidence/<UTC>-<shortSHA>/manifest.json` plus `checksums.sha256`. Never overwrite a prior run. Redact bot tokens, cookies, initData and personal data; store only minimal test receipts.
