# OpenAPI version verification

Official OAS v3.2.1 is the latest published specification as of 2026-09-18; publication date 2026-09-10; Apache-2.0. Official repository `OAI/OpenAPI-Specification` is active, default branch `main`, not archived.

Hackathon decision: do not chase latest solely for modernity. The prior official-case extraction recorded acceptance of OpenAPI 3.0/3.1. Until the exact case is reopened, use a broadly compatible `openapi: 3.1.0` target for the submission snapshot rather than 3.2.x.
