# Presentation integrity verification

Source: `POVOD_TEST_DECK_V1.pptx`, 2026-09-17.

Good/keep:
- deck explicitly says runtime/providers/measured results are not confirmed;
- solo-first/social-next is explicit;
- validation slide explicitly says `NOT RUN`.

Conflicts/gaps to fix before final deck:
- slide 9: Moscow BETA and Saint Petersburg BETA, while frozen P0 is one proven Moscow demo city;
- slide 13: hackathon/MVP says `2–3 cities`, basic subscriptions and invite; conflicts with scope freeze unless separately evidenced/gated;
- slide 1: `NO-CODE CONCEPT` can conflict with the substantial code baseline and confuse jury interpretation;
- runtime-sounding promises (MAX login, cross-session personalization, bot notification) must be evidence-locked before being presented as working.
