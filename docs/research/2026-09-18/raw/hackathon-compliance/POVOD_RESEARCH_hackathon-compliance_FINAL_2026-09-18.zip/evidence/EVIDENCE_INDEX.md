# Evidence Index

This archive intentionally does not redistribute the official case PDF or full external documentation. Evidence is represented by source identifiers, exact URLs and concise factual notes.

- `official_case_availability.md` — records the primary-source blocker.
- `max_platform_verification_2026-09-18.md` — date-sensitive official MAX findings.
- `local_git_baseline_verification.md` — SHA/inventory/runtime-claim boundary.
- `docker_host_runtime_verification.md` — host Docker evidence and its limit.
- `presentation_integrity_verification.md` — exact deck conflicts to fix.
- `openapi_version_verification.md` — current OAS version and submission recommendation.
