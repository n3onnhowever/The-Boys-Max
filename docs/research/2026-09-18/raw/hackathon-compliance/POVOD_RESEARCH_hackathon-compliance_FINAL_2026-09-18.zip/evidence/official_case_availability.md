# Official case availability

Status: **OPEN BLOCKER**

The exact official 22-page hackathon case used in earlier research could not be found/reopened through the available File Library searches during this final pass, and targeted public web searches using distinctive terms (`DATA-API.yaml`, Docker/OpenAPI/build-time/scoring phrases) did not recover an authoritative copy.

Therefore:
- previous page mappings p.8/p.9/p.10/p.17/p.19 are preserved as `PREVIOUSLY EXTRACTED`;
- exact submission deadline/timezone/format, scoring table, platform bonus and exact DATA-API semantics are not upgraded to `CONFIRMED`;
- no placeholder/fabricated DATA-API content is recommended.

Closure: recover the exact case PDF, calculate SHA-256, record revision/date, then run a page-by-page delta against `FINAL_REPORT.md`.
