# MAX platform verification — 2026-09-18

Primary sources: dev.max.ru official documentation.

Verified facts:
- Mini Apps work only inside chatbots and require HTTPS.
- Mini App startapp payload: up to 512 characters (allowed alphabet documented); bot start payload: up to 128.
- WebAppData signature validation uses the documented HMAC-SHA256 process; duplicate platform params/hash are explicitly handled.
- The page exposes `auth_date` as a Unix timestamp but does not specify a freshness TTL.
- Current API base is `platform-api2.max.ru`; token via query is not supported; use Authorization header.
- `POST /chats/{chatId}/members` is limited from 2026-09-09 and removed 2026-09-30.
- Webhook subscription URL must be HTTPS. `secret` is optional in the schema and recommended; it arrives as `X-Max-Bot-Api-Secret`.
- Placement rules require an applicable licence agreement; current requirements include legal/contact/privacy/terms/support information, anti-tamper/duplicate protection, malicious-code protection and correct error handling.

URLs are in SOURCE_MANIFEST.*.
