# Gaps and Open Questions

## Hard source gap

The exact official case PDF/revision was not available to this final pass. Previously extracted page mappings remain useful but cannot serve as final primary certification.

## Runtime gaps

- Current HEAD vs 2026-09-16 baseline.
- Frozen dependency install.
- Povod Docker build/start/time.
- HTTPS/API health/smoke.
- Generated OpenAPI/live-route match.
- Exact DATA-API validation.
- Real MAX mobile/Web and identity.
- Moscow provider/live occurrence/provenance.
- Save/relogin and abnormal UI states.

## Manual/legal gaps

- Exact submission portal/deadline/timezone/repo requirements.
- MAX publishing account/entity/licence agreement/hackathon exception.
- Mandatory developer legal/contact/privacy/terms/support content.
- Provider content/data rights.
- Judge/test account/access.

## Human decisions

- Whether to spend remaining time on P1 Smart Povod only after P0 evidence is green.
- Final presentation wording after evidence run.
- Whether/when to add a remote and CI.
