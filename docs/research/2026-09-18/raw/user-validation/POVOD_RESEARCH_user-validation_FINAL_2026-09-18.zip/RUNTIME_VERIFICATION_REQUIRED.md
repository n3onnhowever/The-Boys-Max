# Runtime Verification Required

**This archive performed no Povod runtime execution. All items below remain `NEEDS RUNTIME VERIFICATION` unless separate project evidence already proves them.**

## MAX identity/session
- Launch Mini App from current supported MAX client.
- Send `initData`/WebAppData to backend and validate signature server-side.
- Reject tampered hash.
- Enforce intended freshness policy for `auth_date`.
- Create/use own application session after validation.
- Confirm `initDataUnsafe` is never an authority.

## P0 end-to-end
- Interests/constraints load.
- Live Moscow events load from approved provider.
- Event card resolves to a concrete occurrence.
- Correct date/time/timezone/place shown.
- Known/free/conditional/UNKNOWN price states remain distinct.
- Source/provenance visible.
- Explicit source click reaches exact source page.
- Save persists as designed.

## MAX client matrix
Test current:
- iOS;
- Android;
- web.

Capture:
- screenshots;
- client/version;
- timestamp;
- success/failure;
- console/backend logs where safe;
- no secrets/PII.

## Deep links/share
- `startapp` payload opens intended mini-app context.
- Treat payload as opaque/context only, never authorization.
- `openLink` works after user click.
- `shareMaxContent` works to dialog.
- If group share is used, user is already a member; no auto-add dependency.
- Verify web behavior separately.

## Failure states
- loading;
- empty;
- provider error;
- source unavailable;
- stale data;
- missing price;
- missing optional location details;
- sold-out/cancelled if provider exposes state;
- save failure/retry.

## Current MAX compatibility
- all Bot API calls use `platform-api2.max.ru`;
- certificate/trust requirements satisfied;
- no call to removed/deprecated group-member logic in required flows;
- webhook path preferred for production-like bot updates if applicable.

## Evidence naming suggestion
Store runtime proof under project evidence, e.g.
- `max_runtime_ios_<date>.md`
- `max_runtime_android_<date>.md`
- `max_runtime_web_<date>.md`
- `p0_e2e_receipt_<date>.json`
- screenshots/log excerpts with secrets redacted.
