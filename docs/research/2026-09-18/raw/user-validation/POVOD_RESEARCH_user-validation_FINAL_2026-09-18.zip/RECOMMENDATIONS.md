# Recommendations — Actionable Only

## P0 — keep / tighten

1. **No P0 feature additions.**
2. Preserve Event → Occurrence separation.
3. Apply hard constraints before ranking; do not “score through” budget/time/location failures.
4. Preserve price state:
   - known price → show it;
   - explicitly free → show “Бесплатно”;
   - missing → human-readable unknown;
   - conditional/raw → preserve source text/state.
5. Keep provenance/source visible.
6. Open the primary/source page through explicit user action.
7. Keep Save simple and persistent.
8. Preserve loading / empty / error / source-unavailable states.
9. Keep social optional and user-initiated.
10. Keep map/group planner/new provider/AI agent out of P0.

## P1

- opt-in follow artist/topic;
- bounded Smart Povod: explicit conditions → 1–3 real matching occurrences → source;
- targeted reminders only after explicit opt-in / follow state.

## Before public/demo claims

- run MAX device/runtime matrix;
- verify partner account/licence/moderation;
- finish provider legal/runtime gate;
- clear naming “Повод” manually;
- ensure deck labels this research as desk/public-evidence validation.

## Research wording

Good:
> Public evidence shows that event discovery spans multiple surfaces and that concrete logistics such as date, time, place and price shape the decision journey.

Avoid:
> Russian users are frustrated by fragmented discovery.

Good:
> Conversational discovery is an emerging product pattern.

Avoid:
> Users want Smart Povod.
