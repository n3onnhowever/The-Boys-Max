# CODEX ACTIONS — User Validation / UX Evidence Handoff

## Hard constraint

**Do not redesign or expand the product from this archive.**  
The frozen P0 remains authoritative.

## Repository-path limitation

The repository/source tree was not accessible in this research chat. Therefore exact physical filenames cannot be safely invented.

**Codex first action:** inventory the current repository and map the logical targets below to real files. Record that mapping before changing code.

## Logical code/config targets

1. **MAX launch/auth handler**
   - confirm server-side WebAppData validation;
   - reject duplicate/malformed parameters and invalid hash;
   - enforce freshness policy if canonical code/spec requires it;
   - issue/use own application session;
   - never trust `initDataUnsafe` or `startapp` as authorization.

2. **MAX API client/config**
   - search for `platform-api.max.ru`;
   - replace only where the canonical implementation still uses the obsolete domain;
   - ensure current `platform-api2.max.ru` usage;
   - verify cert/trust handling per deployment environment;
   - search for `/chats/{chatId}/members` dependency and remove from any required path.

3. **Event/Occurrence domain model**
   - ensure Event and Occurrence remain distinct;
   - preserve provider IDs and stable occurrence identity rules already in canonical contract;
   - no synthetic date/time/location/end time.

4. **Price normalization/presentation**
   - explicit `free`, `known`, `conditional`, `unknown` semantics;
   - preserve raw source price text where canonical contract requires it;
   - never map null/missing to `0`;
   - UI copy should be human-readable rather than literal internal enum unless design already specifies otherwise.

5. **Hard-constraint filter/ranker**
   - PASS/FAIL/UNKNOWN logic;
   - FAIL is not compensated by ranking score;
   - UNKNOWN follows canonical policy, not guessed value.

6. **Provenance/source**
   - validate/normalize source URL;
   - visible source in event detail/card per product spec;
   - use explicit user click for external open;
   - graceful `source-unavailable` state.

7. **Save**
   - idempotent save/unsave;
   - persistence across refresh/relaunch/re-login according to current product contract;
   - clear error state if save fails.

8. **Optional share**
   - use existing MAX-native share/deep-link path only if already in accepted scope;
   - no auto group-member addition;
   - no mandatory group flow.

9. **P1 guards**
   - do not implement follow/Smart Povod until P0 acceptance passes unless already scheduled;
   - Smart Povod must return only real structured occurrences and obey hard constraints;
   - no generated date/place/price.

## Tests Codex should add or verify

### Unit
- unknown price != zero/free;
- conditional/raw price preserved;
- no fake coordinates/time;
- hard filter FAIL cannot rank;
- Event vs Occurrence identity;
- source URL validation;
- startapp treated as opaque/context.

### Integration
- valid/invalid MAX launch validation;
- session creation;
- live provider → normalized occurrence → API/UI;
- source open target;
- save idempotency/persistence;
- provider partial/error does not fabricate absence/cancellation;
- current MAX API domain.

### E2E/manual-assisted
- iOS/Android/web P0;
- UNKNOWN display;
- source-unavailable;
- optional share.

## Evidence Codex must save

- test command and result;
- commit hash;
- environment/version;
- runtime receipts/logs with secrets removed;
- screenshots for mobile/web;
- provider response sample only where legally permitted;
- any deviation from Product Contract called out explicitly.

## Decisions Codex must NOT change

- solo-first;
- frozen P0;
- Moscow-first demo scope;
- Event != Occurrence;
- hard constraints before ranking;
- UNKNOWN/conditional/raw price;
- no fake coordinates/time/value;
- mandatory provenance/source;
- optional Save;
- social only optional continuation;
- no map/group-planner/new provider/AI framework as a side effect of this research.

## Stop conditions

If implementation would require a change to a canonical source-of-truth file:
1. stop the change;
2. mark `CONFLICT WITH CURRENT SOURCE OF TRUTH`;
3. describe reason/impact;
4. defer unless it is a critical P0 correctness or safety issue.
