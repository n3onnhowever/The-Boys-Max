# POVOD — Public Evidence User Validation: Final Verified Research

**Project:** «Повод»  
**Team:** The Boys  
**Research topic:** user-validation / public-evidence validation  
**Research version:** FINAL-2026-09-18  
**Verification status:** FINAL WITH OPEN BLOCKERS  
**Verification date:** 2026-09-18

> This is a final verification of the research work in this chat, not a restart. The project owner replaced planned interviews/usability recruitment with public-information desk research. Therefore this archive must not be described as completed primary user research.

## 1. EXECUTIVE SUMMARY

The final verified evidence supports the **existing frozen solo-first P0** and does not justify adding any new required feature.

The strongest cross-source pattern is not “people have nowhere to find events.” Public evidence shows that event discovery happens through multiple surfaces (social/word-of-mouth, search, music platforms, event platforms), while final choice depends on concrete logistics such as date/time/place/price. This supports Povod's already-frozen flow: personalized discovery → concrete Occurrence → hard constraints → honest price/UNKNOWN → visible source → open primary source → optional save.

The verification **does not prove** that discovery fragmentation is the primary pain of Russian users, that Russian users broadly want event discovery inside MAX, or that Smart Povod has broad market demand. Those remain product hypotheses. Public platform patterns make them plausible; they do not turn them into user-validation facts.

Russia-specific evidence is narrower but useful. Okkam/Яндекс Афиша/Kassir.ru report 74% digital ticket purchasing in their 2025 market study [S028]. VCIOM reports, specifically for museums/exhibitions/galleries, lack of free time (44%), inconvenient location/long travel (32%) and high ticket price (22%) as visit barriers [S029]. These data support the relevance of time/location/price constraints, but must not be generalized to all event categories.

MAX platform capabilities are well documented, but the exact Povod flow is **not runtime-verified by this archive**. A new/underemphasized blocker is the publication gate: MAX partner access is limited to verified eligible Russian-resident legal entities/IP/self-employed profiles; placement requires a licence agreement; moderation and legal/personal-data duties apply [S025–S027]. This is a release/operations gate, not a reason to alter P0.

A current MAX breaking change also reinforces solo-first: `POST /chats/{chatId}/members` was restricted on 2026-09-09 and is scheduled for removal on 2026-09-30 [S024]. Optional user-initiated share/deep-link continuation remains the safer design.

The strongest new non-technical question is naming: Yandex has an adjacent feature called **«Повод для поездки»** [S030]. This is not evidence of infringement, but it warrants a manual trademark/naming/positioning clearance before production branding.

## 2. FINAL VERDICT

**FINAL WITH OPEN BLOCKERS.**

**P0 verdict:** KEEP FROZEN P0. No UX/public-evidence finding justifies scope expansion.

**Validated by public evidence:**
- multiple discovery surfaces exist;
- occurrence-level date/time/place is a robust industry pattern;
- price/location/time are decision-sensitive fields in relevant contexts;
- save/source/ticket-link/reminder patterns are common;
- messenger-embedded services and conversational discovery are current product patterns;
- MAX officially provides the primitives required for validated launch data, external source opening, sharing and deep links.

**Not validated:**
- Russia-wide “fragmentation pain” as a market fact;
- PMF;
- task success/time/hesitation/UNKNOWN comprehension;
- demand for Smart Povod;
- demand for event search specifically inside MAX;
- exact Povod mobile/web runtime;
- final provider legal/runtime approval;
- final brand/trademark clearance.

## SOURCE-OF-TRUTH CONFLICT STATUS

**CONFLICT WITH CURRENT SOURCE OF TRUTH: NONE DETECTED against the canonical context supplied in this thread.**

This is not a byte-level clearance of the four named files because those files were not retrievable in the accessible File Library. If the later synthesis pass finds a mismatch, that mismatch must supersede this statement and be explicitly labelled `CONFLICT WITH CURRENT SOURCE OF TRUTH`.

## 3. WHAT WAS VERIFIED

1. Re-read the current research thread and the prior desk-research conclusions.
2. Searched accessible File Library for the four named source-of-truth artifacts; they were not retrievable by exact name or semantic query. The project-owner canonical context in this thread was therefore used without inventing file contents.
3. Rechecked mutable public claims on 2026-09-18, prioritizing official sources.
4. Verified current MAX docs, legal rules, requirements, deep-link/Bridge behavior and current API breaking changes.
5. Rechecked Eventbrite, Spotify, Google, WhatsApp, Telegram, LINE, Weixin/Tencent and Fever examples for currentness and scope limits.
6. Rechecked Russia-specific evidence from Okkam, VCIOM, Yandex and Mail.
7. Downgraded claims that could not be traced to a strong primary source.
8. Performed a self-red-team and scope-conflict check.
9. No third-party open-source/GitHub project is recommended or required by this research; GitHub maintenance/licence review is therefore **NOT APPLICABLE** to the user-validation topic.

## 4. CURRENT STATE AS OF 18.09.2026

### Product source of truth carried into this archive

- solo-first;
- P0 frozen;
- MAX → validated MAX identity → interests/constraints → live events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → primary source → optional save;
- Event != Occurrence;
- hard constraints before ranking;
- UNKNOWN/conditional/raw price preserved;
- no fake coordinates/place/time/value;
- provenance/source mandatory;
- Moscow-first live scope per project context;
- social continuation optional;
- map, richer group planning and second city are non-blocking/stretch;
- follow and Smart Povod are post-core/P1 directions, not prerequisites.

### Research state

This archive is **Public Evidence Validation / Desk Research**. No respondent recruitment, problem interviews or moderated usability sessions were executed after the user explicitly changed the validation approach.

### MAX state

- server-verifiable Mini App launch data documented [S021];
- `initDataUnsafe` is not a validation authority [S020];
- external source opening documented via `openLink`, with a required user click [S020];
- in-MAX sharing documented via `shareMaxContent`, with a required user click [S020];
- `startapp` supports an optional payload up to 512 characters; bot `start` up to 128 [S022];
- `platform-api2.max.ru` is required since 2026-07-19 [S023];
- programmatic group-member addition is scheduled for removal on 2026-09-30 [S024];
- real publication requires eligible verified partner profile, licence agreement, moderation/compliance path [S025–S027].

No statement above means the Povod implementation is runtime-verified.

## 5. KEY FINDINGS

### 5.1 Multi-channel discovery is verified; “fragmentation pain” is not

Eventbrite's 2026 Social Study reports 69% of 4,051 surveyed 18–35-year-olds in the US/UK rely on personal networks/word-of-mouth to find experiences [S001]. Eventbrite's 2025 materials also report substantial social-media event discovery among younger cohorts [S002]. Spotify reports that more than half of >6M `Find Tickets` click interactions during 2025 occurred after shows were surfaced to fans rather than after users went looking for them [S005].

**FACT:** discovery is multi-surface.  
**INFERENCE:** a product that consolidates discovery and decision context can reduce switching.  
**NOT PROVEN:** “Russian users' main problem is discovery fragmentation.”

### 5.2 Occurrence is strongly justified

Eventbrite separates recurring-event time slots and gives each slot its own dashboard [S003]. Yandex Afisha requires events to have a defined date, time and place [S031]. Google Event structured data uses `startDate`, `location`, offer/status fields and warns against inventing a midnight time when the hour is unknown [S036].

This strongly supports the existing `Event != Occurrence` contract and the project's data-safety rule not to synthesize missing event detail.

### 5.3 Time, location and price matter, but evidence must stay scoped

VCIOM's 2026 museum/exhibition/gallery study reports:
- lack of free time — 44%;
- inconvenient location / long travel — 32%;
- high ticket price — 22% [S029].

These are useful Russia-specific signals, but they apply to that cultural segment. They must not be presented as percentages for “all event users.”

The Mail analysis reports roughly 40% of processed entertainment tickets are for events within the next month and more than half are for later dates [S032]. This supports **mixed planning horizons**, not an “equal spontaneous/planned split.”

### 5.4 Price and missing-data honesty remain critical

The U.S. FTC live-event ticket pricing rule and 2026 StubHub enforcement show that ticket-price presentation is a consumer-trust and regulatory issue in the US [S011]. It is not Russian law.

For Povod, the stronger reason to preserve price state is already internal: the Product Contract/data-safety rule says unknown/conditional/raw price must be retained and not converted to false “0 ₽/free.”

**Recommendation:** keep internal `UNKNOWN`; use human copy such as “Цена не указана” or “Уточнить у источника” in UI.

### 5.5 Source/provenance is stronger than a decorative label

Google explicitly advises users to confirm event details because plans can change [S004]. MAX places responsibility for accuracy, completeness and currentness of app information on the developer [S026]. Spotify and Yandex route users to ticket/source partners [S006,S030].

**Inference:** source/provenance plus freshness handling is a practical trust/safety control.  
**Do not claim:** a measured trust uplift for Povod without actual usability evidence.

### 5.6 Save is a low-risk conventional action

Google event search supports saving events [S004]. Spotify supports saved events, reminders and ticket links [S006]. This is sufficient to support the already-frozen optional Save without turning it into a larger calendar/reminder subsystem.

### 5.7 Smart Povod is plausible, not demand-validated

Spotify's Prompted Playlist lets users specify discovery intent in natural language [S007], and Spotify explicitly describes a shift from inferred intent to users directly stating what they want [S008]. Google Ask Maps uses conversational local discovery [S009]. Fever exposes an event-discovery MCP/API surface for AI assistants [S010].

These sources validate an **interaction direction**, not market demand for Smart Povod in Russia.

**P0 impact:** none.  
**P1:** a bounded “conditions → 1–3 real matching Occurrences” flow remains reasonable after core stability. It must never invent event data or compensate for failed hard constraints.

### 5.8 Messenger context is a valid platform pattern, not proof of MAX-specific user demand

WhatsApp supports events, reminders and group-decision polls [S012–S014]. Telegram Mini Apps, LINE MINI Apps and Weixin Mini Programs show that embedded services inside communication platforms are mature cross-market patterns [S015–S018].

This supports the plausibility of the MAX surface, but does not establish that Russian users specifically want event search inside MAX.

### 5.9 MAX capabilities and MAX runtime are different evidence categories

Official MAX docs verify:
- validation algorithm [S021];
- `openLink` [S020];
- `shareMaxContent` [S020];
- `startapp` deep links [S022].

But the project-specific flow has not been run in this research archive. Therefore status is:
- capability: **VERIFIED BY OFFICIAL DOCS**;
- Povod exact behavior: **NEEDS RUNTIME VERIFICATION**.

### 5.10 MAX publication is an underappreciated release gate

MAX partner platform access is currently limited to Russian-resident legal entities, individual entrepreneurs and self-employed users with verification [S027]. Placement rules require an active licence agreement and allow moderation/suspension; the developer bears responsibility for rights, data processing and content/information accuracy [S025,S026].

This is a practical **BLOCKER** if the team account/legal path is not already cleared.

### 5.11 Social remains optional — now with stronger technical reason

WhatsApp confirms that group coordination is a real messaging pattern. But that does not justify making it Povod's primary flow. More importantly, MAX is removing the programmatic group-member addition endpoint on 2026-09-30 [S024].

Use user-initiated share/deep-link continuation. Do not create a P0 dependency on chat membership automation.

### 5.12 Naming requires a manual check

Yandex has an official feature named “Повод для поездки” for music-event-driven trip planning [S030].

This does **not** prove any trademark conflict. It does create a meaningful brand/search/confusion question for a product called “Повод.”

Status: **NEEDS LEGAL VERIFICATION / MANUAL DECISION**.

## 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

| PREVIOUS CONCLUSION | FINAL VERIFIED CONCLUSION | WHY | SOURCE | IMPACT |
| --- | --- | --- | --- | --- |
| Discovery fragmentation | Strongest problem is fragmented discovery→decision path. | MULTI-CHANNEL DISCOVERY VERIFIED; 'main Russian pain' downgraded to hypothesis. | Eventbrite/Spotify verify multiple discovery surfaces but no representative Russian end-to-end pain study was found. | S001,S002,S005 | No P0 change; tone down deck claim. |
| Ticketland survey | Used 1,596-person Ticketland figures as direct Russia evidence. | DOWNGRADED: primary Ticketland source not surfaced; secondary only. | Verification found secondary reports reproducing the survey but no direct primary publication. | S033 | Remove from key evidence; optional footnote only. |
| VCIOM time barrier | Used 44% lack-of-time as a broad event-market fact. | SCOPED: applies to museums/exhibitions/galleries survey. | Official VCIOM page explicitly concerns museums/exhibitions/galleries and also reports location 32%, price 22%. | S029 | Use only with segment qualifier. |
| Mail planning horizon | Interpreted as roughly equal spontaneous vs planned. | CORRECTED: mixed horizons; ~40% within month, >50% later. | Source does not support 'equal' wording. | S032 | Keep date-window flexibility rationale; remove equality claim. |
| MAX technical/distribution validation | Called technical/distribution hypothesis strongly confirmed. | SPLIT: platform capabilities verified by docs; exact Povod E2E needs runtime; audience reach remains secondary context. | Official MAX docs verify primitives; no Povod device runtime was run; audience figures are media reports citing Mediascope. | S019-S027,S034,S035 | Add runtime gate; do not use reach as demand proof. |
| MAX publication gate | Underemphasized in previous user-validation narrative. | NEW MAJOR BLOCKER: verified profile eligibility + licence agreement + moderation/legal/data responsibilities. | Official MAX legal and connection docs. | S025,S026,S027 | Manual/legal check before public release. |
| MAX group API | Not central in earlier public-evidence narrative. | NEW BREAKING-CHANGE CONTEXT: member-add restricted 2026-09-09, removal 2026-09-30. | Official MAX API docs. | S023,S024 | Reinforces optional share; never build P0 around auto-add. |
| LINE precedent | LIFF used generically as current mini-app precedent. | UPDATED: LINE recommends new LIFF apps be created as LINE MINI Apps; LIFF v2.31.0 current. | Official LINE docs/release notes. | S016,S017 | Update comparative wording only. |
| Smart Povod | Public trends used to support Smart Povod value. | UNCHANGED BUT NARROWED: interaction model is supported; Russian demand remains unproven. | Spotify/Google/Fever show explicit-intent/conversational discovery, not Povod demand. | S007-S010 | P1 only, bounded. |
| Group/social | Optional continuation was preferred. | UNCHANGED AFTER VERIFICATION. | WhatsApp validates chat coordination as a pattern; MAX API churn makes group-first even less attractive. | S012-S014,S020,S024 | Keep solo-first. |
| Event != Occurrence | Supported by prior reasoning. | UNCHANGED AND STRENGTHENED. | Eventbrite time-slot dashboards; Yandex date/time/place requirements; Google event schema. | S003,S031,S036 | Keep model. |
| UNKNOWN/provenance | Keep honest missing data and source. | UNCHANGED AND STRENGTHENED. | Google advises verifying mutable event details; MAX places accuracy/currentness duty on developer. | S004,S026 | Keep data-safety rules. |
| Brand/naming | Not previously highlighted in this research. | NEW OPEN LEGAL/MARKETING QUESTION: Yandex already has 'Повод для поездки'. | Official Yandex feature announcement/help. | S030 | Manual naming/trademark clearance; no infringement claim. |
| P0 scope | Keep current freeze. | UNCHANGED AFTER VERIFICATION. | No high-confidence finding justifies adding map, group planning, AI or new provider to P0. | P001 + matrix | No P0 expansion. |

## 7. CONFIRMED FACTS

| CLAIM | TYPE | STATUS | EVIDENCE | SOURCE | DATE | CONFIDENCE | PROJECT IMPACT | ACTION REQUIRED |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| P0 is frozen and solo-first: MAX → validated MAX identity → interests/constraints → live events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → open source → optional save. | FACT | CONFIRMED | Canonical context supplied by project owner in this research thread. | P001 | 2026-09-18 | HIGH | Defines the non-negotiable P0 boundary. | KEEP; do not expand P0 from this research. |
| The named canonical files were not retrievable byte-for-byte from the accessible File Library during this pass. | FACT | UNKNOWN | File Library search by exact names and semantic content returned copies of the verification prompt, not the named source-of-truth files. | P001 | 2026-09-18 | HIGH | A byte-level conflict check against the four files could not be performed. | During synthesis/Codex handoff, diff this archive against the actual four files if they become accessible. |
| Event discovery is demonstrably multi-channel in current large platforms/studies; this does not by itself prove that fragmentation is a pain for Russian Povod users. | FACT | VERIFIED BY OFFICIAL DOCS | Eventbrite: 69% of surveyed 18–35 US/UK rely on personal networks/word-of-mouth; Eventbrite TRNDS reports social discovery; Spotify: >50% of Find Tickets clicks follow proactive surfacing. | S001;S002;S005 | 2025-2026 | HIGH | Supports an aggregator/context-unification rationale but not a Russia-wide pain claim. | Use qualified wording in deck; never present as Russian representative statistic. |
| The previous stronger statement that 'fragmentation is the main Russian user pain' is not publicly proven. | INFERENCE | UNKNOWN | Public sources show multiple discovery channels but no representative Russia study was found that measures fragmentation pain end-to-end. | S001;S002;S028;S029 | 2026-09-18 | HIGH | Prevents overclaiming problem validation. | Describe it as a product hypothesis supported by cross-market patterns, not a market fact. |
| In the Okkam/Яндекс Афиша/Kassir.ru 2025 Russian ticket-market study, 74% of tickets were reported as bought online. | FACT | VERIFIED BY OFFICIAL DOCS | Official Okkam research landing page. | S028 | 2026-02 | MEDIUM-HIGH | Supports the relevance of digital event journeys in Russia. | Cite methodology caveat: industry-participant research, not an independent census. |
| For Russian museum/exhibition/gallery visits specifically, VCIOM reports lack of free time 44%, inconvenient location/long travel 32%, and high ticket price 22% as barriers. | FACT | VERIFIED BY OFFICIAL DOCS | VCIOM 'Идем в музей?' published 2026-02-11. | S029 | 2026-02-11 | HIGH | Russia-specific support for time/location/price constraints in one event category. | Do not generalize these percentages to concerts/sports/stand-up. |
| A specific occurrence/time slot is a distinct operational object in major event systems; date/time/place are first-class event fields. | FACT | VERIFIED BY OFFICIAL DOCS | Eventbrite gives each time slot its own dashboard; Yandex Afisha requires defined date/time/place; Google structured data uses startDate/location/eventStatus. | S003;S031;S036 | 2026-09-18 | HIGH | Strong external support for the frozen Event != Occurrence model. | KEEP Event != Occurrence; no scope change. |
| Hard time/location/budget constraints should be applied before recommendation ranking in Povod P0. | RECOMMENDATION | CONFIRMED | Already canonical in project context; public evidence shows date/time/location/price are decision-relevant fields and barriers in applicable segments. | P001;S029;S036 | 2026-09-18 | HIGH | Prevents 'relevant but impossible' recommendations. | KEEP; test PASS/FAIL/UNKNOWN semantics. |
| Price is trust-sensitive; UNKNOWN price must never silently become 0/free. | RECOMMENDATION | CONFIRMED | Project data-safety rule; FTC all-in pricing enforcement shows price accuracy is consumer-sensitive in the US; VCIOM shows price can be a barrier in museum segment. | P001;S011;S029 | 2026-09-18 | HIGH | Direct P0 data-integrity and trust requirement. | KEEP internal UNKNOWN; display human-readable 'Цена не указана/Уточнить у источника'; show 0/free only when source explicitly establishes it. |
| Visible source/provenance and an explicit source-open action are justified trust controls, but public evidence does not quantify how much they increase trust for Povod users. | INFERENCE | LIKELY | Google advises confirming event details because plans change; MAX requires developer information to be accurate/current; Spotify and Yandex use source/ticket partner transitions. | S004;S006;S026;S030 | 2026-09-18 | HIGH for need; LOW for quantified trust effect | Supports P0 source CTA and freshness states without fabricated claims. | KEEP source CTA; do not claim measured trust uplift. |
| Save/bookmark is a stable cross-product convention for events. | FACT | VERIFIED BY OFFICIAL DOCS | Google event search supports Save; Spotify Concerts Near You supports saved events and reminders. | S004;S006 | 2026-09-18 | HIGH | Supports optional save in frozen P0. | KEEP; verify persistence runtime. |
| Artist/topic follow and relevant reminders are reasonable P1 patterns; generic notification spam is not validated. | RECOMMENDATION | PROPOSED | Spotify supports saved-event notifications/reminders and shows high ticket-click contribution from proactive surfacing. | S005;S006 | 2026-09-18 | MEDIUM | Supports P1 follow/reminders but not P0. | KEEP P1 only; opt-in and bounded. |
| Natural-language explicit-intent discovery is a current product pattern. | FACT | VERIFIED BY OFFICIAL DOCS | Spotify Prompted Playlist and Investor Day; Google Ask Maps; Fever AI-assistant event discovery. | S007;S008;S009;S010 | 2026 | HIGH | Makes bounded Smart Povod interaction plausible. | Use only as interaction precedent, not demand proof. |
| There is no public evidence in this pass proving broad Russian demand for Smart Povod specifically. | OPEN QUESTION | UNKNOWN | Found sources are product precedents, not representative Russian demand studies for conversational event recommendations. | S007;S008;S009;S010;S028 | 2026-09-18 | HIGH | Smart Povod must not be promoted into P0 based on this research. | DEFER to P1; keep one bounded demo path only if already planned and core is stable. |
| Messaging platforms support embedded services and planning patterns across multiple markets. | FACT | VERIFIED BY OFFICIAL DOCS | WhatsApp Events/polls/reminders, Telegram Mini Apps, LINE MINI App direction, Weixin Mini Programs. | S012;S013;S014;S015;S016;S018 | 2024-2026 | HIGH | Supports MAX-as-surface plausibility, not MAX-specific user demand. | Use as cross-market precedent only. |
| MAX officially documents Mini Apps, server-verifiable init data, external-link opening, in-MAX sharing and startapp deep links. | FACT | VERIFIED BY OFFICIAL DOCS | MAX validation, Bridge and deep-link documentation. | S019;S020;S021;S022 | 2026-09-18 | HIGH | Supports frozen MAX-native architecture choices. | KEEP; do not equate documentation with Povod runtime proof. |
| The exact end-to-end Povod flow in MAX mobile and web is not verified by this desk-research archive. | OPEN QUESTION | NEEDS RUNTIME VERIFICATION | No Povod runtime session, screenshot, log or device test was performed in this research chat. | P001;S019;S020;S021;S022 | 2026-09-18 | HIGH | Cannot claim 'works in MAX mobile/web' from docs alone. | Run explicit Android/iOS/web acceptance matrix before demo. |
| MAX publication/partner access has an operational/legal gate: eligible Russian-resident entity/self-employed profile, verification, licence agreement and moderation; developer is responsible for data legality/accuracy and personal-data compliance. | BLOCKER | NEEDS LEGAL VERIFICATION | MAX connection docs, placement rules and developer requirements. | S025;S026;S027 | 2026-09-18 | HIGH | Can block real publication even if code works. | Confirm team account/entity verification, licence agreement, moderation path, privacy/legal documents before release. |
| MAX POST /chats/{chatId}/members is restricted from 2026-09-09 and scheduled for removal on 2026-09-30. | FACT | VERIFIED BY OFFICIAL DOCS | MAX API method page and changelog. | S023;S024 | 2026-09-18 | HIGH | Any group flow depending on programmatic membership is brittle and imminent-deprecation dependent. | REJECT such dependency; retain user-initiated share/deep-link optional continuation. |
| Optional share/invite is better aligned with evidence and current MAX API direction than mandatory group planning. | RECOMMENDATION | CONFIRMED | Frozen solo-first scope; WhatsApp shows coordination can live in messaging; MAX shareMaxContent is documented; member-add API is being removed. | P001;S014;S020;S024 | 2026-09-18 | HIGH | Protects P0 and avoids deprecated group-member mechanics. | KEEP optional continuation only. |
| Location matters, but a map is not publicly validated as necessary for Povod P0. | RECOMMENDATION | REJECTED | VCIOM museum segment shows location/travel barrier; Google supports directions; neither proves map UI is required for Povod core. | S004;S029 | 2026-09-18 | HIGH | Avoids scope expansion. | DEFER map unless already implemented and non-blocking. |
| This archive cannot report Povod task success, time-on-task, hesitation, UNKNOWN comprehension, or source-trust scores. | FACT | UNKNOWN | No recruited user sessions or usability tests were run; project owner explicitly chose public-information validation. | P001 | 2026-09-18 | HIGH | Prevents fake 'user validation' metrics. | Call this work Public Evidence Validation / Desk Research; do not invent participant findings. |
| Yandex has an adjacent feature named 'Повод для поездки' for event-driven travel discovery. | FACT | VERIFIED BY OFFICIAL DOCS | Official Yandex announcement and current help page. | S030 | 2025-06-27 | HIGH | Creates possible naming/positioning/search confusion; legal significance is unknown. | Manual trademark/naming clearance. Do not infer infringement. |
| The previously used Ticketland survey figures are not strong enough to remain foundational because a primary Ticketland publication was not surfaced in this pass. | FACT | UNKNOWN | Secondary media reproduces the figures; direct primary source was not found in the verification searches. | S033 | 2026-09-18 | HIGH | Removes a weak pillar from the validation narrative. | Use only as optional secondary context or omit. |
| Mail analytics supports mixed planning horizons, not the stronger claim that spontaneous and long-range planning are 'roughly equal'. | FACT | LIKELY | Mail reports ~40% tickets for events within a month and more than half for later dates. | S032 | 2026-05 | MEDIUM | Corrects overstatement while still supporting multiple date-horizon filters. | Use 'mixed planning horizons' wording only. |
| The older framing of LINE LIFF as the forward-looking standalone pattern is outdated; LINE now recommends creating new LIFF apps as LINE MINI Apps. | FACT | VERIFIED BY OFFICIAL DOCS | LINE developer docs; current LIFF v2.31.0 released 2026-08-31. | S016;S017 | 2026-09-18 | HIGH | Corrects cross-market example; no Povod technology change. | Use 'LINE MINI App' in comparative research; do not add LINE tech to Povod. |
| MAX audience-size numbers can be used only as secondary distribution context in this archive. | FACT | LIKELY | Vedomosti and Expert cite Mediascope for June/August 2026 reach; a directly accessible primary Mediascope page was not surfaced in this pass. | S034;S035 | 2026-07..09 | MEDIUM-HIGH | Avoids turning platform reach into product-demand proof. | Do not use audience scale as evidence that users want event discovery in MAX. |
| No P0 scope change is justified by the final verified public-evidence research. | RECOMMENDATION | CONFIRMED | All strong findings support already-frozen P0 elements; unproven features are P1/stretch or deferred. | P001;S003;S004;S006;S020;S029;S031;S036 | 2026-09-18 | HIGH | Protects hackathon delivery. | KEEP frozen P0. No hidden expansion. |

## 8. RECOMMENDATIONS

1. **KEEP frozen P0.** No feature addition is justified by this research.
2. Preserve `Event != Occurrence` and occurrence-level date/time/place/source.
3. Preserve hard-constraint semantics; recommendation relevance never overrides impossible budget/time/location constraints.
4. Preserve price/raw/conditional/UNKNOWN semantics. Never map missing price to free.
5. Keep source CTA explicit and user-initiated; retain source-unavailable/error states.
6. Keep Save simple and persistent.
7. Keep social as optional native share/deep-link continuation.
8. Keep Smart Povod in P1/conditional scope and bounded to existing structured data.
9. Use public evidence in the deck only with population/geography qualifiers.
10. Rename research evidence honestly: “Public Evidence Validation / Desk Research,” not “user interviews.”
11. Complete MAX partner/legal/publication checks and runtime matrix before claiming demo readiness.
12. Run a manual naming/trademark check for “Повод” because of Yandex's adjacent “Повод для поездки.”

## 9. REJECTED / DEFERRED OPTIONS

| OPTION | STATUS | ADVANTAGES | DISADVANTAGES | RISKS | COMPLEXITY | P0 FIT | SCALE FIT | LICENCE | MAINTENANCE | VERDICT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Frozen solo-first P0 | KEEP | Directly aligned with source of truth; smallest complete value loop; supported by occurrence/constraint/source/save patterns. | Does not prove PMF or social virality. | Core still depends on live data and MAX runtime/legal gates. | LOWER | EXCELLENT | GOOD | Depends on MAX + provider rights; separate gates | Manageable | KEEP unchanged. |
| Mandatory group planning in P0 | REJECT | Could support friend coordination. | Expands scope; no direct demand evidence; conflicts with solo-first; MAX group-member API is being removed. | Demo fragility, API churn, coordination UX complexity. | HIGH | POOR | OPTIONAL LATER | MAX terms apply | Higher | REJECT for P0; optional share only. |
| Map as required P0 surface | DEFER | Can make location evaluation easier. | Public evidence proves location relevance, not need for a map; adds UI/integration risk. | Scope creep. | MEDIUM | LOW | GOOD later | Depends on map provider if added | Additional | DEFER unless already working and non-blocking. |
| Artist/topic follow + relevant reminders | P1 | Strong cross-product pattern; clear opt-in value. | Needs subscription state, notification permission/rules and event matching. | Spam/irrelevance if broad. | MEDIUM | NOT REQUIRED | GOOD | MAX notification/bot rules + provider rights | Moderate | KEEP P1, opt-in and bounded. |
| Bounded Smart Povod | P1 / CONDITIONAL | Matches explicit-intent conversational trend; demo-friendly if tightly constrained. | Russian demand unproven; can distract from core; requires reliable hard-constraint execution. | Hallucination/overreach if model invents data; latency/cost depending implementation. | MEDIUM-HIGH | NO | POSSIBLE | Depends on model/service used | Moderate | Do not promote to P0; one bounded E2E flow only after core stability. |
| MAX-native optional share/deep link | KEEP OPTIONAL | Native continuation after solo discovery; documented share/deep-link primitives. | Cross-client behavior must be tested; user gesture required for share/open. | Runtime/version differences. | LOW-MEDIUM | OPTIONAL | GOOD | MAX platform terms | Low if kept simple | KEEP optional; runtime test before claiming support. |
| Human-readable UNKNOWN state while preserving internal UNKNOWN | KEEP | Maintains data honesty; reduces risk of 'unknown = free/zero'. | Requires careful copy and provider normalization. | Users may still misread without runtime test. | LOW | EXCELLENT | EXCELLENT | N/A | Low | KEEP; never synthesize missing values. |
| Switch/add Fever as provider based on this research | REJECT | Modern AI-assistant/event-discovery API surface. | Russia coverage, rights, commercial terms and fit not established; provider selection is separate research. | Provider churn and legal/data gate reopening. | HIGH relative to benefit | POOR | UNKNOWN | Needs separate legal/commercial verification | Unknown | REJECT as a change from this user-validation research. |
| Present desk research as completed user interviews/usability validation | REJECT | None defensible. | False evidence; damages credibility. | Misleading judges/team; invalid metrics. | N/A | N/A | N/A | N/A | N/A | REJECT. Name it Public Evidence Validation / Desk Research. |

## 10. RISKS

### P0/product
- Overclaiming market/user validation from desk research.
- Literal `UNKNOWN` or ambiguous copy being misread as free/no restriction.
- Source CTA not discoverable enough in actual UI.
- Interest settings confused with temporary filters.
- Stale occurrence/source data creating a false-confidence experience.

### Technical/runtime
- Official docs may differ from current client runtime.
- MAX user-click requirements can affect share/open flows.
- API churn (`platform-api2`, removed group-member API).
- No device-matrix evidence in this archive.

### Legal/operational
- MAX partner eligibility, licence agreement, moderation and privacy documents may not yet be cleared.
- Provider rights/attribution/storage/caching remain a separate provider/legal research gate.
- Brand/name adjacency with Yandex “Повод для поездки” requires clearance.
- Images/descriptions/logos must not be reused without provider/legal rights.

### Research/evidence
- Eventbrite/Spotify/Google/Fever are vendor/platform sources with incentives.
- US/UK/US-India/China/Japan patterns are not automatically Russian behavior.
- Okkam is industry-participant research.
- VCIOM result is category-specific.
- Ticketland figures lack a surfaced primary source in this pass.
- MAX audience figures are secondary reports citing Mediascope and do not equal engagement or event-discovery intent.

## 11. BLOCKERS

### B1 — MAX publication/partner gate
**Status:** NEEDS LEGAL/MANUAL VERIFICATION.  
Confirm eligible verified entity/self-employed profile, licence agreement, bot/mini-app moderation path and required legal/privacy documentation.

### B2 — Exact MAX E2E runtime
**Status:** NEEDS RUNTIME VERIFICATION.  
Docs do not prove the Povod flow works on the target versions/platforms.

### B3 — Live provider legal/runtime gate
**Status:** OUTSIDE THIS TOPIC BUT PROJECT-CRITICAL.  
This user-validation archive does not approve KudaGo, Timepad, Fever or any provider. Preserve the separate provider/data-gate decision.

### B4 — User/usability claims
**Status:** BLOCKER FOR CLAIMS, NOT FOR IMPLEMENTATION.  
No primary participants were run after the research approach was changed to public-only evidence. Do not claim task-success, time-on-task or participant preference.

### B5 — Byte-level source-of-truth reconciliation
**Status:** OPEN.  
Named canonical files were not retrievable in accessible File Library. No conflict was detected against the canonical context supplied in this chat, but actual-file diff remains for synthesis.

## 12. OPEN QUESTIONS

- Is the team already verified on MAX partner platform under an eligible profile?
- Is the licence agreement accepted and mini-app moderation route available?
- Does the exact current build validate MAX init data server-side and reject invalid/stale launches?
- Does source opening work correctly from MAX iOS, Android and web?
- Does `shareMaxContent` behave as intended on all target clients?
- Are provider source URLs, rights, caching/retention and attribution legally cleared?
- Has “Повод” been checked against Russian trademark/name databases and adjacent Yandex branding?
- Are actual source-of-truth file versions identical to the canonical context used here?
- What does the current MVP display for each UNKNOWN state? Public evidence cannot answer UI comprehension.
- Is Smart Povod already implemented? If not, it must not displace P0 work.

## 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`. No runtime test in that file is claimed as already passed by this archive.

Minimum:
1. Valid MAX launch → server validation succeeds → own session established.
2. Tampered/invalid launch data rejected.
3. Android/iOS/web P0 path to live event occurrence.
4. External source opens only after explicit click and reaches the intended primary source.
5. Save persists after reload/relaunch/re-login as designed.
6. Price known / free / conditional / UNKNOWN states remain distinct.
7. UNKNOWN time/location/price are not fabricated.
8. loading / empty / error / source-unavailable states are reachable and understandable.
9. hard filters exclude fail cases and handle UNKNOWN per contract.
10. `platform-api2.max.ru` and certificate requirements are satisfied where Bot API is used.
11. no required flow depends on `POST /chats/{chatId}/members`.
12. optional share works on target clients before the team claims it.

## 14. REQUIRED MANUAL / LEGAL CHECKS

- MAX partner-profile eligibility and verification.
- Active MAX licence agreement / moderation readiness.
- Published privacy/terms/support documents required by MAX and applicable law.
- Legal basis and lifecycle for personal data handled by Povod.
- Provider licence/attribution/storage/caching/image/description/source-link rights.
- Brand/trademark/name clearance for “Повод,” explicitly considering Yandex “Повод для поездки.”
- Final deck copy: every public statistic must include population/geography/source qualifier.
- Actual four source-of-truth artifacts should be compared during synthesis.
- This section is operational guidance, not legal advice.

## 15. EXACT CHANGES FOR «ПОВОД»

### P0
**No scope additions.**

Exact changes/reinforcements:
- internal UNKNOWN remains a data state; UI should use human-readable wording;
- source CTA must be explicit and point to validated provider/source URL;
- current MAX integration must use server-validated init data, not `initDataUnsafe` as authority;
- use current MAX API domain where Bot API is called;
- no group-member auto-add dependency;
- retain existing loading/empty/error/source-unavailable states;
- do not add map/group planner/new provider/AI agent from this research.

### P1
- artist/topic follow: keep as opt-in;
- Smart Povod: one bounded E2E scenario, hard constraints first, only real occurrences, exact source;
- notifications: opt-in/relevance-bounded.

### Stretch
- share/deep-link continuation;
- second city only after separate data gate;
- map only if already stable and non-blocking;
- richer shared planning after hackathon.

## 16. IMPACT ON P0 / P1 / STRETCH

### P0
**UNCHANGED AFTER VERIFICATION.**

### P1
No new commitment. Existing follow/Smart Povod direction remains defensible but not user-demand validated.

### Stretch
Social coordination/map remain non-blocking. MAX API deprecation makes custom group automation even less attractive.

## 17. WHAT NOT TO DO

- Do not say “we interviewed users” or “users validated X.”
- Do not publish percentage claims as Russia-wide facts when samples are US/UK or museum-specific.
- Do not say MAX reach proves users want Povod in MAX.
- Do not say Smart Povod demand is validated.
- Do not make social/group planning mandatory.
- Do not add a map to satisfy a research narrative.
- Do not add Fever or another provider because its developer API looks modern.
- Do not trust `initDataUnsafe` or `startapp` as authorization.
- Do not use the old MAX API domain.
- Do not build on `POST /chats/{chatId}/members`.
- Do not fabricate missing price/time/location/end time.
- Do not equate UNKNOWN with free.
- Do not call docs-only evidence “verified by runtime.”
- Do not claim provider legality from public UX evidence.
- Do not infer trademark infringement from the Yandex naming overlap.

## 18. SELF-CRITIQUE / RED TEAM

### What if the “fragmentation” thesis is wrong?
It may be. Multiple discovery channels can be a feature rather than pain. Users may enjoy TikTok/word-of-mouth discovery and only need Povod at the constraint-checking stage. Therefore the safe product claim is “Povod consolidates a decision-ready occurrence,” not “Povod fixes a universally painful fragmented market.”

### What if save/follow are copied conventions with little actual value?
Possible. Their presence in large products demonstrates convention, not Povod frequency/value. Save remains acceptable because it is already P0 and low scope. Follow remains P1.

### What if Smart Povod is overengineering?
This is the primary red-team concern. Conversational discovery is fashionable, but public evidence does not prove it beats simple filters for live events in Russia. Keep it outside P0 and require the same hard constraints and source truth as normal search.

### What if MAX is a poor engagement surface despite large reach?
Possible. Secondary reach statistics do not measure depth, intent or event-discovery behavior. The product rationale should rest on required hackathon/MAX-native integration plus low-friction continuation, not on a claim that reach equals demand.

### What if group coordination is actually the strongest use case?
Even then, the frozen project is solo-first. Public evidence supports coordination in chats, but a group-first rebuild would add complexity and depend on changing platform APIs. The safer hackathon path is solo discovery followed by share.

### What if source links reduce conversion?
They may add a click, but the product intentionally does not own final ticket truth. Event details change; MAX makes the developer responsible for accuracy/currentness. The source link is therefore a correctness boundary, not merely UX decoration.

### What if Event != Occurrence is too complex?
For implementation it is more complex than a flat event row, but recurring/time-slot systems and event structured data confirm that dates/sessions are materially distinct. Since the project contract is already occurrence-centric, flattening now would create more data ambiguity than it removes.

### What if Yandex “Повод для поездки” is irrelevant?
It may be legally irrelevant. The archive does not claim infringement. But adjacent naming in an event/travel domain is sufficient to justify a cheap manual clearance before production branding.

### Hidden costs
- legal/privacy/MAX partner setup;
- provider licences and attribution;
- maintaining freshness/status;
- cross-client MAX testing;
- notification abuse risk if P1 expands;
- AI latency/cost/hallucination if Smart Povod is overbuilt.

### More modern/simple alternatives
The simpler alternative remains the frozen product: structured filters + occurrence cards + source + save. No newly found technology is necessary for P0.

## 19. MISSING AREAS CHECK

### Potentially forgotten areas found in verification
- MAX publication eligibility/licence/moderation gate;
- imminent MAX group-member API removal;
- brand adjacency with Yandex “Повод для поездки”;
- distinction between platform reach and actual engagement/demand;
- outdated forward-looking framing of LINE LIFF.

### Areas additionally checked
- current MAX docs and legal pages;
- current MAX changelog/API deprecation;
- current LINE direction and release;
- current Spotify conversational-discovery direction;
- Russia digital-ticket market context;
- Russia museum-segment time/location/price barriers;
- exact source of prior Ticketland and Mail claims.

### Still impossible to close from public information alone
- actual Povod usability;
- actual user trust/UNKNOWN comprehension;
- actual MAX exact-flow runtime;
- final provider rights/coverage/runtime approval;
- actual trademark clearance;
- exact byte-for-byte canonical-file comparison.

### Requires runtime
See section 13.

### Requires human/manual decision
Brand naming, final deck wording, whether P1 is attempted after P0 stability.

### Requires legal
MAX licence/privacy/personal-data requirements, provider rights, trademark/name clearance.

### Requires Codex/host
Implementation-level checks listed in `CODEX_ACTIONS.md`, repository-path inventory, tests and evidence capture.

### Closed enough for this research topic
- do not expand P0;
- keep occurrence model;
- keep hard constraints;
- keep honest UNKNOWN/provenance/source;
- keep save;
- keep social optional;
- Smart Povod/follow are non-P0;
- public evidence must not be represented as completed user testing.

## 20. SOURCE MANIFEST

See `SOURCE_MANIFEST.csv` and `SOURCE_MANIFEST.json`.

Source policy applied:
- official/platform/government sources prioritized;
- vendor studies marked as such;
- secondary Ticketland/MAX-audience sources explicitly downgraded;
- no Reddit/SEO source is used for a major conclusion;
- no GitHub/OSS dependency is proposed in this topic.

## 21. FINAL CHECKLIST

- [x] Major claims have evidence or explicit UNKNOWN status.
- [x] Mutable platform facts rechecked on 2026-09-18.
- [x] Official sources prioritized.
- [x] Source population/geography limitations recorded.
- [x] Current MAX breaking changes rechecked.
- [x] MAX legal/publication requirements rechecked.
- [x] No runtime claim invented.
- [x] No user-interview/usability metric invented.
- [x] P0 not silently expanded.
- [x] Conflict policy applied; no conflict detected against supplied canonical context.
- [x] Named source-of-truth files explicitly marked unavailable for byte-level diff.
- [x] Recommendations are actionable.
- [x] Deferred/rejected options recorded.
- [x] Open questions recorded.
- [x] Source manifest generated.
- [x] Decision delta generated.
- [x] machine_summary.json generated.
- [x] CODEX_ACTIONS.md generated.
- [x] Evidence notes generated.
- [x] Archive will be validated after creation.
