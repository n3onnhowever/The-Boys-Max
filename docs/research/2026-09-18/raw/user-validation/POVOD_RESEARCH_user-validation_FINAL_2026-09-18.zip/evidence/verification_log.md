# Verification Log

Date: 2026-09-18

## Source-of-truth access

Searches were run in accessible File Library using:
- exact canonical filenames;
- phrases including solo-first, Occurrence, UNKNOWN, provenance, Product Contract.

Results surfaced copies of the final-verification prompt rather than the four named files. Therefore no byte-for-byte source-of-truth file comparison is claimed.

Canonical project decisions were carried from the project-owner context in this research thread and prior project context:
- frozen P0;
- solo-first;
- Moscow-first demo scope;
- Event != Occurrence;
- hard constraints before ranking;
- honest UNKNOWN/conditional/raw price;
- no fake coordinates/value;
- source/provenance;
- save;
- social optional.

## Web verification highlights

### Event/occurrence
- Eventbrite current help: recurring events have distinct time slots and per-slot dashboards.
- Yandex Afisha current rules: event must have definite date/time/place.
- Google Event structured data: startDate/location/eventStatus and guidance against inventing midnight when time unknown.

### Discovery
- Eventbrite Social Study 2026: 4,051 respondents age 18–35, US/UK; 69% personal networks/word-of-mouth.
- Spotify Fan Study: >6M interactions during 2025; more than half of Find Tickets clicks after surfaced shows.

### Russia
- Okkam/Яндекс Афиша/Kassir: 74% digital ticket share in 2025 study.
- VCIOM 2026 museum/exhibition/gallery: time 44%, location 32%, price 22% barriers.
- Mail: ~40% tickets within a month, more than half later.
- Ticketland figures found only via secondary media in this pass; downgraded.

### MAX
- validation algorithm confirmed in official docs;
- `initDataUnsafe` cannot be used for validation;
- `openLink` requires user click;
- `shareMaxContent` requires user click and supports dialogs/group chats;
- `startapp` payload up to 512 chars;
- `platform-api2.max.ru` required since 2026-07-19;
- group-member add restricted 2026-09-09 and removed 2026-09-30;
- eligible verified RF-resident entity/IP/self-employed profile required;
- placement requires licence agreement and is subject to moderation;
- developer responsible for accuracy/currentness, rights and data compliance.

### Cross-market embedded services
- WhatsApp events/reminders/polls;
- Telegram Mini Apps;
- LINE now recommends LINE MINI App direction;
- Weixin Mini Programs.

## No runtime evidence produced
No code was executed against MAX, no mobile/web screenshot was generated, and no user test was performed in this research archive.
