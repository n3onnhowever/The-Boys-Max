# Gaps and Open Questions

## Critical open items

1. **Named source-of-truth files not byte-accessible in this pass.**  
   No byte-level diff against `POVOD_FINAL_SCOPE_FREEZE_MVP.md`, `POVOD_PRODUCT_SPEC_V1.md`, `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`, `POVOD_PRODUCT_CONTRACT_V1.json` was possible. The supplied canonical project context was preserved.

2. **MAX exact runtime.**  
   Official docs verify capabilities, not the Povod implementation. Android/iOS/web runtime evidence remains required before claiming support.

3. **MAX publication/legal gate.**  
   Confirm eligible verified partner profile, active licence agreement, moderation path, privacy/terms/support documentation and personal-data basis.

4. **Provider/data legal gate.**  
   This archive does not approve KudaGo, Timepad, Fever or any other provider. Provider rights, coverage, source URLs, retention/caching and image/text use belong to the provider research stream.

5. **Brand/name clearance.**  
   Yandex operates an adjacent feature called “Повод для поездки.” This may be harmless, but requires a manual trademark/naming/positioning check.

6. **No primary usability evidence.**  
   Public research cannot produce task-success rates, hesitation, comprehension or trust metrics for the current Povod UI.

## Non-blocking questions

- Is follow artist/topic already implemented or only planned?
- Is Smart Povod already implemented? If not, do not let it displace P0.
- Is optional MAX share already functional on web as well as native clients?
- Which human-readable copy is currently used for UNKNOWN price/time/place?
- Are saved events durable across re-login or only local/session state?
- Do current source links point to exact event pages and handle source-unavailable gracefully?

## What is closed

- No P0 scope expansion from this research.
- Event != Occurrence stays.
- Hard constraints stay before ranking.
- UNKNOWN/provenance/source stay.
- Save stays.
- Group-first is rejected for hackathon P0.
- Map is deferred.
- Smart Povod/follow stay outside P0.
- Public desk evidence must not be presented as interviews/usability tests.
