# Risks

## P0
- Live data can be stale or incomplete.
- UNKNOWN can be misread if UI copy is weak.
- Source CTA can be missed or lead to an unavailable source.
- Interest preferences and temporary filters can be confused.
- Save may appear successful without durable persistence unless tested.

## Technical/runtime
- MAX docs are not runtime proof.
- share/open flows require explicit user gestures.
- MAX API changes are active in September 2026.
- `POST /chats/{chatId}/members` removal on 2026-09-30 breaks any dependency on programmatic group joining.
- Old `platform-api.max.ru` usage is invalid for current bot/mini-app integrations.

## Legal/operational
- MAX partner profile, licence agreement and moderation.
- Personal-data/legal documents and deletion/support obligations.
- Provider attribution/licensing/caching/retention/content rights.
- Yandex adjacent “Повод для поездки” naming/positioning question.
- Rights to event images/descriptions/logos if used.

## UX/evidence
- No direct task-success or comprehension evidence.
- Vendor product patterns can be mistaken for user demand.
- US/UK/China/Japan/India patterns may not transfer to Russia.
- VCIOM barrier percentages are museum/exhibition-specific.
- MAX audience reach does not prove engagement or event-search intent.

## Operational
- External source/provider outage.
- Last-minute event cancellation/reschedule.
- Provider disappearance must not be treated as cancellation without evidence.
- P1 notifications can become spam.
- Smart Povod can hallucinate/overreach if not constrained to structured facts.
