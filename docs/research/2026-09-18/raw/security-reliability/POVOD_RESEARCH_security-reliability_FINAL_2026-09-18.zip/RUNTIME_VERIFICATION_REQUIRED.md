# Runtime Verification Required

## 1. MAX identity mutation suite
Test valid fixture, parameter reordering, duplicate arbitrary key, duplicate `hash`, modified `user`, modified/future/stale `auth_date`, malformed encoding. Acceptance: no actor/session on any invalid input.

## 2. MAX mobile + web session matrix
For each supported client prove launch, validated identity exchange, authenticated API request, refresh/reopen, source link, logout/expiry, and chosen cookie/SameSite/CSP/frame behavior.

## 3. MAX outbound API
From the exact release image: resolve/connect to `platform-api2.max.ru`, verify trusted TLS chain, perform a harmless authenticated call (for example `/me` if appropriate), capture status/latency without the token.

## 4. Webhook
Invalid/missing secret → reject. Valid event → durable accept well under 30s. Same semantic event x10 → one business side effect. Worker failure after durable accept → bounded eventual processing. Monitor before the platform’s 8-hour unsubscribe risk.

## 5. Provider/data
Inject timeout, malformed JSON, 429 + Retry-After, page-3 failure after pages 1–2, stale response after newer response, vanished event, price conflict, missing price/place/coordinates/end, timezone boundary and duplicate occurrence. Acceptance: no fabricated truth and no partial tombstone.

## 6. DB/queue/worker
Duplicate jobs concurrently; kill worker at multiple points using the existing helper; DB failure before/during transaction; pool exhaustion; deadlock/serialization; poison job; ambiguous MAX send. Acceptance: bounded retries, no duplicate business effect, explicit `unknown` where remote outcome cannot be proven.

## 7. Observability
Inject one traceable failure. Prove the user gets a safe correlation ID; logs can find it without secret/PII; Sentry/equivalent is scrubbed; metric increments without high-cardinality IDs; one alert reaches the intended team channel.

## Evidence format
For every test store: date, git SHA, image/container version, command/test name, result, sanitized log excerpt, relevant metric/error ID, pass/fail. Never store live credentials in receipts.
