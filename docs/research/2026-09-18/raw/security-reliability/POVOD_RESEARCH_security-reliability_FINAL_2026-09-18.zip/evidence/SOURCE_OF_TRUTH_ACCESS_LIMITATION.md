# Source-of-truth access limitation

The verification searched the available File Library for the exact names of:
- `POVOD_FINAL_SCOPE_FREEZE_MVP.md`
- `POVOD_PRODUCT_SPEC_V1.md`
- `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`
- `POVOD_PRODUCT_CONTRACT_V1.json`

Directly openable canonical copies were not returned; available hits were prompt/context echoes rather than the actual documents.

Therefore:
- the current project instructions/context are treated as authoritative context;
- this archive does not invent exact unseen file contents;
- `CODEX_ACTIONS.md` requires a host-side direct read + SHA-256 receipt before synthesis;
- any discrepancy found on host must be recorded as a source-of-truth conflict rather than silently merged.
