# Web verification notes — 18.09.2026

Compact notes only; full copyrighted pages are not copied.

## MAX
- Exact WebApp HMAC validation/unique-param rules confirmed.
- `initDataUnsafe` is not validation authority; auth_date recommended invalidation interval ~1h.
- API2 domain/certificate change effective 19.07.2026 confirmed.
- Webhook HTTPS/443/trusted cert, <=30s response, secret header, retry schedule and 8h unsubscribe risk confirmed.
- 30 rps and production Webhook recommendation confirmed.
- `User.name` deprecation confirmed.
- Account/data deletion requirement and anti-duplication/tampering requirements confirmed in current developer legal/requirements pages.

## KudaGo
- HTML default text format, free-form price, nullable end fields and licence disclaimer confirmed.
- Direct open indexable source-link obligation confirmed.
- Provider remains project-level NOT APPROVED.

## Queue/observability
- pg-boss active; current docs runtime floor Node >=22.12/PostgreSQL >=13; GitHub API reported release 12.33.2 on 18.09.2026.
- BullMQ v6 supports PostgreSQL, correcting a Redis-only assumption.
- OTel JS traces/metrics stable; logs development; browser instrumentation experimental.
- Prometheus high-cardinality warning and modern Node client package confirmed.
- Sentry server-side scrub/IP controls confirmed.
