# Project static evidence note

Source: local Git/PowerShell transcript captured 16.09.2026.

Verified in the transcript:
- repository path `D:\Dev\Repos\The-Boys-Max`;
- source inventory included API, Mini App, worker, auth, persistence, migrations and tests;
- notable paths included `packages/platform/auth.ts`, `ingress.ts`, `transport.ts`, `packages/persistence/*`, `apps/worker/main.ts`, `tests/unit/security.test.ts`, `tests/helpers/kill-worker.ts`;
- repaired baseline SHA reported as `dc011dad97a63be0297c455548bbde8a05f749e4`;
- handoff SHA reported as `b94b7185e31214c9b1b73a106c3c45b5e9fca71f`;
- working tree reported clean after the repaired procedure; no remote was added/pushed.

Critical limitation stated by the transcript itself: the Git baseline did **not** constitute application integration, runtime, Docker, npm, network, live-provider, browser or end-to-end acceptance.

Therefore this archive never upgrades “file exists” into “security control works”.
