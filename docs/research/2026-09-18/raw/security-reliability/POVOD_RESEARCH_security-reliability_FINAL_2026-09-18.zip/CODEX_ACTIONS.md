# CODEX ACTIONS — Security / Reliability Handoff

Codex must **inspect first and patch only evidence-backed gaps**.

## A. Re-establish authority
Open and SHA-256 hash:
- `POVOD_FINAL_SCOPE_FREEZE_MVP.md`
- `POVOD_PRODUCT_SPEC_V1.md`
- `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`
- `POVOD_PRODUCT_CONTRACT_V1.json`

Also record `git rev-parse HEAD`, branch and `git status --short`. Confirm solo-first/Moscow-first, Event ≠ Occurrence, UNKNOWN/provenance and frozen P0 before any code change. If current files conflict with this archive, source of truth wins and the conflict must be recorded explicitly.

## B. Dependency/runtime inventory
Inspect `package.json`, lockfile(s), Dockerfile, `compose*.yaml`, CI/runtime config. Record Node/PostgreSQL versions; actual queue package/backend/version; `pg`, logger, Sentry, metrics and validation libraries already present.

**Do not upgrade to pg-boss 12.33.2 just because it is newest.** The current pg-boss line requires Node >=22.12; preserve a tested compatible version unless a change is required.

## C. Mandatory greps
Search for:
`platform-api.max.ru`, `platform-api2.max.ru`, `/chats`, `/members`, MAX `User.name`, `initDataUnsafe`, `auth_date`, `WebAppData`, `createHmac`, `timingSafeEqual`, `localStorage`, `sessionStorage`, `dangerouslySetInnerHTML`, `.innerHTML`, `eval(`, `new Function`, URL construction around `fetch`/HTTP clients, generic redirect/go endpoints, `console.log`, request-body logging, Authorization/BOT/webhook secrets, `.env` values, raw MAX IDs/initData in analytics/Sentry.

Preserve a sanitized grep receipt.

## D. Inspect/patch if needed
### `packages/platform/auth.ts`
Exact MAX validation; duplicate rejection; freshness <= official one-hour baseline unless product intentionally chooses tighter; constant-time compare hardening; validated actor only; no raw initData logging.

### `packages/platform/config.ts` / `transport.ts`
Use `https://platform-api2.max.ru`; token in header only; explicit timeout; classify 429/5xx; no secret in URL/log; obtain runtime TLS receipt.

### `packages/platform/ingress.ts`
If Webhook exists: require secret; body/schema bounds; durable accept before 200; semantic/event-specific replay key; no invented universal `update_id`.

### `packages/platform/links.ts` and mini-app launch/link code
`startapp` is input, never ACL. Validate invite grammar/entropy/scope/expiry. Resolve source URLs from stored provider records; allowlist HTTPS hosts; no arbitrary redirect URL.

### `packages/platform/governor.ts/.lua`
Verify bounded auth/invite/write/search limits and TTLs. Return 429 appropriately. Avoid unbounded user-controlled keys.

### `packages/persistence/sessions.ts`
Inspect CSPRNG session generation, storage, expiry/revocation and client storage. Hash persistent bearer/capability tokens where appropriate.

### `packages/persistence/plans.ts` and all user-owned persistence
Actor-scoped reads/writes; DB unique constraints; A/B tests.

### `packages/persistence/delivery.ts`
Semantic delivery unique key; `pending/sent/failed/unknown` or equivalent; bounded attempt tracking; no blind retry after ambiguous remote success.

### `packages/persistence/catalog.ts` + search/provider modules
Run completeness; stale/version guard; no partial tombstone; raw price/provenance; UNKNOWN preservation; no fake coords/place/end; provider minimal text fields.

### `packages/persistence/db.ts`
Pool bounds; connection/statement timeouts; error handler; transaction helper that uses one checked-out client.

### `apps/worker/main.ts`
One durable queue path; graceful shutdown; explicit retry/backoff/expiration; one P0 worker replica unless current authority says otherwise; queue stats/warnings.

### `apps/api/*`
Request/correlation IDs; body limits; safe errors; `/health/live`; `/health/ready`; deletion flow if missing and required for public placement.

### Mini App
No auth token in browser storage; no provider HTML sink; honest stale/UNKNOWN/source states; no client-only authorization.

## E. Tests
Extend the existing security/integration suite and reuse `tests/helpers/kill-worker.ts`:
1. MAX validation vectors/mutations.
2. A/B IDOR matrix.
3. invalid/expired/revoked/tampered startapp capabilities.
4. Webhook invalid secret + replay x10 + durable ACK.
5. DB uniqueness/idempotency.
6. worker kill at transaction/send boundaries.
7. provider timeout/malformed/429/partial/stale.
8. price/free ambiguity.
9. missing place/end/coordinates.
10. timezone/Moscow boundary.
11. log redaction assertions where practical.
12. health/readiness dependency matrix.

## F. Runtime receipts
Preserve sanitized receipts for MAX mobile, MAX web, API2 TLS, Webhook, DB-down, queue duplicate/crash, provider failures, secret/PII scans and account deletion (if public placement).

## G. Supporting security tools
Run and review Gitleaks, OSV-Scanner/package-manager audit, selected Semgrep TS/JS rules and ZAP baseline against staging. Clean scanners do **not** prove correct auth/IDOR/idempotency.

## H. Decisions NOT to change
Do not expand P0, city/provider/social scope. Do not add Redis/Kafka/Temporal/Kubernetes solely for this handoff. Do not add provider HTML or fabricate UNKNOWN fields. Do not mark KudaGo approved. Do not migrate an actually E2E-green queue close to deadline only for architecture purity.
