# POVOD_RESEARCH_security-reliability_FINAL_2026-09-18

**Project:** «Повод» — The Boys  
**Topic:** security + reliability + observability red-team verification  
**Research version:** FINAL-2026-09-18  
**Previous result:** security + reliability + observability red-team from the same research chat, 18.09.2026  
**Verification status:** FINAL WITH OPEN BLOCKERS

## Main conclusion
The security/reliability direction remains suitable for a hackathon, but the current runtime is **not proven** by static repository evidence. A controlled demo is **CONDITIONAL GO** after explicit code/runtime gates. Public MAX placement is **NO-GO until open blockers close**.

Material verification deltas:
- MAX API transport must use `platform-api2.max.ru` from 19.07.2026 and production TLS trust must be proven.
- MAX's documented initData freshness recommendation is about **1 hour**; the previous 15-minute requirement was over-strong.
- MAX does not document a universal top-level webhook `update_id`; semantic/business idempotency remains necessary.
- The MAX placement rules create an account/data-deletion compliance gate when their trigger applies.
- Queue guidance is corrected to **PostgreSQL + pg-boss if compatible/currently selected**; do not add Redis for P0. Preserve an already-real E2E-green BullMQ path rather than rewriting near deadline.
- Observability is intentionally reduced to structured logs, safe error capture, health/readiness and bounded metrics. Full OTel/Tempo/Loki and mandatory self-hosted Prometheus/Grafana are deferred.
- KudaGo remains **NOT APPROVED**; data safety and separate runtime/legal gates remain in force.

## Archive contents
`FINAL_REPORT.md`, `EXECUTIVE_VERDICT.md`, `FACT_CHECK_MATRIX.csv`, `CLAIMS_EVIDENCE.csv`, `SOURCE_MANIFEST.csv/.json`, `DECISION_MATRIX.csv`, `DECISION_DELTA.md`, `GAPS_AND_OPEN_QUESTIONS.md`, `RECOMMENDATIONS.md`, `RISKS.md`, `RUNTIME_VERIFICATION_REQUIRED.md`, `CODEX_ACTIONS.md`, `machine_summary.json`, and compact supporting evidence notes under `evidence/`.

The exact current bodies of the four canonical source-of-truth files were not directly retrievable in this verification context. This is preserved as an explicit host/Codex gate rather than filled with assumptions.
