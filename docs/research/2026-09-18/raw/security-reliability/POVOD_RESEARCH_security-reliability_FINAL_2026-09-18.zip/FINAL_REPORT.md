# POVOD Security + Reliability + Observability — Final Verification Report

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** security-reliability  
**Research version:** FINAL-2026-09-18  
**Verification status:** FINAL WITH OPEN BLOCKERS  
**Verification date:** 18.09.2026  
**Previous result:** security + reliability + observability red-team from earlier in the same research chat on 18.09.2026

> This is a verification pass over the existing research. It does not redesign the product and does not silently expand the frozen P0.

## 1. EXECUTIVE SUMMARY

The previous red-team was directionally correct on the central invariants: validate MAX identity server-side; keep Povod authorization independent from `startapp`; protect every user-owned object from IDOR; make webhook/job/notification side effects idempotent; never treat a partial provider run as a complete snapshot; preserve Event ≠ Occurrence, `UNKNOWN`, provenance and source; treat provider content as untrusted; and keep secrets/PII out of observability.

This verification pass changes the confidence and several exact conclusions rather than the product design.

First, **MAX changed materially during 2026**. Official change logs require bot/mini-app API calls to `platform-api2.max.ru` from 19 July 2026, with the applicable certificate trust-chain requirement. This is a current compatibility gate, not generic hardening. The previous result did not promote it strongly enough.

Second, the current Webhook contract is exact: HTTPS on port 443, trusted certificate, successful `200 OK` no later than 30 seconds, optional-but-recommended shared secret delivered in `X-Max-Bot-Api-Secret`, up to 10 delivery retries after failures, and prolonged lack of successful responses may automatically remove the subscription. This makes durable early acceptance and semantic idempotency mandatory whenever the webhook path is in the shipped flow.

Third, the prior **15-minute initData freshness recommendation was too strong**. MAX documents `auth_date` and recommends invalidating initialization data after about one hour. Povod may choose a shorter interval as hardening, but it must not be represented as a MAX requirement, and it should be tested against real mobile/web reload/reopen behavior. Likewise, `query_id` is documented as unique for the current session, not as a globally one-time nonce; globally consuming it is not a justified release blocker without runtime evidence.

Fourth, the previous answer was too casual about account deletion. MAX placement rules state that if an application creates an account or receives user data based on the MAX account, it must offer a free way to delete the application account and developer-processed data on request. This creates a **public-placement compliance gate**. It does not justify expanding the event product; it is a narrow compliance edge around the account/profile already implied by P0.

Fifth, queue guidance is corrected. Current project architecture context points to **PostgreSQL + pg-boss in the existing worker** rather than a new Redis service. BullMQ v6 now supports PostgreSQL, so the old “BullMQ means Redis” assumption is stale; nevertheless, introducing BullMQ gives no frozen-P0 benefit. If the actual repository already has an E2E-green BullMQ implementation, rewriting it close to the deadline can be riskier than keeping it. Queue choice must therefore be inspect-first. Any queue’s exactly-once claim still does not prove an external MAX message is exactly once after a worker/network crash.

Sixth, observability should be smaller than the previous response implied. P0 needs structured JSON logs, request/correlation IDs, safe error capture, health/readiness and bounded metrics. A separate Prometheus/Grafana deployment is useful only if already available or trivial; a full OpenTelemetry Collector + Tempo + Loki stack is explicitly deferred.

Finally, KudaGo remains **NOT APPROVED**. Its official API confirms HTML-default text, free-form price strings and nullable end fields; its licence disclaims correctness/API availability. These facts reinforce the existing Data Safety Patch rather than replace it. Provider runtime/legal gates remain separate blockers.

The local project transcript from 16.09.2026 proves that the repository baseline contained API, Mini App, worker, auth, persistence, migrations, security tests and `kill-worker` helper paths. The same transcript explicitly states that this baseline **does not constitute application integration, runtime, Docker, network, live-provider, browser or E2E acceptance**. Therefore this archive does not label the current build secure/stable/production-ready.

## 2. FINAL VERDICT

### Controlled hackathon demo
**CONDITIONAL GO**, provided the release acceptance checks in this archive pass on the actual current commit/runtime.

### Public MAX placement/open pilot
**NO-GO UNTIL OPEN BLOCKERS CLOSE.** Specifically: current MAX auth implementation must be inspected/tested; API2/TLS must work from the release environment; object authorization/session handling must be proven; webhook idempotency must be proven if webhook is shipped; the deletion/data-handling platform rule must be satisfied; real MAX mobile/web runtime receipts must exist; and KudaGo must independently pass its provider/runtime/legal gate.

### Vulnerability claim discipline
This report does **not** claim a currently exploitable IDOR, XSS, SSRF, SQL injection or session theft without current code/runtime evidence. Their status is **potential risk**. Confirmed items are platform contracts, breaking changes, provider data hazards, retry/failure semantics, and the evidence gaps themselves.

## 3. WHAT WAS VERIFIED

**Project evidence:** current-chat frozen project context, previous security result, and the 16.09 local Git transcript/static inventory.  
**MAX:** WebApp validation/Bridge/deeplink docs; API overview/changelog; Webhook contract; Update/User objects; current developer rules/requirements; official JS SDK repository/release.  
**Provider:** KudaGo API model/text formats/licence.  
**Queue:** pg-boss repository/docs/current release/runtime floor and BullMQ v6 PostgreSQL/breaking-change facts for comparison only.  
**Observability:** Pino, Sentry JS/scrubbing, OpenTelemetry JS maturity, Prometheus Node client/naming guidance.  
**Security guidance/tools:** node-postgres, Ajv, Helmet, DOMPurify, OWASP Session/IDOR/SSRF/CSRF/XSS/Logging, Gitleaks, OSV-Scanner, Semgrep, ZAP.

**Not verified:** exact current bodies of the four canonical source-of-truth documents; current `package.json`/lockfile/Dockerfile; current contents of auth/ingress/transport/persistence/worker files; real MAX mobile/web runtime; release-container API2 TLS; deployed logs/Sentry/analytics; actual DB constraints/queue behavior; KudaGo runtime/legal approval.

## 4. CURRENT STATE AS OF 18.09.2026

The frozen mandatory path remains:

`MAX → validated MAX identity → interests/conditions → live events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → open source → optional save.`

The product remains **solo-first** and Moscow-first for the demo data gate. Social continuation is optional. Security research is not an excuse to re-introduce group-first UX, additional cities/providers, AI infrastructure or enterprise platform components.

Core data invariants remain unchanged: Event ≠ Occurrence; UNKNOWN is first-class; parse failure must not masquerade as UNKNOWN; no fake coordinates/venue/end/price; conditional/free price ambiguity must preserve raw evidence; partial provider run is not a complete snapshot; stale responses must not overwrite newer truth; provenance/source is mandatory.

Static project evidence confirms the repository baseline contained `packages/platform/auth.ts`, `ingress.ts`, `links.ts`, `transport.ts`, `governor.ts/.lua`, persistence files, `apps/api`, `apps/miniapp`, `apps/worker/main.ts`, migrations, `tests/unit/security.test.ts`, `tests/helpers/kill-worker.ts`, and integration/unit test suites. That is a useful implementation starting point, not proof that the final controls are implemented.

## 5. KEY FINDINGS

### 5.1 MAX identity validation is an exact protocol
**FACT — VERIFIED BY OFFICIAL DOCS.** MAX requires unique platform parameters, one `hash`, URL decoding, sorted keys, newline-joined launch parameters, and the two HMAC-SHA256 steps using `WebAppData` and the bot token. `initDataUnsafe` must not be used as validation authority.

**RECOMMENDATION.** Compare digests in constant time; derive the Povod actor only after validation; reject malformed/duplicate input; do not log raw initData.

**CORRECTION.** MAX recommends invalidating via `auth_date` at about one hour. A 15-minute cutoff is optional Povod hardening only after runtime verification.

### 5.2 `startapp` authenticity does not grant Povod rights
**FACT.** MAX can deliver a `start_param`/startapp payload to the mini-app.  
**INFERENCE.** A valid MAX signature authenticates the launch context and user identity; it does not by itself make an invite/plan token authorized.  
**RECOMMENDATION.** Keep public event deep links opaque but harmless; restricted capability tokens need high entropy, scope, expiry/revocation and server-side object authorization. UUID secrecy is not ACL.

### 5.3 MAX API2/certificate migration is a dated compatibility blocker
**FACT — VERIFIED BY OFFICIAL DOCS.** Since 19.07.2026 outbound API requests must target `platform-api2.max.ru`; the runtime trust store must handle the applicable certificate chain.  
**BLOCKER.** This archive does not have the current `transport.ts` body or release image. Codex/host must grep the code and capture a sanitized TLS/API receipt from the exact release environment.

### 5.4 Webhook handling must assume retries
**FACT.** MAX documents <=30-second successful acknowledgement, retry behavior and potential automatic unsubscribe after prolonged failure.  
**INFERENCE.** Side effects before durable acceptance plus no idempotency can duplicate work even with no attacker.  
**CORRECTION.** No universal top-level `update_id` is documented. Do not invent one. Use event-specific/semantic identity, DB uniqueness and business-level idempotency. A raw-body hash is only a secondary fingerprint after runtime retry-capture proves it is stable enough.

### 5.5 Queue exactly-once does not equal external exactly-once
pg-boss can provide strong job-claiming semantics inside PostgreSQL, but a message send remains ambiguous if the remote side accepts it and the local worker loses the response before committing outcome. The same is true for other at-least-once worker systems.  
**RECOMMENDATION.** Maintain a durable semantic delivery ledger with `pending`, `sent`, `failed`, and `unknown` (or equivalent) states. Do not blind-retry an ambiguous external side effect without a downstream idempotency mechanism that has actually been verified.

### 5.6 Partial provider response is often worse than a clean outage
A sync that fetches pages 1–2 then times out on page 3 must not “prove” that older records absent from pages 1–2 disappeared.  
**RECOMMENDATION.** Persist run completeness (`running|complete|partial|failed` or equivalent). Only complete reconciliation evidence may drive absence/tombstone decisions.

### 5.7 Provider data is untrusted even without a malicious provider
KudaGo officially defaults event text format to HTML, exposes a free-form `price` alongside `is_free`, allows nullable end fields, and disclaims data correctness/API availability. That means provider data can mislead Povod through ordinary inconsistency, stale data or malformed records.  
**RECOMMENDATION.** P0 should request/minimize to text fields, preserve raw price evidence and UNKNOWN, length-limit strings, validate source URLs, and avoid provider HTML entirely.

### 5.8 Public placement has a narrow but real deletion obligation
**FACT.** MAX developer rules state that an app creating an account or processing data based on the MAX account must provide a free way to delete the app account and processed data on user request.  
**SOURCE-OF-TRUTH CONFLICT CHECK.** The exact four canonical file bodies were unavailable here, so no direct conflict is claimed. If a current canonical file explicitly forbids any deletion path, mark `CONFLICT WITH CURRENT SOURCE OF TRUTH`: the conflict is frozen scope vs platform-placement obligation; criticality is high for public placement; the recommended change is the smallest compliance exception; it may be deferred only if the app is not being publicly placed or the rule trigger does not apply, subject to human legal/platform review.

### 5.9 Observability must prove P0 rather than become P0
Required evidence can be produced with structured logs, request/correlation IDs, safe error capture, health/readiness and bounded metrics. OpenTelemetry traces/metrics are stable, but logs are development and browser instrumentation is experimental/mostly unspecified. That makes a full collector/Tempo/Loki stack low-value for this deadline. Metric IDs such as user/event/request/job/source URL/search query must not become Prometheus labels because of cardinality and privacy.

## 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

See `DECISION_DELTA.md` for the complete table. Major changes: queue correction; MAX API2/certificate gate; exact webhook delivery contract; no universal update ID; deletion promoted to public-placement gate; initData 15m downgraded; query_id one-use downgraded; provider XSS claim made conditional on actual unsafe sink; full raw provider archive rejected; observability reduced; KudaGo status reaffirmed as NOT APPROVED; all implementation claims downgraded without current source/runtime proof.

## 7. CONFIRMED FACTS

1. MAX documents a deterministic HMAC validation algorithm and duplicate-parameter rule.
2. `initDataUnsafe` is not validation authority.
3. `auth_date` supports freshness checking and MAX recommends an invalidation interval around one hour.
4. `query_id` is current-session unique, not documented as a globally one-time nonce.
5. `startapp` is a launch/deeplink payload, not an application ACL.
6. `platform-api2.max.ru` is the required current API domain after 19.07.2026.
7. MAX documents a 30 rps API ceiling and recommends Webhook rather than Long Polling for production.
8. Webhook requires HTTPS/443/trusted cert and <=30s successful acknowledgement; failures may be retried and prolonged failure may remove the subscription.
9. `X-Max-Bot-Api-Secret` is supported/recommended for webhook authenticity.
10. The current documented Update schema does not provide a universal top-level `update_id`.
11. MAX `User.name` is deprecated.
12. `GET /chats` is removed and the add-members endpoint has a dated removal announcement for 30.09.2026.
13. MAX developer rules contain the account/data-deletion requirement under their stated trigger.
14. MAX developer requirements explicitly call for protection against substitution, duplication/request inflation and malicious code.
15. KudaGo defaults event text to HTML and provides text alternatives.
16. KudaGo `price` is free-form text and date end fields may be null.
17. KudaGo licence requires direct open indexable source attribution and disclaims correctness/API availability.
18. KudaGo does not expose a documented modern event `updated_since` cursor in the checked API docs; do not invent a watermark strategy.
19. pg-boss is active/not archived; current docs require Node >=22.12 and PostgreSQL >=13; GitHub API reported release 12.33.2 on 18.09.2026.
20. BullMQ v6 can use PostgreSQL, so Redis-only assumptions are stale.
21. OpenTelemetry JS traces/metrics are stable; logs are development; browser instrumentation remains experimental.
22. The modern Prometheus JS client is `@prometheus-io/client`; label cardinality must remain bounded.
23. The local project baseline contains security/worker test paths but explicitly disclaims runtime/E2E proof.

## 8. RECOMMENDATIONS

See `RECOMMENDATIONS.md`. The essential release gates are: exact MAX auth; API2/TLS; object auth/session; startapp capability semantics; webhook durable fast ACK/idempotency if used; partial/stale provider protections; honest price/time/place/coordinates; PII/secret scrubbing; DB uniqueness/transactions/timeouts; duplicate/kill-worker/provider failure injection; minimal safe health/metrics/logging; deletion/legal gate for public placement.

## 9. REJECTED / DEFERRED OPTIONS

**REJECT for P0:** new Redis solely for queue; Kafka/Redpanda; Temporal; Kubernetes/service mesh; Vault cluster; custom JWT/key-rotation framework where opaque server session works; provider HTML/rich descriptions; broad raw KudaGo archive; fake cancellation/free/place/end/coordinates inference; startapp/UUID as authorization; production Long Polling; queue exactly-once as proof of remote exactly-once; rewriting an actually E2E-green queue only for research purity.

**DEFER:** OTel Collector+Tempo; Loki/ELK; SIEM; browser OTel; Sentry Session Replay; advanced bot-abuse scoring; multi-region/HA queue; external pentest; Trusted Types; complex automated retention workflows beyond the minimum placement obligation; extra city/provider for “resilience”.

## 10. RISKS

The top-15 risk register is in `RISKS.md`. The dominant risks are identity/authz mistakes, dated MAX transport incompatibility, webhook/worker duplication, provider partial/stale data, false price/time/place certainty, DB consistency/retry behavior, and telemetry leakage. These are more likely to damage the demo than advanced attack scenarios.

## 11. BLOCKERS

**B1 — current source bodies unavailable:** file existence is evidenced; implementation is not.  
**B2 — exact canonical documents not re-opened:** current project context is authoritative, but exact bytes/hashes remain a Codex/host receipt.  
**B3 — queue/runtime compatibility:** current Node/lockfile not directly read; newest pg-boss requires Node >=22.12.  
**B4 — MAX production transport receipt absent:** API2/TLS not runtime-proven.  
**B5 — KudaGo gate open:** security research cannot approve provider.  
**B6 — real MAX clients absent:** cookie/CSP/SameSite/source-open flow needs mobile+web evidence.  
**B7 — public placement legal/manual gate:** deletion/privacy/retention/support and KudaGo attribution need human review.

## 12. OPEN QUESTIONS

See `GAPS_AND_OPEN_QUESTIONS.md`. They focus on current source/runtime state rather than new product decisions.

## 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`. The highest-value tests are MAX auth mutation, A/B IDOR, API2 TLS, webhook replay, provider partial/429/malformed/stale, duplicate queue work, kill-worker around transaction/send boundaries, DB outage and telemetry redaction.

## 14. REQUIRED MANUAL / LEGAL CHECKS

1. Re-read the actual MAX developer agreement/rules accepted by the developer entity.
2. Verify privacy/terms/support/contact material against current MAX rules.
3. Choose actual legal basis/retention windows rather than encoding research guesses.
4. Confirm the deletion process satisfies rule 4.5.5 and applicable law.
5. Confirm KudaGo direct-open-indexable attribution works legally/technically in the exact Mini App environment.
6. Confirm only permitted KudaGo material categories are used; excluded images/descriptions/logos remain out unless separately cleared.
7. Confirm Sentry/analytics/log-processing implications.

This archive is technical research, not legal advice.

## 15. EXACT CHANGES FOR «ПОВОД»

Inspect-first targets are detailed in `CODEX_ACTIONS.md`:
- `packages/platform/auth.ts`: exact MAX validator, duplicates, freshness, constant-time hardening, validated actor only.
- `packages/platform/config.ts`/`transport.ts`: API2 domain, Authorization header, timeout, 429/5xx classification, TLS receipt.
- `packages/platform/ingress.ts`: webhook secret, bounded body/schema, durable ACK, semantic idempotency.
- `packages/platform/links.ts` and mini-app launch code: startapp input-only, safe source URL lookup/allowlist, no arbitrary redirect.
- `governor.*`: bounded rate limits/TTLs.
- sessions/plans/delivery/catalog/db persistence: secure sessions, actor scope, unique constraints, delivery ledger, run completeness, stale guard, transactions/timeouts.
- `apps/worker/main.ts`: one durable queue, graceful shutdown, bounded retries/backoff, one P0 worker unless authority says otherwise.
- `apps/api`: safe errors/correlation IDs/health/readiness and minimum deletion path if public placement requires it.
- tests: expand existing security/integration suite and reuse `kill-worker.ts`.

## 16. IMPACT ON P0 / P1 / STRETCH

**P0:** no feature expansion. Impacts are identity correctness, API2 compatibility, object authorization/session hygiene, provider truthfulness, source-link safety, minimal health/logging/metrics, save idempotency. The deletion requirement is a public-placement compliance edge around existing account data, not a new event feature.

**P1:** notifications/Smart Povod require durable delivery ledger; bot webhook reliability becomes a hard gate; social flows must not rely on the member-add method announced for removal 30.09.2026.

**Stretch:** no new security-driven feature recommended. Do not add city/provider/group/map/AI/infrastructure scope.

## 17. WHAT NOT TO DO

Do not trust `initDataUnsafe`, client user IDs, startapp, UUID secrecy or queue completion as authorization/idempotency truth. Do not use the old API domain, Long Polling for production, provider HTML, arbitrary backend URL fetches, partial-sync tombstones, inferred free/venue/end/coords, high-cardinality metric labels, raw initData/tokens/PII logs, or enterprise infrastructure for its own sake. Do not upgrade a same-day library release only because it is newest. Do not mark KudaGo approved. Do not call static source inventory runtime verified.

## 18. SELF-CRITIQUE / RED TEAM

**What if pg-boss is the wrong recommendation?** If current code already has a tested BullMQ implementation, migration can create more deadline risk. Final recommendation is inspect-first and preserve a proven path. Same-day pg-boss 12.33.2 should not be adopted blindly, especially with its Node >=22.12 runtime floor.

**What if one-hour initData freshness is too loose?** It may be for a more sensitive product, but 15 minutes is not a MAX requirement. Povod’s lower-risk event domain plus server session and no financial transaction makes official guidance the better baseline until runtime evidence justifies tighter policy.

**What if global query_id replay blocking improves security?** It might, but can also break legitimate reload/reopen. The docs do not define it as a single-use nonce, so it should not become a release gate without observation.

**What if Sentry creates the privacy incident?** Browser errors/breadcrumbs/URLs can leak tokens/queries/identifiers. Sentry is useful only with project-side scrubbing and SDK filtering. If the team cannot configure that safely, structured logs alone are safer for P0.

**What if Prometheus/Grafana is overkill?** Instrumentation is valuable; running two more services may not be. This archive separates metrics emission from operating a monitoring stack.

**What if cached fallback lies more than an outage?** Then it must not be used. Last-known-good browse is allowed only with explicit freshness/stale semantics and suppression of unsafe recommendation/notification issuance.

**What if the deletion endpoint introduces a vulnerability?** It can. Deletion must require current authenticated actor ownership, clear scope and idempotency. Compliance does not justify an unauthenticated destructive endpoint.

**What if provider text is still malicious?** Plain text can still be misleading or extremely long and can contain URLs. It remains untrusted: limit length, escape output and validate the independent source URL.

**What if all scanners are green?** Gitleaks/OSV/Semgrep/ZAP cannot prove IDOR absence, correct MAX HMAC, partial-sync correctness or notification idempotency. They are supporting evidence only.

**What happens under growth?** A PostgreSQL-centered P0 reduces moving parts now, but later notification volume may justify separated workers/rate budgets and broader telemetry. That does not justify pre-emptive P0 complexity.

## 19. MISSING AREAS CHECK

### Areas added by this pass
MAX API2/certificate change; exact webhook 30s/retry/unsubscribe behavior; absence of universal documented update ID; MAX deletion rule; `User.name` deprecation; `/chats`/member-add changes; pg-boss runtime floor/same-day release caution; BullMQ PostgreSQL correction; Sentry scrubbing; OTel browser maturity; Prometheus package/cardinality change; provider correctness/availability disclaimer.

### Still impossible to close here
Current source bodies and lockfile/runtime; exact canonical-file bytes; real mobile/web behavior; release TLS; current DB constraints/queue; provider gate; deployed telemetry; legal retention/attribution interpretation.

### Requires runtime test
MAX auth, client/session, API2 TLS, webhook, provider failures, DB/worker/queue, telemetry redaction.

### Requires human/manual decision
Retention; public-placement timing; existing-queue preservation; operational alert owner.

### Requires legal consultation
MAX placement/privacy/data handling; KudaGo attribution/material rights; error/analytics vendor data processing.

### Requires Codex/host
Authority document hashes, source grep/inspection, dependency inventory, tests/receipts/scans.

### Final closed research facts
The platform/provider/library facts listed in Section 7 can be treated as verified as of 18.09.2026. Implementation/runtime claims cannot.

## 20. SOURCE MANIFEST

See `SOURCE_MANIFEST.csv` and `SOURCE_MANIFEST.json`. Primary sources were used wherever available; no major final decision depends on Reddit, random blogs or SEO summaries.

## 21. FINAL CHECKLIST

### Research quality gate
- [x] Major claims have type/status/evidence.
- [x] Time-sensitive external facts rechecked for 18.09.2026.
- [x] Official/primary sources prioritized.
- [x] Runtime claims not invented.
- [x] Previous conclusions red-teamed.
- [x] Delta documented.
- [x] MAX breaking changes documented.
- [x] Queue correction documented.
- [x] Provider remains NOT APPROVED.
- [x] P0 not silently expanded.
- [x] Compliance exception isolated from product scope.
- [x] Rejected/deferred options documented.
- [x] Open/runtime/manual/legal questions documented.
- [x] Source, claim and decision matrices included.
- [x] Machine summary and Codex handoff included.

### Release acceptance — OPEN
- [ ] Four canonical source-of-truth files directly re-opened and hashed on host.
- [ ] Current auth source reviewed.
- [ ] Current transport source reviewed for API2.
- [ ] Current Node/lockfile/queue version verified.
- [ ] MAX mobile receipt.
- [ ] MAX web receipt.
- [ ] API2 TLS receipt from release environment.
- [ ] A/B IDOR test receipt.
- [ ] Webhook replay receipt if shipped.
- [ ] Worker duplicate/crash receipt.
- [ ] Provider partial/429/malformed/stale receipts.
- [ ] UNKNOWN/price/time/place fixture suite green.
- [ ] Secret/PII telemetry scan green.
- [ ] Supporting Gitleaks/OSV/Semgrep/ZAP findings reviewed.
- [ ] Deletion/privacy/legal gate closed for public placement.
- [ ] KudaGo separate provider gate closed.

**Canonical final status: FINAL WITH OPEN BLOCKERS.**
