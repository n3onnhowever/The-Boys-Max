# Risks

| ID | Risk | Severity | Classification | Impact | Primary control | Scope |
| --- | --- | --- | --- | --- | --- | --- |
| R01 | MAX identity validator mismatch or client-trusted user id | CRITICAL | POTENTIAL VULNERABILITY | Account spoofing / cross-user access | Official-vector code review + mutation runtime tests | P0 |
| R02 | Old MAX API domain / missing required TLS trust | HIGH | CURRENT BREAKING-CHANGE RISK | Outbound MAX API failure | Grep transport/config + exact release-container TLS/API receipt | P0 |
| R03 | IDOR across plans/saves/preferences/profile | HIGH | POTENTIAL VULNERABILITY | Read/write another user’s state | Actor-scoped authorization + A/B user tests | P0 |
| R04 | startapp/invite used as authority or weak capability | HIGH | POTENTIAL VULNERABILITY | Unauthorized join/read/write | High-entropy scoped token + expiry/revocation + server authz | P0/P1 |
| R05 | Session token leakage/weak session lifecycle | HIGH | POTENTIAL VULNERABILITY | Session takeover | Opaque CSPRNG session, narrow cookie policy, expiry/revocation, redaction | P0 |
| R06 | Webhook spoof/replay/slow acknowledgement | HIGH | PLATFORM DELIVERY RISK + POTENTIAL VULNERABILITY | Forged/duplicate actions or subscription loss | Secret verification + durable fast ACK + semantic idempotency | P0/P1 if webhook shipped |
| R07 | Worker replay or ambiguous outbound side effect | HIGH | CONFIRMED FAILURE MODE | Duplicate/lost notification | Durable delivery ledger + unique semantic key + `unknown` outcome | P1 notifications |
| R08 | Partial provider run interpreted as complete | HIGH | DATA CORRECTNESS RISK | Mass false withdrawal/tombstone | Run completeness state; absence only from complete reconciliation | P0 |
| R09 | Stale/cancelled/wrong-time/wrong-timezone event presented as live truth | HIGH | DATA CORRECTNESS RISK | User goes to wrong/nonexistent event | Freshness, timezone tests, stale suppression, provenance/source | P0 |
| R10 | Conditional/free price misclassified | HIGH | DATA CORRECTNESS RISK | False free/exact-price claim | Raw price + conditional/UNKNOWN semantics + fixtures | P0 |
| R11 | Provider HTML/URL reaches unsafe sink | MED-HIGH | POTENTIAL VULNERABILITY | XSS/open redirect/SSRF | Minimal text fields, escaping, URL allowlist, no arbitrary server fetch | P0 |
| R12 | DB partial transaction / uniqueness gap / pool/deadlock | HIGH | RELIABILITY RISK | Corrupt state/outage/duplicates | Single-client tx, DB constraints, bounded pool/timeouts, deterministic lock order | P0 |
| R13 | Retry storm / 429 disregard / MAX rate ceiling | MED-HIGH | RELIABILITY RISK | Amplified outage/throttling | Single retry owner, bounded attempts, backoff+jitter, Retry-After | P0/P1 |
| R14 | Secrets/PII in logs, Sentry or analytics | HIGH | PRIVACY/SECURITY RISK | Credential or personal-data leak | Redaction + allowlisted telemetry fields + scan receipts | P0 |
| R15 | Missing deletion/retention/legal-data handling path | HIGH | PLATFORM COMPLIANCE BLOCKER | Public placement rejection/noncompliance | Minimal deletion path + notices + human legal review | Public-placement gate |

## Classification discipline
- **POTENTIAL VULNERABILITY** means exploitability is not proven without current source/runtime evidence.
- **CONFIRMED FAILURE MODE / CURRENT BREAKING-CHANGE RISK** is backed by platform/provider/queue contracts or dated change notices.
- **DATA CORRECTNESS RISK** can make «Повод» lie without an attacker.
- **PLATFORM COMPLIANCE BLOCKER** can block public placement even when a controlled demo works.
