# Gaps and Open Questions

## Blockers
1. Exact current bodies/hashes of the four canonical project source-of-truth files were not directly re-opened in this pass.
2. Current source bodies for auth/ingress/transport/persistence/worker were not directly inspected.
3. Current Node version, lockfile and chosen queue package/version were not directly read.
4. Real MAX mobile/web runtime receipt is absent.
5. `platform-api2.max.ru` TLS/API receipt from the exact release runtime is absent.
6. KudaGo runtime/legal data gate remains open.
7. Public-placement deletion/privacy/legal gate remains open.

## Open questions
- Does `auth.ts` exactly follow current MAX HMAC/duplicate-param/freshness rules and use constant-time compare?
- Where is the application session stored/transmitted? Does the chosen SameSite/CSP/frame policy work in both MAX mobile and web?
- Is `platform-api.max.ru` still referenced anywhere? Does the release image trust the required chain?
- Is `User.name`, removed `GET /chats`, or the soon-removed member-add endpoint used anywhere?
- Which DB unique constraints protect occurrences, saves, memberships and delivery semantics?
- What makes an ingestion run `complete` rather than `partial`? Can stale responses overwrite newer data?
- What happens if the worker dies after MAX accepts a send but before local completion?
- Are raw initData, cookies, tokens, MAX IDs, IPs, source URLs or search text sent to logs/Sentry/analytics?
- Does the backend fetch arbitrary/provider-controlled URLs or expose a generic redirect endpoint?
- Is any provider HTML rendered through `dangerouslySetInnerHTML`/`innerHTML`?
- Does a user-data deletion path exist today, and what retention policy has been approved?
- Does KudaGo’s direct open indexable attribution condition work legally/technically inside the exact MAX Mini App flow?

## Requires runtime test
MAX auth mutations; MAX mobile/web session launch/reload; API2 TLS; webhook replay; DB/worker crash; provider partial/429/malformed/stale cases; duplicate suppression; telemetry redaction.

## Requires human/manual decision
Retention windows; public-placement timing; whether an already-real BullMQ path is sufficiently green to preserve; operational alert owner/channel.

## Requires legal check
MAX placement/licence/privacy/support obligations; deletion/legal basis/retention; KudaGo attribution/material-use applicability; analytics/error-vendor data processing.

## Requires Codex/host
Source-of-truth hash receipt; dependency/runtime inventory; source greps; test implementation; runtime receipts; scanner reports.

## Closed by this research
Official MAX initData algorithm; `initDataUnsafe` non-authority; ~1h auth_date guidance; API2 domain change; webhook transport/retry contract; deletion-rule existence; `User.name` deprecation; `/chats` breaking changes; KudaGo HTML/price/null-end/licence facts; OTel JS signal maturity; BullMQ v6 PostgreSQL-backend fact; pg-boss current runtime floor/repository activity; rejection of enterprise-security/observability expansion for P0.
