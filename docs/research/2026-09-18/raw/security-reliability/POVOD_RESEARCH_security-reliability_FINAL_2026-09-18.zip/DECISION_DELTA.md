# Decision Delta

| Area | PREVIOUS CONCLUSION | FINAL VERIFIED CONCLUSION | Why/source | Impact |
| --- | --- | --- | --- | --- |
| Queue baseline | BullMQ/Redis was discussed as if it were the likely P0 queue. | Canonical direction is PostgreSQL + pg-boss in the existing worker if compatible/currently selected; keep an already E2E-green BullMQ path rather than rewriting. | Current project architecture context; pg-boss/BullMQ official docs. | Avoids an unnecessary Redis/service migration. |
| BullMQ architecture fact | BullMQ was implicitly treated as Redis-only. | BullMQ v6 supports a PostgreSQL backend. This fact is corrected, but introducing BullMQ still does not help frozen P0. | BullMQ v6 official PostgreSQL docs/changelog. | Corrects a stale technical assumption without changing P0. |
| MAX API transport | Not a first-class blocker in the previous result. | From 19.07.2026 MAX API requests must use `platform-api2.max.ru`; exact release runtime must trust the required certificate chain. | MAX API changelog/overview/webhook docs. | Can otherwise break all outbound MAX calls. |
| Webhook contract | Secret/replay/idempotency emphasized, but exact transport contract was under-specified. | Webhook: HTTPS/443, trusted cert, 200 in <=30s, retry up to 10 times, prolonged failure may auto-unsubscribe. | MAX POST /subscriptions docs. | Adds an exact runtime acceptance receipt. |
| Webhook dedupe identity | Could be read as if a universal update id exists. | No universal top-level `update_id` is documented; use event-specific semantic keys + DB uniqueness. Raw-body hash is secondary only after runtime retry evidence. | MAX Update schema. | Prevents an invented idempotency authority. |
| initData freshness | 15 minutes was proposed as must-fix. | Official guidance recommends invalidation around one hour. Narrower TTL is optional hardening after runtime UX verification. | MAX Bridge docs. | Removes unnecessary platform-unsupported strictness. |
| query_id replay | Replay TTL/single-use could be read as broadly required. | `query_id` is documented as current-session unique, not as a one-time nonce. Do not globally burn it without launch/reload runtime evidence. | MAX Bridge docs. | Avoids breaking valid reload/reopen paths. |
| Deletion / retention | Account deletion could be deferred after hackathon. | MAX placement rules require a free deletion path for app account/processed MAX-based data when rule 4.5.5 trigger applies. | MAX developer rules revision 11.06.26. | Public-placement compliance gate; narrow exception, not product expansion. |
| MAX compatibility | Not highlighted. | `User.name` is deprecated; `GET /chats` removed; adding members endpoint scheduled for removal 30.09.2026. | MAX User object/API changelog. | Mostly P1/social, but requires code grep. |
| Provider HTML | XSS was phrased too close to a confirmed vulnerability. | KudaGo HTML default is confirmed; exploitable XSS remains only a potential vulnerability until an unsafe render sink is proven. Prefer text/minimal fields. | KudaGo API + OWASP XSS. | Improves claim discipline. |
| Provider raw archive | Broad raw/versioned payload storage could appear generally desirable. | Full raw archive is rejected/deferred for P0; keep normalized fields, provenance and explicitly required raw fragments only. | Project Data Safety context + KudaGo licence. | Reduces legal/storage/security surface. |
| Observability | Pino + Sentry + Prometheus + Grafana looked like the mandatory minimal stack. | Minimal requirement is structured logs + error capture + health/readiness + metrics instrumentation; self-hosted Prometheus/Grafana only if already available/trivial. | OTel/Prometheus/Sentry/Pino primary docs. | Avoids two extra services solely for the hackathon. |
| OpenTelemetry | Useful but ambiguous adoption pressure. | Traces/metrics stable; logs development; browser instrumentation experimental/mostly unspecified. Full collector/Tempo/Loki deferred. | OpenTelemetry JS official docs. | Clear defer decision. |
| Provider status | Could be misread as if KudaGo is active. | KudaGo remains NOT APPROVED; Moscow runtime/legal provider gate remains open. | Project provider gate + KudaGo primary docs. | Preserves frozen data gate. |
| Runtime confidence | Control recommendations were precise enough to sound implemented. | All current-control implementation claims are downgraded to NEEDS SOURCE/RUNTIME VERIFICATION unless direct evidence exists. | Local baseline transcript explicitly disclaims runtime acceptance. | Prevents false release confidence. |

## UNCHANGED AFTER VERIFICATION
- Server-side MAX identity validation remains mandatory.
- Object-level authorization remains mandatory for user-owned state.
- `startapp` is input, not authorization.
- Partial provider runs cannot prove absence.
- Event ≠ Occurrence; UNKNOWN/provenance/source remain first-class.
- Provider HTML is not needed in P0.
- Business side effects require idempotency even if a queue deduplicates jobs.
- PII/secrets must be excluded from observability.
- Targeted failure injection is more valuable than enterprise infrastructure.
