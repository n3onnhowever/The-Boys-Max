# Actionable Recommendations for «Повод»

## Must verify/fix before controlled demo
1. Validate current `packages/platform/auth.ts` against the current MAX algorithm; reject malformed/duplicate params; validate freshness; derive actor only after successful signature verification.
2. Verify `packages/platform/transport.ts` and the exact release image use `https://platform-api2.max.ru` and trust the required certificate chain.
3. Enforce object-level authorization on all user-owned state; add A/B user tests.
4. Treat every `startapp` value as input. Restricted invite/capability semantics must be high-entropy, scoped, expiring/revocable and checked server-side.
5. If Webhook is shipped: verify `X-Max-Bot-Api-Secret`, durably accept before `200`, keep acknowledgement well below 30s, and make business side effects idempotent.
6. Model provider sync completeness explicitly; a partial page set must never support absence/tombstone reconciliation.
7. Preserve raw price fragment + conditional/UNKNOWN semantics; never invent venue/end/coordinates/price.
8. Avoid KudaGo/provider HTML in P0; use only minimal fields/text.
9. Scrub raw initData, tokens, raw MAX IDs, IPs and sensitive URLs/queries from logs/Sentry/analytics.
10. Use a user-safe correlation ID on errors.
11. Verify DB transactions, unique constraints, pool bounds and timeouts.
12. Run duplicate-job, worker-kill, DB-down, 429, malformed/partial/stale-provider failure tests.

## Queue
- Prefer the current canonical PostgreSQL + pg-boss path **only after current runtime/dependency compatibility is confirmed**.
- If BullMQ is already integrated and E2E-green, do not rewrite near the deadline for architectural purity.
- Do not add Redis solely because the previous red-team mentioned it.
- Persist notification delivery outcome independently of queue completion.

## Minimal observability
- structured JSON logs (Pino or existing equivalent);
- `request_id`, user-safe `correlation_id`, release SHA;
- safe error capture (Sentry/equivalent) only with scrubbing;
- `/health/live` and `/health/ready`;
- bounded-cardinality API/provider/ingestion/queue/data-quality/DB metrics;
- existing dashboard/scraper if available.

Self-hosted Prometheus/Grafana is optional, not a mandatory P0 dependency. Full OTel Collector/Tempo/Loki is deferred.

## Public placement
- implement the minimum safe account/data deletion flow if missing and if MAX rule 4.5.5 trigger applies;
- publish/verify required legal/support information;
- close KudaGo’s separate legal/data/runtime gate;
- capture real MAX mobile + web receipts.
