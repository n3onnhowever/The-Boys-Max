# PRIMARY WEB SOURCES SNAPSHOT

Accessed: 2026-09-18.

Full copyrighted pages are not copied. First-party references are preserved.

## Discovery / feed / search
- DICE personalization: https://dicefm.zendesk.com/hc/en-gb/articles/43436499448209-How-to-personalise-your-DICE-feed
- DICE discovery: https://dicefm.zendesk.com/hc/en-gb/articles/22365220986897-How-to-find-events-you-ll-love-on-DICE
- Luma search: https://help.luma.com/p/searching-for-events
- Eventbrite app: https://www.eventbrite.com/help/en-us/articles/783059/
- Yandex Afisha: https://afisha.yandex.ru/moscow/selections/best-events

## Detail / occurrence / price
- DICE times: https://dicefm.zendesk.com/hc/en-gb/articles/36839407078673-How-to-view-the-event-times
- Fever: https://feverup.com/m/529498/en
- KudaGo: https://kudago.com/msk/events/
- Resident Advisor: https://ra.co/events/2481697
- Timepad empty state: https://afisha.timepad.ru/kvitok

## Save / follow / retention
- Ticketmaster app: https://help.ticketmaster.com/hc/en-us/articles/22926422411537-How-do-I-use-the-Ticketmaster-App
- Ticketmaster alerts/favorites: https://help.ticketmaster.com/hc/en-us/articles/9613319708561-How-do-I-get-alerts-about-new-events
- Bandsintown artist follow: https://help.bandsintown.com/en/articles/3652370-how-do-i-follow-an-artist
- Bandsintown venue/festival follow: https://help.bandsintown.com/en/articles/3652392-can-i-follow-venues-or-festivals
- Luma notification types: https://help.luma.com/p/notification-types

## Changes / social
- Luma event updates: https://help.luma.com/p/updating-event-information
- Partiful Find a Time: https://help.partiful.com/en-us/articles/15525423-using-find-a-time-to-poll-guests-on-date-and-time
- Partiful date/time edit: https://help.partiful.com/en-us/articles/15525367-how-do-i-change-the-date-and-time-on-my-event
- Partiful Group Reminder: https://help.partiful.com/en-us/articles/15774034-what-is-group-reminder
- Rallly mobile redesign: https://landing.rallly.co/blog/mobile-voting-redesign
- LINE Schedule: https://help.line.me/line/smartphone?contentId=20023797&lang=en

## Asia
- Damai App Store: https://apps.apple.com/cn/app/id513829338
- Damai official Weibo `想看`: https://weibo.com/1722647874/5180323505374016

These links are pattern evidence, not Povod runtime evidence.
