# MAX OFFICIAL DOCS SNAPSHOT — 2026-09-18

Primary sources:
- https://dev.max.ru/docs
- https://dev.max.ru/docs/webapps/bridge
- https://dev.max.ru/docs-api/changelog-api
- https://dev.max.ru/docs-api/methods/POST/chats/-chatId-/members
- https://dev.max.ru/docs/legal/rules
- https://dev.max.ru/docs/legal/requirements
- https://dev.max.ru/help/miniapps

## Verified by official docs

- Mini Apps are tied to MAX platform/chatbot context.
- Bridge exposes BackButton, openLink/openMaxLink, shareContent, shareMaxContent and haptic APIs.
- `shareContent` is supported on iOS/Android and explicitly not web.
- haptic methods are explicitly unsupported on desktop/web.
- API requests must use `platform-api2.max.ru` from 2026-07-19.
- `GET /chats` is no longer supported since June 2026.
- `POST /chats/{chatId}/members` is restricted from 2026-09-09 and removed 2026-09-30; docs state no ready add-participant API remains after that.
- Platform placement has legal/partner requirements.

## Not verified by runtime

- Povod `shareMaxContent` E2E on every target client.
- occurrence deep-link roundtrip.
- BackButton lifecycle with current router.
- actual team account/legal readiness.
