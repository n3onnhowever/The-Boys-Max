# PROJECT SOURCE BOUNDARY

## Directly inspected

`POVOD_TEST_DECK_V1.pptx`, File Library, dated 2026-09-17.

Relevant content:
- Povod is a personal event guide inside MAX.
- `SOLO FIRST / SOCIAL NEXT`.
- Personal value completes before group creation.
- Poster Pop in brand; clean/calm working UI.
- Favorites, follows, preferences and Smart Povod are conceptualized.
- Historical roadmap says MVP `2–3 города`.
- Pilot explicitly `NOT RUN`.
- Runtime/providers/measured results are explicitly not presented as confirmed.

## Conflict

Current 2026-09-18 project instruction freezes P0 as one working city (Moscow). Therefore the deck's `2–3 города` line is superseded.

## Not directly retrieved

File Library search did not return:
- POVOD_FINAL_SCOPE_FREEZE_MVP.md
- POVOD_PRODUCT_SPEC_V1.md
- POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md
- POVOD_PRODUCT_CONTRACT_V1.json
- POVOD_UI_TRANSLATION_V2_SPEC.md

This is an access limitation, not evidence of absence.

The current 18 Sep research instruction directly restates the frozen core and is the authority boundary used for this archive.
