# EXECUTIVE VERDICT

## Verdict

**Keep the current product and brand direction. Do not expand P0.**

The final verified P0 UX target is:

**MAX → validated identity → interests/conditions → live Moscow events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → original source → optional save.**

## Recommend

1. Occurrence-first cards and detail hierarchy.
2. Typed UNKNOWN states.
3. Mandatory source/provenance; freshness only when evidence exists.
4. `Save != Follow != Going`.
5. Structured search/filters in P0.
6. Factual recommendation reasons only.
7. Explicit changed/cancelled/moved states when the data layer can prove them.
8. Poster Pop strongest at emotional moments; calmer feed/search/filter/settings.
9. MAX native Back/share primitives only after runtime verification.
10. Keep map optional after stable core.

## Do not recommend

- mandatory group scenario;
- full Partiful/Rallly scheduling poll in hackathon scope;
- map as a new primary bottom-navigation destination;
- fake freshness (“checked today”) without a defensible timestamp;
- `0 ₽` for unknown price;
- fake coordinates;
- one heart for save + follow + RSVP;
- “AI recommends” or match percentages without evidence;
- group-member automation via MAX API;
- claiming MAX UI compatibility without a build/client spike.

## Main blockers

- direct canonical spec files were not retrievable in this session;
- no Povod runtime test was run;
- MAX share/deeplink cross-client behavior remains runtime-required;
- MAX UI v0.5.0 compatibility is unproven;
- MAX platform/legal readiness needs manual confirmation;
- provider/legal approval remains outside this UX archive.

## Next actions

- finish/verify P0 feed/search/detail/source/save/states;
- run MAX Bridge client spike before P1/Stretch social;
- run MAX UI compatibility spike only if the library is being adopted;
- add tests for UNKNOWN, state separation, source link, occurrence identity and save persistence.
