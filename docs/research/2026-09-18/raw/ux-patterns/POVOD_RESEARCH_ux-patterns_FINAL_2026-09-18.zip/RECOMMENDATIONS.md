# RECOMMENDATIONS

## P0 — do now

1. Make Occurrence facts the primary scan line on cards/detail.
2. Render typed UNKNOWN for price/time/place; never synthesize missing values.
3. Keep source/provenance visible with `Открыть первоисточник`.
4. Never show a freshness label unless timestamp semantics are defensible.
5. Keep Save as the only universal intent action in P0.
6. Keep structured search + compact decision-critical filters.
7. Distinguish loading / empty / error / source-unavailable.
8. Do not expose unsupported cities.
9. Do not render map pins without trusted coordinates.
10. Keep operational UI calm; Poster Pop remains controlled brand/emotional intensity.
11. Add material-change status if the data layer actually exposes change evidence.
12. Add regression tests preventing UNKNOWN price from becoming free/zero.

## P1 — after stable core

- artist/topic Follow;
- one Smart Povod loop through MAX bot;
- factual recommendation reason;
- minimal notification preferences;
- map only if core and coordinate quality are already stable.

## Stretch

- user-initiated invite/share to a chosen occurrence;
- minimal `Иду / Может быть / Не смогу` shared plan;
- second city only after its own data gate.

## Explicitly defer

- full social planner;
- scheduling polls;
- social graph;
- team/venue follow unless already naturally supported;
- conversational AI search;
- match percentages;
- ticket purchase/resale/seating;
- multi-provider UX before data/legal gates.
