# RISKS

## P0 product / UX

| Risk | Severity | Mitigation |
|---|---|---|
| Event/Occurrence conflation | HIGH | Occurrence-first contract |
| UNKNOWN rendered as fake value | HIGH | Typed unknown + tests |
| Source outage shown as no events | HIGH | Separate source-unavailable |
| Save loses occurrence identity | HIGH | Stable identity + current-status recheck |
| Unsupported city exposed | HIGH | Moscow-only P0 gate |
| False freshness | HIGH | Evidence-gated copy |
| Material change silently overwritten | HIGH | Status/diff |
| Poster-first feed hides facts | MEDIUM | Calm factual hierarchy |
| Filter overload | MEDIUM | Only decision-critical filters |

## MAX / technical

| Risk | Severity | Evidence | Mitigation |
|---|---|---|---|
| Group-member API removal | HIGH | MAX-004 | Never make it social foundation |
| API endpoint migration missed | HIGH | MAX-003 | Audit `platform-api2` config |
| Bridge client differences | HIGH | MAX-002 | Runtime matrix |
| `shareContent` assumed on web | MEDIUM | MAX-002 says unsupported | Fallback |
| Haptics assumed desktop/web | LOW | MAX-002 says unsupported | Progressive enhancement |
| MAX UI integration churn | MEDIUM | v0.5.0 / active pre-1.0 | Selective use + pin + spike |
| MAX partner/legal setup incomplete | HIGH | MAX-001/MAX-005 | Manual/legal gate |

## Legal/data

- competitor interfaces are references, not assets to copy;
- no third-party screenshot binaries are packaged;
- KudaGo/Yandex/etc. UX does not grant data reuse rights;
- MAX placement and provider rights require separate legal checks.

## Scope/operational

- map/social work can consume P0 stabilization time;
- Smart Povod can become spam if reasons/dedup are weak;
- provider outage can look like “0 events” if state model is wrong.
