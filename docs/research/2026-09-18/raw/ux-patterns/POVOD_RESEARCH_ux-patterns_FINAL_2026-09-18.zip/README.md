# POVOD RESEARCH — UX PATTERNS

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** feature-level UX patterns / retention / Smart Povod / social continuation  
**Research version:** FINAL-2026-09-18  
**Date:** 2026-09-18  
**Verification status:** FINAL WITH OPEN BLOCKERS  
**Previous result:** feature-level UX research in this chat, 2026-09-18

## What is inside

Canonical verification package for the UX-pattern research from this chat:

- `FINAL_REPORT.md` — full verified report;
- `EXECUTIVE_VERDICT.md` — short verdict;
- `FACT_CHECK_MATRIX.csv` and `CLAIMS_EVIDENCE.csv`;
- `SOURCE_MANIFEST.csv/.json`;
- `DECISION_MATRIX.csv`;
- `DECISION_DELTA.md`;
- `GAPS_AND_OPEN_QUESTIONS.md`;
- `RECOMMENDATIONS.md`;
- `RISKS.md`;
- `RUNTIME_VERIFICATION_REQUIRED.md`;
- `CODEX_ACTIONS.md`;
- `DESIGNER_REFERENCES.md`;
- `machine_summary.json`;
- `evidence/` supporting snapshots/indexes.

## Final status

**FINAL WITH OPEN BLOCKERS.**

The research is sufficient to guide design and implementation, but intentionally does not claim closure on:

1. exact named canonical source-of-truth files — they were not returned by File Library search in this session;
2. Povod runtime/client behavior — no run was executed here;
3. exact MAX share/deeplink behavior across all clients;
4. MAX UI v0.5.0 compatibility with the project;
5. MAX/platform legal/account readiness;
6. provider legal/data approval, which belongs to the dedicated provider/legal research.

## Main conclusion

Do **not** redesign the product and do **not** expand the frozen P0.

Keep:

**occurrence-first decision UI → honest UNKNOWN → visible source → original source → optional save**

with a calmer operational UI than the Poster Pop brand layer.

Key corrections after verification:

- `Save`, `Follow`, `Going` remain separate intents and scope levels.
- Source is mandatory; freshness copy is conditional on real evidence.
- `Список | Карта` is the preferred pattern **if map ships**, but map itself must not block P0.
- Smart Povod reasons must be factual, not “AI magic”.
- Social continuation should be user-initiated share/deeplink, not programmatic group-member management.
- MAX UI is active/current but must be runtime-tested before broad adoption.
