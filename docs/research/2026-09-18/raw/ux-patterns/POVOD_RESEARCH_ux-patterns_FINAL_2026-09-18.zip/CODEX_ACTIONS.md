# CODEX ACTIONS

## Boundary

Repository HEAD was not available here. **Do not invent file paths.** First discover the real files.

Do not change:
- frozen P0;
- solo-first;
- Moscow-first;
- Event != Occurrence;
- UNKNOWN rules;
- provenance/source;
- brand palette/type system;
- primary navigation unless the directly opened UI Translation says otherwise.

## A. Read-only inventory first

```bash
git status --short
git rev-parse --show-toplevel
rg -n "Для тебя|Поиск|Сохранённые|Мой Повод|EventCard|Occurrence|Price|UNKNOWN|source|favorite|save|shareMaxContent|BackButton" .
```

Record:
- routes;
- event card/detail;
- search/filters;
- saved;
- profile/preferences;
- Bridge wrapper;
- data types/schema;
- tests;
- feature flags;
- package versions.

## B. P0 data/UI audit

Verify invariants:

1. unknown price cannot render as zero/free;
2. unknown time cannot become midnight;
3. unknown coordinates cannot create a pin;
4. source URL is validated and displayed;
5. source-unavailable != zero results;
6. cards/detail resolve the correct Occurrence;
7. save persists using the stable identity already defined by Product Contract.

## C. State components

Ensure separate paths/tests for:
- loading;
- empty;
- error;
- source unavailable;
- populated;
- changed/cancelled if data exists.

## D. Recommendation reason

If already present:
- remove generic “AI recommends” copy;
- map real reason codes to copy;
- suppress any reason whose input is unknown;
- never say “within budget” unless the occurrence price rule proves it.

If not already in P0/P1 implementation, do not add it just because this research mentions it.

## E. Map

If not stable:
- feature-flag/defer;
- do not block P0.

If it exists:
- list/map share query and filters;
- no pin for unknown coordinates;
- pin opens exact event/occurrence;
- no new Map bottom tab.

## F. MAX Bridge spike

Use the existing wrapper if present; do not create a second integration layer.

Verify:
- `BackButton`;
- `openLink`;
- `shareMaxContent`;
- feature detection/fallback.

**Do not implement social using `POST /chats/{chatId}/members`; MAX removes it on 2026-09-30.**

## G. MAX UI spike

Before importing/expanding `@maxhub/max-ui`:
1. inspect current `package.json`;
2. compare React versions with max-ui v0.5.0 peer dependencies;
3. disposable branch;
4. integrate one low-risk primitive;
5. build + target-client smoke;
6. record CSS/bundle/runtime evidence;
7. revert if it creates P0 churn.

Prefer selective native primitives over a wholesale rewrite.

## H. Tests

Add equivalents under existing test conventions:
- event card exact/unknown price;
- occurrence unknown time;
- no fake map pin;
- source CTA;
- empty vs source-unavailable;
- save persistence;
- changed/cancelled state;
- reason suppression on unknown data;
- Bridge fallback;
- invalid/expired deep-link payload when P1/Stretch is implemented.

## I. Evidence

Record:
- commit SHA;
- lockfile state;
- MAX client/version;
- screenshots;
- logs;
- pass/fail matrix;
- repro steps.

## J. Non-actions

Do not:
- add another city;
- add full shared planning;
- add group-member management;
- add conversational AI search;
- add Map/Social bottom tabs;
- rewrite the design system;
- change fonts/palette;
- import competitor assets into production;
- change provider logic based on this UX research.
