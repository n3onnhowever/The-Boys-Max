# 20 UI / INTERACTION REFERENCES FOR DESIGNER

## 01. DICE — Personalized feed feedback

**Feature:** Into it / Not it; location selector

**Reference:** https://dicefm.zendesk.com/hc/en-gb/articles/43436499448209-How-to-personalise-your-DICE-feed

**Povod note:** P1 preference-learning reference; not required P0.

## 02. DICE — Discovery + map

**Feature:** Map nested inside discovery/search

**Reference:** https://dicefm.zendesk.com/hc/en-gb/articles/22365220986897-How-to-find-events-you-ll-love-on-DICE

**Povod note:** Use only if map ships after core.

## 03. DICE — Event times

**Feature:** Explicit time area

**Reference:** https://dicefm.zendesk.com/hc/en-gb/articles/36839407078673-How-to-view-the-event-times

**Povod note:** Do not infer Povod always knows end time.

## 04. Luma — Search + map

**Feature:** Location-aware search/map exploration

**Reference:** https://help.luma.com/p/searching-for-events

**Povod note:** Structural reference, not scope mandate.

## 05. Luma — Material updates

**Feature:** Name/start/duration/location changes

**Reference:** https://help.luma.com/p/updating-event-information

**Povod note:** Translate to changed-state/diff.

## 06. Luma — Notification preferences

**Feature:** Semantic reminder/update categories

**Reference:** https://help.luma.com/p/notification-types

**Povod note:** P1; simplify for MAX bot.

## 07. Resident Advisor — Dense event detail

**Feature:** Venue/date/time/promoter/admin/last updated/cost

**Reference:** https://ra.co/events/2481697

**Povod note:** Excellent factual density; only show known fields.

## 08. Яндекс Афиша — Date strip + filters

**Feature:** Russian-market date/filter pattern

**Reference:** https://afisha.yandex.ru/moscow/selections/best-events

**Povod note:** Familiarity reference.

## 09. KudaGo — Russian date/price strings

**Feature:** Schedules and free/range/conditional price language

**Reference:** https://kudago.com/msk/events/

**Povod note:** UX only; not provider approval.

## 10. Bandsintown — Taste onboarding

**Feature:** Music-service scan as preference import

**Reference:** https://help.bandsintown.com/en/articles/3652358-how-can-i-connect-my-account-to-other-music-services

**Povod note:** Concept only; don't require external music account.

## 11. Bandsintown — Artist follow

**Feature:** Entity-level future interest

**Reference:** https://help.bandsintown.com/en/articles/3652370-how-do-i-follow-an-artist

**Povod note:** P1 follow reference.

## 12. Ticketmaster — Save vs favorite

**Feature:** Bookmark saved events; heart favorite artists

**Reference:** https://help.ticketmaster.com/hc/en-us/articles/22926422411537-How-do-I-use-the-Ticketmaster-App

**Povod note:** Strong precedent for Save != Follow.

## 13. Ticketmaster — Team/venue favorites

**Feature:** Performers, teams, venues share favorites model

**Reference:** https://help.ticketmaster.com/hc/en-us/articles/9613319708561-How-do-I-get-alerts-about-new-events

**Povod note:** Scale model; team/venue follow deferred.

## 14. Partiful — Find a Time

**Feature:** Yes / No / Maybe before final time

**Reference:** https://help.partiful.com/en-us/articles/15525423-using-find-a-time-to-poll-guests-on-date-and-time

**Povod note:** Shared-plan reference only.

## 15. Partiful — Event-change anti-pattern

**Feature:** Date/time edits do not auto-notify guests

**Reference:** https://help.partiful.com/en-us/articles/15525367-how-do-i-change-the-date-and-time-on-my-event

**Povod note:** Warning against silent commitment transfer.

## 16. Rallly — Mobile 3-state selector

**Feature:** Yes / If need be / No visible simultaneously

**Reference:** https://landing.rallly.co/blog/mobile-voting-redesign

**Povod note:** Best simple RSVP reference if Stretch ships.

## 17. LINE Schedule — Messenger-native planning

**Feature:** Create/share schedule from chat and RSVP

**Reference:** https://help.line.me/line/smartphone?contentId=20023797&lang=en

**Povod note:** Social-next inspiration only.

## 18. Eventbrite — Search/filter/save

**Feature:** Date/category/price/type; event like; organizer follow

**Reference:** https://www.eventbrite.com/help/en-us/articles/783059/

**Povod note:** Filter and distinct-follow reference.

## 19. Fever — Date/session picker

**Feature:** Choose date, slot and session-specific price

**Reference:** https://feverup.com/m/529498/en

**Povod note:** Occurrence selector; reject ticketing complexity.

## 20. MAX — Bridge-native interactions

**Feature:** BackButton, shareMaxContent, openLink/openMaxLink, haptics constraints

**Reference:** https://dev.max.ru/docs/webapps/bridge

**Povod note:** Behavior reference; exact Povod runtime still required.


## Packaging note

No third-party screenshot binaries are included. The archive preserves first-party source URLs instead, avoiding redistribution of copyrighted UI assets and reducing stale-screenshot risk.
