# FINAL REPORT — UX PATTERNS

**Project:** «Повод» / The Boys  
**Date:** 2026-09-18  
**Research version:** FINAL-2026-09-18  
**Verification status:** FINAL WITH OPEN BLOCKERS

## 1. EXECUTIVE SUMMARY

This is a verification pass over the existing feature-level UX research, not a new product concept.

The central conclusion survives: Povod should borrow **feature-level interaction patterns from different products**, while preserving its own frozen product contract.

Strongest verified donor groups:

- **DICE / Luma / Resident Advisor / Yandex Afisha** — discovery, filters, factual density;
- **Fever** — occurrence/session selection;
- **Ticketmaster / Bandsintown** — save/follow/return semantics;
- **Partiful / Rallly / LINE** — optional social continuation;
- **MAX Bridge** — MAX-native shell interactions.

The verified result is more conservative than the previous answer:

1. Source is mandatory; freshness is conditional.
2. Map/list is a good interaction pattern **if map ships**, but map itself is not mandatory P0.
3. MAX share/deeplink primitives exist, but Povod end-to-end behavior remains runtime-unverified.
4. MAX group-member addition is being removed on 2026-09-30 and must not become social infrastructure.
5. MAX UI is verified at v0.5.0 (2026-09-15), active and pre-1.0; compatibility is unproven.
6. Save ≠ Follow now has direct primary evidence from Ticketmaster.
7. Partiful’s no-auto-notify behavior for date/time edits is verified and remains an anti-pattern.
8. Rallly’s 2026-08-14 mobile redesign is a strong current 3-state interaction reference.
9. Partiful Group Reminder is newly identified but remains over-scope and limited-release.
10. The older deck’s “2–3 cities” MVP line is superseded by the Moscow-first freeze.

## 2. FINAL VERDICT

**Keep the existing product and brand direction. Do not expand P0.**

Povod should be a **decision interface around a concrete Occurrence**, not a poster gallery, ticketing stack or social planner.

Canonical P0 target:

**MAX → validated identity → interests/conditions → live Moscow events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → original source → optional save.**

Stable UX rules:

- Event != Occurrence;
- UNKNOWN is first-class;
- provenance/source visible;
- hard constraints before ranking;
- no fake price/time/location/coordinates;
- Save is a distinct P0 intent;
- operational UI calmer than Poster Pop brand layer;
- social is optional continuation;
- P1/Stretch cannot block P0.

No evidence justifies changing the agreed brand, palette or typography.

## 3. WHAT WAS VERIFIED

### Project evidence

- Current 18 Sep canonical instruction and frozen P0 boundary.
- `POVOD_TEST_DECK_V1.pptx`, directly inspected from File Library.
- File Library search for exact named canonical spec/contract/translation files.

### External primary sources

Current/still-live first-party sources were verified for:

- MAX docs, Bridge, API changelog, group-member deprecation, legal rules;
- official max-messenger/max-ui GitHub repository/release/package metadata;
- DICE;
- Bandsintown;
- Luma;
- Partiful;
- Rallly;
- Ticketmaster;
- Eventbrite;
- Yandex Afisha;
- KudaGo;
- Timepad;
- Fever;
- Resident Advisor;
- LINE Schedule;
- Damai.

No runtime speed/stability/compatibility/usability claim was upgraded without direct evidence.

## 4. CURRENT STATE AS OF 18.09.2026

### Project

**P0:** frozen, solo-first, Moscow-first, live-data-gated.

**P1 after stable core:** basic artist/topic follow and one Smart Povod end-to-end scenario through MAX bot/deep-link; map only if it does not slow core.

**Stretch:** second city only after independent data gate; optional invite/shared-plan via share/deeplink/startapp.

### MAX platform facts

- Bridge officially exposes BackButton, link opening, share and haptics. [MAX-002]
- `shareContent` is iOS/Android and explicitly unsupported on web. [MAX-002]
- Haptics are explicitly unsupported on desktop/web. [MAX-002]
- Integrations must use `platform-api2.max.ru` since 2026-07-19. [MAX-003]
- `GET /chats` has been unsupported since June 2026. [MAX-003]
- `POST /chats/{chatId}/members` is restricted from 2026-09-09 and removed on 2026-09-30; docs say no ready add-participant API remains after that. [MAX-004]
- Mini Apps are tied to chatbot/platform context. [MAX-001, MAX-007]
- Platform placement has partner/licence/eligibility requirements. [MAX-001, MAX-005]

### MAX UI

Verified GitHub state:
- repository: `max-messenger/max-ui`;
- default branch: `main`;
- not archived;
- latest verified release: `v0.5.0`, 2026-09-15;
- recent push observed 2026-09-17;
- package `@maxhub/max-ui` v0.5.0;
- package metadata declares MIT;
- peerDependencies list React and react-dom `19.2.8`.

Exact Povod compatibility was **not tested**.

## 5. KEY FINDINGS

### K1 — Occurrence-first remains the strongest P0 pattern

Across RA, Fever, Yandex Afisha, KudaGo and DICE, event decisions rely on concrete date/time/place/price/session. This independently reinforces Povod’s Event != Occurrence contract.

**Recommendation:** selected occurrence above editorial description/decorative metadata.

### K2 — UNKNOWN is a product state

Use explicit copy:

- `Время уточняется`
- `Место уточняется`
- `Цена пока не указана`
- `Источник временно недоступен`
- `Новых дат пока нет`

Never substitute:
- `0 ₽`;
- `Бесплатно`;
- `00:00`;
- arbitrary venue;
- Moscow-center coordinates.

### K3 — Source and freshness must be separated

Previous research bundled them too strongly.

Final rule:
- provenance/source link: **P0 mandatory**;
- freshness text: **only if timestamp semantics are defensible**.

Provider publish/update time, fetch time and successful Povod reconciliation time are different concepts.

### K4 — Save / Follow / Going is evidence-backed

Ticketmaster’s current docs explicitly separate:
- saved **events** → Bookmark;
- favorite **artists** → heart/Favorites.

For Povod:
- **Save** = P0 current event/occurrence;
- **Follow** = P1 future subject;
- **Going** = Stretch shared-plan commitment.

### K5 — Material changes need explicit UX

Luma treats event name, start/duration and location as update-worthy. Partiful explicitly says date/time edits do not automatically notify guests.

Recommended Povod states:
- `Время изменилось: 19:00 → 20:00`
- `Место изменилось`
- `Перенесено`
- `Событие отменено`

Only show a diff when the prior value is actually known.

### K6 — Map belongs inside Search but is not required P0

DICE/Luma validate the pattern, not the Povod scope need.

If implemented:

**Список | Карта**

One query/filter state. No pin when coordinates are unknown.

### K7 — Recommendation reasons should expose facts

Avoid:
- `AI рекомендует`;
- `93% match`;
- `Тебе понравится`.

Prefer known reasons:
- `Ты следишь за Сироткиным`;
- `Пятница вечером`;
- `До 2 000 ₽`;
- `Москва`.

Suppress a reason when the underlying datum is unknown.

### K8 — Social continuation should be share-first

The MAX group-member API removal reinforces a minimal model:

event chosen → user taps `Позвать` → MAX share/deeplink → recipient opens exact context.

Do not build the product around automatic group creation/member management.

Exact Povod share/deeplink remains `NEEDS RUNTIME VERIFICATION`.

### K9 — Full scheduling systems are over-scope

Partiful, Rallly and LINE provide excellent commitment-state references. They do not justify a hackathon planning subsystem.

Partiful Group Reminder is lighter but still introduces hostless group-plan semantics unnecessary for frozen P0.

### K10 — Poster Pop direction remains correct

Keep stronger brand intensity in:
- onboarding;
- event-detail hero;
- share card;
- selective expressive empty/editorial moments.

Keep calmer:
- feed;
- filters;
- search;
- saved;
- profile/settings;
- errors.

## 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

See `DECISION_DELTA.md`.

Most important deltas:
- freshness rule tightened;
- group-member automation explicitly rejected;
- MAX UI version/current state verified and put behind compatibility spike;
- map downgraded from generic recommendation to conditional/P1-after-core;
- Save vs Follow confidence increased;
- Damai reference downgraded to medium confidence;
- Partiful Group Reminder added then deferred;
- old 2–3 city deck line superseded;
- native MAX share kept but runtime proof required;
- no usability result claimed because pilot is NOT RUN.

## 7. CONFIRMED FACTS

- P0 is solo-first and frozen. [PJT-001]
- Test deck says `SOLO FIRST / SOCIAL NEXT`. [PJT-002]
- Test deck says Poster Pop in brand / clean working UI. [PJT-002]
- Test deck pilot is `NOT RUN`. [PJT-002]
- Deck’s 2–3-city roadmap conflicts with current Moscow-first freeze. [PJT-001, PJT-002]
- DICE exposes location plus Into it / Not it. [DICE-001]
- Luma exposes search/map and material-update semantics. [LUMA-001, LUMA-004]
- Partiful Find a Time uses Yes/No/Maybe. [PART-001]
- Partiful date/time edits do not automatically notify guests. [PART-002]
- Rallly’s 2026 redesign exposes all three mobile availability states. [RALLY-001]
- Ticketmaster separates event bookmark from artist favorites. [TM-002]
- Eventbrite exposes date/category/price/type filters. [EB-001]
- Yandex Afisha exposes current date/filter/from-price patterns. [YA-001]
- Timepad exposes explicit no-results copy. [TP-001]
- Fever exposes date/session selection with time/price. [FEVER-001]
- MAX Bridge exposes native shell primitives with platform restrictions. [MAX-002]
- MAX group-member addition is removed on 2026-09-30. [MAX-004]
- MAX UI latest verified release is v0.5.0 dated 2026-09-15. [GH-002]

## 8. RECOMMENDATIONS

### P0

1. Occurrence-first card/detail.
2. Typed UNKNOWN.
3. Visible source CTA.
4. Structured search + compact filters.
5. Save as a single clear P0 intent.
6. Distinct loading/empty/error/source-unavailable.
7. No unsupported freshness.
8. No fake coordinates.
9. Calm operational UI.
10. Material-change status when backed by data.

### P1

- artist/topic Follow;
- one Smart Povod flow;
- factual recommendation reason;
- minimal notification preferences;
- map only if core is stable and geo quality is proven.

### Stretch

- second city after data gate;
- invite/share to chosen occurrence;
- minimal shared-plan RSVP;
- no full scheduling poll during hackathon.

## 9. REJECTED / DEFERRED OPTIONS

### Reject for hackathon

- mandatory group scenario;
- programmatic group-member management;
- one universal heart for Save/Follow/Going;
- fake freshness;
- `0 ₽` as unknown;
- fake map coordinates;
- `AI recommends` or unsupported match score;
- Map/Social bottom tabs;
- ticketing/seating/resale;
- full social graph;
- full scheduling clone;
- 2–3-city promise without gates.

### Defer

- negative preference feedback;
- team/venue/festival follow;
- advanced notification matrix;
- full shared-plan polling;
- hostless Group Reminder;
- second city;
- generalized entity graph.

## 10. RISKS

See `RISKS.md`.

Critical risks:
- Event/Occurrence confusion;
- UNKNOWN corruption;
- source outage misread as empty catalogue;
- false freshness;
- silent material changes;
- MAX API breaking changes;
- MAX UI integration churn;
- social/map scope creep.

## 11. BLOCKERS

### B1 — Exact canonical files

**OPEN QUESTION / EVIDENCE GAP.**

Exact named source-of-truth files were not returned by File Library search. Current 18 Sep instruction is authoritative here, but synthesis should re-diff if files become accessible.

### B2 — MAX share/deeplink runtime

**NEEDS RUNTIME VERIFICATION.**

Official APIs exist; Povod E2E was not run.

### B3 — MAX UI compatibility

**NEEDS RUNTIME VERIFICATION.**

v0.5.0 package peer dependencies are known; project dependency graph was not inspected.

### B4 — MAX placement/legal state

**REQUIRED MANUAL / LEGAL CHECK.**

Official rules impose eligibility/licence obligations; account readiness is not proven by UX research.

### B5 — Provider/legal data approval

**EXTERNAL BLOCKER.**

KudaGo/etc. are UX references only here. Consume provider/legal research for reuse approval.

## 12. OPEN QUESTIONS

1. Can synthesis/Codex access the exact Product Spec/Contract/UI Translation files?
2. What React/runtime versions are in current repository HEAD?
3. Does `shareMaxContent` work as intended on the actual supported MAX client matrix?
4. What is exact startapp/deep-link token and expiry contract?
5. Does every P0 event have a valid source URL?
6. Which provider timestamps can legitimately power freshness copy?
7. Is revision history available for material-change diffs?
8. What coordinate quality threshold gates map?
9. Which artist/topic identifiers are stable enough for P1?
10. Is MAX partner/legal setup already complete?

## 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`.

Minimum:
- Bridge BackButton;
- source `openLink`;
- `shareMaxContent`;
- exact deep-link occurrence;
- web/desktop fallback;
- MAX UI build/client spike if adopted;
- P0 state matrix;
- save persistence;
- change-state rendering;
- responsive/accessibility smoke.

**No runtime test was executed by this research pass.**

## 14. REQUIRED MANUAL / LEGAL CHECKS

1. MAX partner eligibility/account verification.
2. MAX licence/platform-rule acceptance.
3. MAX UI package/repository licence evidence if dependency is used.
4. Provider rights/attribution/images/storage from provider research.
5. Provider-mandated source wording.
6. Privacy/legal links required in the Mini App.
7. Human Poster Pop design review.
8. Human map go/no-go after P0 stability.

## 15. EXACT CHANGES FOR «ПОВОД»

### Change now

- make occurrence fields the factual priority;
- formalize typed UNKNOWN copy;
- separate source from freshness;
- keep Save = current event interest;
- keep Follow out of P0 unless already gated;
- keep Going only in optional shared plan;
- add material change status/diff contract;
- use factual recommendation reason codes only;
- keep map conditional/feature-flagged if unstable;
- remove any plan to rely on MAX group-member API;
- treat MAX UI as optional/selective until compatibility proof.

### Do not change

- name «Повод»;
- solo-first;
- MAX Mini App;
- Poster Pop / Urban Event Poster;
- palette;
- Onest + IBM Plex Mono;
- calmer working UI;
- Event != Occurrence;
- UNKNOWN first-class;
- provenance mandatory;
- Moscow-first frozen P0;
- `Для тебя / Поиск / Сохранённые` + profile entry, unless the actual canonical UI Translation directly says otherwise.

## 16. IMPACT ON P0 / P1 / STRETCH

### P0 — keep
- validated identity;
- Moscow;
- live source-backed events;
- interests/constraints;
- personal feed;
- structured search/filters;
- Occurrence;
- price/UNKNOWN;
- source/original link;
- all core states;
- save;
- My Povod/basic profile;
- MAX mobile/web.

**No new P0 feature is added by this research.**

### P1
- artist/topic follow;
- one Smart Povod E2E;
- factual reason;
- minimal notifications;
- map only after core.

### Stretch
- second city after data gate;
- invite/share;
- minimal shared-plan RSVP.

Full scheduling remains post-hackathon unless scope is deliberately reopened.

## 17. WHAT NOT TO DO

- Do not turn Povod into Partiful inside MAX.
- Do not make social mandatory.
- Do not promise AI.
- Do not show unsupported match percentages.
- Do not fake “checked today”.
- Do not fabricate missing values.
- Do not implement an API path being removed.
- Do not force full MAX UI adoption before a compatibility spike.
- Do not expose unsupported cities.
- Do not let map delay occurrence/source/save.
- Do not equate provider UI availability with API/legal rights.
- Do not claim pilot results.
- Do not copy competitor visual systems wholesale.

## 18. SELF-CRITIQUE / RED TEAM

### RT1 — Could occurrence-first feel too utilitarian?
Yes. Mitigation: retain stronger Poster Pop in onboarding/detail/share, not repetitive feed facts.

### RT2 — Could Save/Follow/Going separation overcomplicate UI?
Yes if shown together. Scope separation prevents this: Save P0, Follow P1, Going Stretch-only context.

### RT3 — Could typed UNKNOWN make cards noisy?
Yes. Label only decision-critical unknowns; unknown image/description does not need explicit copy.

### RT4 — Could source visibility distract?
Possibly. Keep compact factual row + clear source action; source need not visually dominate.

### RT5 — Is map necessary?
No. Good list + location/radius filters is the simpler alternative.

### RT6 — Is Smart Povod necessary to prove value?
No. P0 works without it; Smart Povod demonstrates retention only after core.

### RT7 — Is shared-plan RSVP necessary?
No. Plain share may be enough for hackathon; shared plan is Stretch.

### RT8 — Could MAX UI cost more than it saves?
Yes. It is current pre-1.0 and exact compatibility is unverified. Selective use is safer.

### RT9 — Is MAX API deprecation really a UX concern?
Yes when it invalidates a proposed interaction architecture such as automatic group management.

### RT10 — Do competitor docs prove Povod UX success?
No. They prove existing patterns, not Povod usability. User testing/runtime remain separate evidence.

### RT11 — Are some source articles old?
Yes. Older Bandsintown docs are used only for pattern reference, not current-market claims.

### RT12 — Were exact screen screenshots verified?
No complete screenshot dataset was packaged. First-party pages/docs are linked; copyrighted screen binaries are not redistributed.

## 19. MISSING AREAS CHECK

### Additionally checked
- MAX API deprecations affecting social UX;
- MAX UI version/maintenance state;
- MAX legal/partner dependency;
- client limitations of share/haptics;
- source versus freshness semantics;
- material update behavior;
- Partiful Group Reminder;
- Rallly 2026 voting redesign;
- direct Save vs Follow evidence;
- older deck vs current city freeze;
- `NOT RUN` pilot status.

### Still impossible to close
- exact canonical file contents;
- repository HEAD and paths;
- actual MAX client runtime;
- provider timestamp semantics;
- actual coverage/coordinate quality;
- actual usability outcomes;
- legal interpretation/account status.

### Requires runtime
- Bridge/share/deeplink;
- MAX UI;
- source link;
- save persistence;
- client fallbacks;
- material-change rendering;
- responsive/accessibility.

### Requires human decision
- map go/no-go;
- final copy tone;
- exact Poster Pop intensity;
- whether P1 ships before submission.

### Requires legal
- MAX platform/licence;
- MAX UI dependency licence evidence;
- provider rights.

### Requires Codex/host
- repo inventory;
- state contract tests;
- Bridge spike;
- build evidence;
- feature flags.

### Closed for this topic
- solo-first remains;
- occurrence-first hierarchy;
- typed UNKNOWN;
- source mandatory / freshness conditional;
- Save != Follow != Going;
- no group-member API dependency;
- social after personal result;
- calm working UI under Poster Pop;
- no P0 expansion.

## 20. SOURCE MANIFEST

See:
- `SOURCE_MANIFEST.csv`
- `SOURCE_MANIFEST.json`

All time-sensitive external claims used for decisions are mapped to first-party sources.

Competitor help/product pages prove those products’ patterns; they do not prove equivalent Povod runtime behavior.

## 21. FINAL CHECKLIST

- [x] major claims have evidence/status rows;
- [x] current/time-sensitive sources rechecked on 2026-09-18;
- [x] first-party sources prioritized;
- [x] dates/versions captured where exposed;
- [x] MAX UI GitHub rechecked;
- [x] package licence declaration captured with caveat;
- [x] no runtime claim fabricated;
- [x] P0 not expanded;
- [x] source-of-truth conflicts identified;
- [x] recommendations actionable;
- [x] rejected/deferred patterns documented;
- [x] open questions documented;
- [x] source manifest generated;
- [x] decision delta generated;
- [x] machine summary generated;
- [x] Codex actions generated;
- [x] archive integrity will be tested before delivery.

# APPENDIX A — VERIFIED FEATURE PATTERN LIBRARY

### 1. Onboarding interests

**Verified donors:** DICE; Bandsintown  
**Observed pattern:** Location + explicit preference feedback; optional taste import  
**Povod adaptation:** P0 should stay minimal: city + coarse interests + explicit constraints. External music import and negative feedback are optional future enhancers.  
**Decision:** **KEEP minimal; DEFER enrichment.**

### 2. Personalized event feed

**Verified donors:** DICE; Luma  
**Observed pattern:** Feed shaped by location/follows/preferences  
**Povod adaptation:** Use one ranked feed and a small number of useful temporal sections. Hard constraints filter before ranking.  
**Decision:** **KEEP.**

### 3. Event card

**Verified donors:** Resident Advisor; Yandex Afisha  
**Observed pattern:** Fact density plus familiar Russian poster/list cues  
**Povod adaptation:** Occurrence/date/time/place/price-or-UNKNOWN dominate; poster supports the decision.  
**Decision:** **KEEP occurrence-first.**

### 4. Occurrence/date/time

**Verified donors:** Fever; DICE  
**Observed pattern:** Date/session selector and explicit event times  
**Povod adaptation:** Concrete occurrence is the actionable unit. Never invent end time or time-of-day.  
**Decision:** **KEEP.**

### 5. Price presentation

**Verified donors:** KudaGo; Fever; Yandex Afisha  
**Observed pattern:** Exact/from/range/conditional/session prices  
**Povod adaptation:** Represent exact/from/range/free/conditional/unknown separately; preserve raw condition when interpretation is unsafe.  
**Decision:** **KEEP.**

### 6. UNKNOWN/unavailable

**Verified donors:** Povod canonical contract; event-product TBA patterns  
**Observed pattern:** Explicit absence rather than silent omission  
**Povod adaptation:** Use human Russian copy. Never fake 0/free/time/venue/coordinates.  
**Decision:** **KEEP P0.**

### 7. Provenance/source

**Verified donors:** Povod contract; Resident Advisor  
**Observed pattern:** Source/admin/update metadata  
**Povod adaptation:** Source is mandatory. Freshness is optional and only evidence-backed.  
**Decision:** **KEEP source; CHANGE freshness rule.**

### 8. Filters

**Verified donors:** Yandex Afisha; Eventbrite  
**Observed pattern:** Date/category/price/type  
**Povod adaptation:** Keep decision-critical filters visible; avoid giant taxonomy sheets.  
**Decision:** **KEEP.**

### 9. Search

**Verified donors:** Luma; DICE  
**Observed pattern:** Location-aware search and typed entities  
**Povod adaptation:** Search only entities the backend can normalize reliably. No AI/conversational search needed for P0.  
**Decision:** **KEEP.**

### 10. Map/list switch

**Verified donors:** Luma; DICE  
**Observed pattern:** Map nested in discovery/search  
**Povod adaptation:** If map ships: one query/filter state with `Список | Карта`. Map itself is not mandatory P0.  
**Decision:** **DEFER unless core stable.**

### 11. Event detail

**Verified donors:** RA; DICE; Fever  
**Observed pattern:** Factual detail before editorial copy  
**Povod adaptation:** Status → title → occurrence → place → price → source/actions → description.  
**Decision:** **KEEP.**

### 12. Save/favorite

**Verified donors:** Ticketmaster; Eventbrite  
**Observed pattern:** Saved-event state  
**Povod adaptation:** P0 Save = return to this event/occurrence. Not Follow, not Going.  
**Decision:** **KEEP P0.**

### 13. Follow artist

**Verified donors:** Bandsintown; Ticketmaster  
**Observed pattern:** Future-interest entity action  
**Povod adaptation:** P1. Contextual action on entity/detail, not noise on every card.  
**Decision:** **P1.**

### 14. Follow topic

**Verified donors:** Luma categories/subscriptions  
**Observed pattern:** Category-like following  
**Povod adaptation:** P1 only with stable taxonomy; avoid deep tag graph.  
**Decision:** **P1 constrained.**

### 15. Follow team/sport

**Verified donors:** Ticketmaster  
**Observed pattern:** Teams as favorite subjects  
**Povod adaptation:** Good scale model but unnecessary for hackathon unless data already supports it.  
**Decision:** **DEFER.**

### 16. Notification preferences

**Verified donors:** Luma  
**Observed pattern:** Meaning-based reminder/update categories  
**Povod adaptation:** For Povod bot use only a few semantic toggles, not a channel matrix.  
**Decision:** **P1.**

### 17. Smart event alerts

**Verified donors:** Bandsintown/Luma patterns + Povod contract  
**Observed pattern:** Return around followed subjects and conditions  
**Povod adaptation:** Only send when occurrence and reason are defensible; exact bot/deeplink flow runtime-test required.  
**Decision:** **P1.**

### 18. Profile/personal preferences

**Verified donors:** Current project UX  
**Observed pattern:** My Povod centralizes city/interests/conditions/follows  
**Povod adaptation:** Keep profile entry; no extra Settings bottom tab.  
**Decision:** **KEEP.**

### 19. City switching

**Verified donors:** DICE/Luma + Povod data gate  
**Observed pattern:** Persistent city context  
**Povod adaptation:** P0 is Moscow. Do not expose unsupported cities; second city only after independent gate.  
**Decision:** **KEEP Moscow-first.**

### 20. Invite

**Verified donors:** Partiful share pattern; MAX Bridge  
**Observed pattern:** Explicit share after choosing event  
**Povod adaptation:** P1/Stretch continuation. Native MAX share/deeplink preferred; exact roundtrip unverified.  
**Decision:** **DEFER / SPIKE.**

### 21. RSVP

**Verified donors:** Partiful; Rallly  
**Observed pattern:** Going/Maybe/No / 3-state availability  
**Povod adaptation:** Only inside shared plan, never on ordinary P0 card.  
**Decision:** **STRETCH.**

### 22. Preference vs commitment

**Verified donors:** Ticketmaster; Damai; Partiful/Rallly  
**Observed pattern:** Saved/want-to-see/favorite versus RSVP  
**Povod adaptation:** Formal semantics: Save=current event interest; Follow=future subject interest; Going=shared-plan commitment.  
**Decision:** **KEEP separation.**

### 23. Event updates/material changes

**Verified donors:** Luma; Partiful anti-pattern  
**Observed pattern:** Key changes can invalidate plans  
**Povod adaptation:** Show changed/cancelled/moved; old→new only when old value is actually known.  
**Decision:** **P0 status if data supports; notifications P1.**

### 24. Shared plans

**Verified donors:** Partiful; Rallly; LINE  
**Observed pattern:** Poll/schedule/RSVP  
**Povod adaptation:** Only optional continuation after chosen event. Full scheduling poll is over-scope.  
**Decision:** **STRETCH / DEFER full poll.**


# APPENDIX B — TOP-10 PATTERNS FOR POVOD

1. Occurrence-first card/detail hierarchy.
2. Typed UNKNOWN for price/time/place.
3. Source mandatory; freshness evidence-gated.
4. Save ≠ Follow ≠ Going.
5. Visible decision-critical filters.
6. Structured search over actually normalized entities.
7. Factual recommendation-reason chips.
8. Material-change state / old→new diff when evidence exists.
9. MAX-native user-initiated share/deeplink instead of group automation.
10. Poster Pop strongest at emotional moments, calmer operational UI.

**Map/list is intentionally not a mandatory Top-10 implementation item because map is conditional after core.**

# APPENDIX C — RETENTION UX

Verified recommended loop:

**Discover → Save/Follow → notification → exact event context → inspect current occurrence/source → optional share.**

Scope:
- P0 proves Discover → Event → Source → optional Save.
- P1 adds Follow/Smart Povod.
- Stretch adds social continuation.

Example factual Smart Povod:

`Сироткин · пятница 20:00 · 1 900 ₽`  
`Почему: ты следишь за Сироткиным · входит в твой бюджет`

The budget reason is forbidden if price is UNKNOWN.

# APPENDIX D — SOCIAL UX

Preferred:

**personal result → explicit invite → user-initiated MAX share → recipient opens exact context**

If shared plan exists:
- `Иду`
- `Может быть`
- `Не смогу`

These states do not belong on ordinary P0 cards.

Commitment belongs to the current occurrence conditions; material change must not silently carry it forward.

# APPENDIX E — ERROR / UNKNOWN CONTRACT

| State | User-facing behavior | Forbidden shortcut |
|---|---|---|
| price unknown | `Цена пока не указана` | `0 ₽`, `Бесплатно` |
| time unknown | `Время уточняется` | `00:00` |
| venue unknown | `Место уточняется` | arbitrary venue |
| coordinates unknown | no map pin | city-center pin |
| no results | explicit empty + reset filters | blank screen |
| provider unavailable | explicit source-unavailable | treating as 0 events |
| stale/unverified | caution only if stale is known | fake “checked today” |
| cancelled | clear cancelled state | silent deletion from saved |
| changed | status/diff if prior value known | silent overwrite |
| loading | loading UI | pretending empty/loaded |

# APPENDIX F — MOBILE NAVIGATION

Retain current canonical navigation:

- `Для тебя`
- `Поиск`
- `Сохранённые`
- profile / `Мой Повод` via avatar/profile entry

No new Map/Social bottom tab.

If map is enabled after core, use `Список | Карта` inside Search.

Nested screens should prefer MAX-native BackButton when runtime-verified, avoiding duplicate competing back controls.
