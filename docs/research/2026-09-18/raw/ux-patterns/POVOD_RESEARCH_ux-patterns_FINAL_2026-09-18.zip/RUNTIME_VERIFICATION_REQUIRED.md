# RUNTIME VERIFICATION REQUIRED

**No test below was executed by this research pass.**

## RT-01 MAX Bridge baseline

Matrix:
- Android MAX target client/version;
- iOS MAX target client/version;
- Desktop MAX;
- Web MAX.

Evidence:
- client/version;
- timestamp;
- screenshots/screen recording;
- console/runtime log;
- pass/fail.

## RT-02 BackButton

Verify:
- hidden at root;
- visible on detail;
- no duplicate handlers after route changes;
- no conflict with app/browser history.

## RT-03 Source open

Test `openLink` after user gesture:
- valid HTTPS source;
- malformed URL blocked before Bridge;
- unsupported scheme blocked;
- behavior on all supported clients.

## RT-04 shareMaxContent

Test:
- `{ text, link }`;
- dialog;
- existing group;
- cancel;
- recipient opening the link;
- duplicate/replay-safe plan behavior if shared plan exists.

Media `{ mid, chatType }` is unnecessary unless the product actually needs a share card as bot media.

Do not use programmatic member-add flow.

## RT-05 deep-link / startapp

Prove:
- opens correct Mini App;
- resolves exact event/occurrence;
- invalid/expired payload is safe;
- token is not authorization;
- reopening is idempotent;
- normal navigation preserves context.

## RT-06 MAX UI compatibility

Before broad adoption:
1. record current Povod React/react-dom versions;
2. try `@maxhub/max-ui` v0.5.0 in a disposable branch;
3. production build;
4. target-client smoke;
5. check CSS/token collision with Poster Pop;
6. record bundle delta and console errors.

If it adds churn, use custom components + Bridge primitives instead of blocking P0.

## RT-07 P0 state matrix

Test:
- exact price;
- from/range/conditional price;
- price unknown;
- time unknown;
- venue unknown;
- coordinates unknown;
- no results;
- source unavailable;
- network error;
- cancelled/changed if supported.

## RT-08 Save persistence

- save;
- relaunch;
- re-establish validated identity/session;
- confirm saved state;
- update/cancel occurrence;
- saved screen shows updated status, not silent disappearance.

## RT-09 Responsive/accessibility smoke

- narrow mobile viewport;
- long Russian titles;
- keyboard/focus in web/desktop;
- touch targets;
- no poster/image obscuring date/price/source.

## Evidence path

Use existing repository artifact conventions. Proposed fallback only:

`artifacts/runtime/ux-patterns/2026-09-18/<test-id>/`
