# DECISION DELTA

| PREVIOUS CONCLUSION | FINAL VERIFIED CONCLUSION | WHY / EVIDENCE | PROJECT IMPACT |
|---|---|---|---|
| Source + freshness should be shown together, e.g. “checked today” | Source is mandatory; freshness is conditional on defensible timestamp semantics | Provenance does not imply freshness | Prevents false trust |
| Native MAX invite is a recommended pattern | User-initiated MAX share remains preferred, but exact Povod share/deeplink roundtrip is `NEEDS RUNTIME VERIFICATION` | MAX Bridge exposes primitives; no Povod client test run | P1/Stretch spike |
| MAX social could be discussed abstractly | Do not build social on programmatic chat-member addition | MAX removes `POST /chats/{chatId}/members` on 2026-09-30 | Critical breaking-change avoidance |
| MAX UI referenced generally | Current verified release is v0.5.0 from 2026-09-15; active, pre-1.0, compatibility unproven | Official GitHub metadata | Selective adoption behind spike |
| Save / Follow / Going separate | **UNCHANGED AFTER VERIFICATION**, with stronger direct evidence | Ticketmaster app: Bookmark events, heart/Favorites artists | Higher confidence |
| Partiful strong RSVP reference | **UNCHANGED AFTER VERIFICATION**; its date/time edit behavior is a verified anti-pattern | Official Partiful 2026 help | Stronger material-change rule |
| Rallly social-planning reference | 2026-08-14 mobile redesign is a current high-quality 3-state reference | Official Rallly product blog | Better designer reference |
| Full social planning unnecessary | **UNCHANGED AFTER VERIFICATION**; new Partiful Group Reminder is lighter but still over-scope and limited release | Partiful 2026 help | DEFER |
| Damai `想看` strong current reference | Keep as medium-confidence conceptual reference; direct evidence is 2025, not a 2026 in-app check | Official Damai Weibo + App Store | Do not make core decision from it |
| Map/list switch recommended | Pattern retained **if map ships**; map itself is not mandatory P0 | Current freeze prioritizes core | Avoid scope creep |
| 2–3 cities appeared in test deck | Superseded: P0 is Moscow-first; second city only after independent data gate | 17 Sep deck vs 18 Sep freeze | Critical scope correction |
| Recommendation reasons avoid magical AI | **UNCHANGED AFTER VERIFICATION** | Fits hard-constraint/data-safety model | Keep factual reasons |
| Poster Pop + calm working UI | **UNCHANGED AFTER VERIFICATION** | Project deck + decision-density references | Keep brand direction |
| Material change state recommended | **UNCHANGED AFTER VERIFICATION**, confidence increased | Luma updates + Partiful anti-pattern | Implement when data supports |
| Competitor patterns implied likely usability benefit | They prove patterns exist, not Povod outcome; usability remains unmeasured | Deck pilot is `NOT RUN` | No outcome claims |
