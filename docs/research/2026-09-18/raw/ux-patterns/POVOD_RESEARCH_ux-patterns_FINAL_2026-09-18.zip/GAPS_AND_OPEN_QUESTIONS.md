# GAPS AND OPEN QUESTIONS

## Evidence gaps

1. **Canonical files not directly available.** Exact named files were searched but not returned. Current 18 Sep instruction is the authority boundary for this archive.
2. **Repository HEAD not inspected here.** Exact component paths, dependency versions, flags and implementation status are unknown.
3. **No Povod runtime executed.** No device/client screenshots, logs or E2E evidence were produced.
4. **Provider timestamp semantics are not verified in this UX archive.** Freshness UI cannot be finalized beyond “only evidence-backed freshness”.
5. **User validation is not run.** Current test deck explicitly says `NOT RUN`.

## Open product questions

- Is map worth remaining hackathon time after P0 is stable?
- Which P1 subjects have stable identifiers: artist/topic only or more?
- Should recommendation reasons appear in the feed, Smart Povod only, or both?
- Does the data pipeline retain prior values/revisions for material-change diffs?
- What exact Poster Pop intensity is desired on detail hero vs feed?

## Open MAX questions requiring runtime

- `shareMaxContent` behavior on Android / iOS / Desktop / Web;
- exact startapp/deep-link return to one Occurrence;
- fallback when mobile-only share/haptic APIs are unavailable;
- BackButton lifecycle with app routing;
- `openLink` behavior for provider URLs.

## Manual/legal questions

- Is the team’s MAX partner/legal account eligible and verified?
- Is the required MAX licence agreement accepted?
- If MAX UI is bundled, is package/repository licensing evidence sufficient for release?
- Provider rights/attribution/storage/images: consume provider/legal research.

## Codex/host questions

- real component/file paths;
- current React/runtime versions;
- current Event/Occurrence/Source/Save state model;
- existing feature flags;
- existing Bridge wrapper.
