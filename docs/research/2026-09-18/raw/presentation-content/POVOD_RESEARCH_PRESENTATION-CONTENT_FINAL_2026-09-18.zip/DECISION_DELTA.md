# Decision Delta — Previous Analysis vs Final Verified Conclusion

| Area | Previous conclusion | Final verified conclusion | Why | Impact |
|---|---|---|---|---|
| Core story | Solo-first, occurrence, UNKNOWN/source, early demo | **UNCHANGED AFTER VERIFICATION** | Still aligned with frozen P0 | Keep |
| Validation | 6–8 problem interviews + 4–5 usability sessions | **CHANGED:** public-information / desk research in this phase | Explicit later project decision | Replace validation slide/Q&A |
| Old pilot | Could be shown as planned 12/48/14 framework | **REJECTED as result** | Old deck itself says `NOT RUN` | Never present as evidence |
| Geography | Scale via gates, but older deck contained 2–3 cities | **CHANGED:** P0 = Moscow only | Final scope freeze | Remove SPb/BETA/multi-city-first from main deck |
| MAX loop | “choose → return → share” framed as a closed loop | **NARROWED:** documented primitives exist, Povod loop needs E2E | `startapp` can open Mini App without starting bot | Smart Povod cannot be assumed |
| MAX social | Generic optional share | **NARROWED:** user-driven share only; no group-add dependency | group member add API removed 30.09.2026 | Avoid obsolete API |
| MAX readiness | Generic HTTPS/identity | **EXPANDED CHECKS:** API2 + certificate, HTTPS webhook, partner verification/licence/moderation | Current official docs | Add acceptance/legal checklist |
| KudaGo | Technical candidate with open gate | **UNCHANGED but stricter presentation treatment** | Official licence confirms attribution constraints, not exact Povod approval | Backup only until approved |
| Source link | Mainly a UX trust mechanism | **STRONGER:** also provider-licence relevant for KudaGo | Official KudaGo open licence | Source CTA is core, not decoration |
| Git baseline | Prior result referenced older intermediate T002 state | **CORRECTED:** latest located baseline `d48f01e...`, handoff `4f9a198...` | Later final host pass | Update evidence references |
| Runtime | Static source structure existed but did not prove runtime | **UNCHANGED AFTER VERIFICATION** | T002 explicitly excludes runtime acceptance | Preserve evidence separation |
| Official case | Not available | **UNCHANGED AFTER VERIFICATION** | File Library still does not expose exact case PDF | Host/manual compliance pass required |
| Deck length | 10–14 slides; recommendation 14 | **UNCHANGED** | No verified case requirement contradicts it yet | Keep, subject to official timing |
| Architecture | One concise slide after product/demo | **UNCHANGED** | Helps explain authority boundaries without scope expansion | Keep concise |
