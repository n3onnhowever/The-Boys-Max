# Quality Gate

This file is completed automatically/manually during archive creation.

## Research gate
- [x] Major claims placed in claim/evidence matrix.
- [x] Time-sensitive MAX/KudaGo facts rechecked on 18.09.2026.
- [x] Official sources prioritized.
- [x] Breaking September MAX group API change captured.
- [x] Runtime claims not inferred from static files.
- [x] P0 not silently expanded.
- [x] Conflicts with old deck identified.
- [x] Recommendations actionable.
- [x] Rejected/deferred options listed.
- [x] Open questions listed.
- [x] Source manifest present in CSV and JSON.
- [x] Decision delta present.
- [x] machine summary present.
- [x] Codex actions present.
- [x] Red-team/self-critique present.
- [x] Missing-areas check present.

## Open blockers, intentionally not marked complete
- [ ] Exact official-case page mapping.
- [ ] Current 18 Sep HEAD verification.
- [ ] P0 MAX/runtime acceptance.
- [ ] Formal Moscow/provider gate.
- [ ] Hackathon-specific MAX provisioning/legal state.

## Archive gate
Archive creator validates:
- required path presence;
- UTF-8 readability for text files;
- JSON parsing;
- CSV header shape;
- ZIP CRC/testzip;
- SHA-256 manifest.
