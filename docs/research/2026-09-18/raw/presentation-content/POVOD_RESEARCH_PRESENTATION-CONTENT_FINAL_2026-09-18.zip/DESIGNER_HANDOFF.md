# Designer Handoff — Content Assets Only

No visual design decisions are introduced here. Existing system remains authoritative.

## Give the designer

### 1. Final slide matrix
From `PRESENTATION_BLUEPRINT.md`:
- slide number;
- exact headline;
- one main thought;
- 2–4 support points;
- evidence status;
- asset ID.

### 2. Runtime screenshot manifest
Recommended IDs:
- `S04_MAX_ENTRY`
- `S04_FOR_YOU`
- `S04_FILTER`
- `S04_EVENT_DETAIL`
- `S05_PRICE_KNOWN`
- `S05_PRICE_UNKNOWN`
- `S05_SOURCE_OPEN`
- `S06_SAVED`
- `S07_SMART_POVOD` — only if accepted
- `S07_STARTAPP_RETURN` — only if accepted
- `S07_SHARE` — only if accepted
- `S08_PROVIDER_RECEIPT`
- `S12_EVIDENCE_BOARD`

Each asset metadata:
- `CONCEPT` or `RUNTIME`;
- commit/build;
- timestamp;
- platform/client;
- data mode;
- evidence ID.

### 3. Three diagrams
1. `MAX → CONDITIONS → FOR YOU → OCCURRENCE → SOURCE → SAVE`
2. `Mini App / Bot / startapp / optional share` with documented-vs-runtime badges
3. `PROVIDER → NORMALIZE → ELIGIBILITY → RANK → API → MAX`

### 4. Evidence states
Use text states:
- `VERIFIED`
- `NEEDS EVIDENCE`
- `NOT RUN`
- `OPEN LEGAL`
- `CONCEPT`

Do not visually disguise unresolved items as pass.

### 5. Real assets
- actual MAX mobile capture;
- actual MAX web capture;
- real source opening;
- accepted provider receipt;
- accepted UNKNOWN case;
- evidence-board snapshot;
- team roster;
- only permitted logos/brand assets.

## Do not give as “proof”
- old concept Smart Povod notification;
- old multi-city map;
- unrun pilot cards;
- mock provider data without explicit label;
- a standalone browser screenshot labelled as MAX runtime.
