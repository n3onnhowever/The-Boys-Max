# CODEX ACTIONS — Presentation Content Verification Handoff

This file is an execution handoff, not authorization to redesign the product.

## 0. Do not change

Do **not** change these decisions unless a human explicitly updates the source of truth:

- solo-first;
- Moscow-only P0;
- Event ≠ Occurrence;
- honest UNKNOWN;
- provenance/source;
- hard constraints before ranking;
- social optional;
- map not required for core;
- Smart Povod P1 after stable core;
- no scope expansion for presentation convenience.

## 1. Verify current repository first

On host repo `D:\Dev\Repos\The-Boys-Max`:

1. record current branch/HEAD/status;
2. compare with latest located T002 evidence:
   - baseline `d48f01eafa23ef4a0a2b98cb20b74e5052423a74`
   - handoff `4f9a198d4fa2b18686efa19a59b6ac78281d341d`
3. do **not** reset/rewrite history merely to match those SHAs;
4. identify changes after T002;
5. produce `CURRENT_HEAD_RECEIPT.md/json`.

## 2. Read canonical local files

Locate and read, without silently editing:

- `POVOD_FINAL_SCOPE_FREEZE_MVP.md`
- `POVOD_PRODUCT_SPEC_V1.md`
- `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`
- `POVOD_PRODUCT_CONTRACT_V1.json`
- `POVOD_MOSCOW_DATA_GATE_V1.md`
- `MOSCOW_DATA_GATE_RECEIPT.json`
- official case PDF under `input/official/` if present

If any recommendation in this archive conflicts, create a note headed:

`CONFLICT WITH CURRENT SOURCE OF TRUTH`

Do not resolve by changing scope automatically.

## 3. Official case compliance pass

Read the exact PDF locally and produce:
`docs/presentation/CASE_COMPLIANCE_MATRIX.md`

Columns:
- requirement
- exact page
- mandatory/optional
- deck slide
- demo step
- backup slide
- evidence ID
- status

Do not commit the official PDF if project rules exclude it.

## 4. Inspect code before patching

The T002 source tree includes these relevant paths. Inspect them; patch **only if the current code violates the accepted contract**:

### MAX identity / transport
- `packages/platform/auth.ts`
- `packages/platform/config.ts`
- `packages/platform/ingress.ts`
- `packages/platform/transport.ts`
- `packages/platform/links.ts`
- `apps/miniapp/bridge.ts`
- `apps/miniapp/src/core/launch.ts`
- `apps/miniapp/src/core/links.ts`

Checks:
- signed `initData` server validation;
- no trust in `initDataUnsafe`;
- explicit `auth_date` freshness;
- opaque/non-secret `startapp`;
- `platform-api2.max.ru`;
- trusted cert chain / HTTPS;
- webhook secret/replay handling if webhooks are used.

### Event/data honesty
- `modules/search/core/provider.ts`
- `modules/search/core/normalizers.ts`
- `modules/search/core/price.ts`
- `modules/search/core/authority.ts`
- `modules/search/core/eligibility.ts`
- `packages/contracts/domain.ts`
- `packages/persistence/catalog.ts`

Checks:
- Event vs Occurrence;
- UNKNOWN remains explicit;
- no free/zero inference without proof;
- no fake geo;
- source/provenance retained;
- hard FAIL cannot be compensated by ranking.

### Persistence / UI
- `packages/persistence/sessions.ts`
- `packages/persistence/ui.ts`
- `packages/persistence/search-issuance.ts`
- `apps/miniapp/src/components/EventCard.tsx`
- `apps/miniapp/src/components/EventDetail.tsx`
- `apps/miniapp/src/core/price-disclosure.ts`

Checks:
- saved state tied to validated user;
- detail exposes source;
- UNKNOWN labels honest;
- loading/empty/error/source-unavailable states.

## 5. Tests to add or run

Relevant existing test paths found in T002:
- `tests/unit/security.test.ts`
- `tests/unit/integration26.test.ts`
- `tests/unit/delivery-and-ports.test.ts`
- `tests/integration/foundation.test.ts`
- `tests/integration/ui26.test.ts`

Add/extend only where absent:
- valid/tampered/stale initData;
- startapp non-secret opaque payload;
- hard constraint cannot be score-overridden;
- conditional/UNKNOWN price;
- source URL safety;
- save persistence;
- provider outage;
- bot→Smart Povod→exact occurrence only if P1 is being accepted for demo.

## 6. Provider/data gate

Do not mark Moscow ACTIVE or KudaGo APPROVED from code alone.

Produce accepted receipt with:
- all required gate cases;
- request/response metadata;
- lawful sample or hashes;
- raw→normalized mapping;
- KNOWN + UNKNOWN;
- source URLs;
- provider/legal status.

## 7. MAX manual provisioning check

Record separately:
- actual partner profile/account used;
- verification status;
- bot moderation/status;
- Mini App attachment;
- licence/agreement status or organizer-provided hackathon path;
- whether any hackathon exception applies.

Do not infer this from public docs.

## 8. Presentation-content outputs

After runtime evidence:
- update `docs/tasks/060_PRESENTATION_UPDATE.md` if still authoritative;
- create/update an evidence-index document;
- produce final runtime screenshot manifest;
- patch deck claims based on `CLAIMS_EVIDENCE.csv`;
- never convert `NEEDS RUNTIME VERIFICATION` to `CONFIRMED` without artifact IDs.

## 9. Evidence to save

Prefer small receipts and hashes; do not commit secrets, full copyrighted source materials, or excluded runtime data.

Save:
- current HEAD receipt;
- build/run logs;
- screenshots/video metadata;
- provider receipt;
- identity-test results;
- source-link check;
- exact-case compliance mapping;
- final evidence board snapshot.

## 10. Stop conditions

Stop and escalate to human if:
- canonical local files disagree with this archive;
- official case requires a different P0;
- MAX account/provisioning cannot support the required demo;
- provider legal gate fails;
- live data gate fails;
- proposed fix requires new infrastructure unrelated to P0.

Do not “solve” a blocker by expanding scope.
