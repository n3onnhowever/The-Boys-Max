# Demo Script

## 90 seconds

### 0–10 — MAX entry
Open the real bot/Mini App path.

Say only what is evidenced:
> “Открываем Повод внутри MAX.”

Add “validated identity” only if RV-05 passed.

### 10–25 — For You / conditions
Show a preconfigured profile and apply a small set of hard conditions:
- Moscow;
- exact day/period;
- time;
- budget.

> “Сначала это ограничения, а не пожелания модели.”

### 25–45 — concrete occurrence
Open one real occurrence.

Show:
- date;
- time;
- venue/place;
- source.

### 45–65 — UNKNOWN + source
Use a genuine missing/conditional price case.

> “Источник не сообщил цену — поэтому здесь UNKNOWN, а не ноль.”

Open original source.

### 65–78 — save
Save the chosen occurrence.

> “На этом личная задача уже решена.”

### 78–90 — optional continuation
If Smart Povod E2E passed:
> “А после явной подписки бот может вернуть меня в конкретный occurrence.”

Show actual bot message → startapp → exact occurrence.

If not passed:
> “Follow и Smart Povod — следующий retention loop после стабильного P0.”

Do not fake a notification.

---

## 3 minutes

### 0:00–0:20 — MAX
Real entry + Mini App.

### 0:20–0:45 — profile/context
Show saved interests only if persistence is verified.

### 0:45–1:10 — hard conditions
Date/time/budget/category.

### 1:10–1:40 — real occurrence
Show date/time/venue/price/source.

### 1:40–2:05 — honesty edge case
Open a genuine UNKNOWN/conditional field case and source.

### 2:05–2:25 — save
Save and, if fast, show it in “Мой Повод”.

### 2:25–2:50 — P1 Smart Povod
Only if verified:
bot → message → opaque startapp → exact occurrence.

### 2:50–3:00 — optional share
Only if the selected mechanism is verified on the claimed client.

End:
> “Сначала я получил ценность сам. MAX добавляет возврат и sharing только после выбора.”

---

## Fallback demo

### Provider/network unavailable
Do not switch invisibly to mock data.

Say:
> “Сейчас внешний источник недоступен. Продукт не подменяет это выдуманными данными. Покажем последний верифицированный прогон с timestamp и receipt.”

Use:
- accepted timestamped recording;
- provider receipt/hash;
- raw→normalized example;
- explicit data mode.

### MAX venue network unstable
Keep:
- 90-second recording from real MAX mobile;
- MAX web capture;
- evidence manifest;
- exact commit/build.

Standalone browser UI is not a substitute for “works in MAX”.

### Smart Povod failure
Finish on `find → occurrence → source → save`.

> “Это законченное P0. Smart Povod остаётся P1 и не нужен, чтобы доказать личную ценность.”

## Demo freeze manifest

Before defense freeze:
- event ID;
- occurrence ID;
- provider;
- fetched timestamp;
- expected filter result;
- expected UNKNOWN case;
- source URL;
- build commit;
- MAX client/platform;
- fallback recording checksum.
