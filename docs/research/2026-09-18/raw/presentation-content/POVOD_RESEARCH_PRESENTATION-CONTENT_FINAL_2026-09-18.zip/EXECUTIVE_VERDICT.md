# Executive Verdict

## Verdict

**FINAL WITH OPEN BLOCKERS.**

The presentation-content direction is retained, but its claims are narrowed to match the evidence actually available on 18.09.2026.

### Keep

- Solo-first as the primary product narrative.
- Moscow-only P0.
- Concrete `Occurrence`, not generic event, as the decision object.
- Honest `UNKNOWN`.
- Visible provenance/source and opening the original.
- Personalization as hard constraints first, ranking second.
- Live demo early in the deck.
- One architecture slide and one evidence-scoreboard slide.
- Scale story through repeatable provider/city gates, not pre-claimed geographic coverage.

### Change

- Replace the previous interview/usability plan with **public-information / desk-research validation** for this phase.
- Replace “MAX closes the retention loop” with: **MAX provides documented primitives for Mini App, identity, deep links, bot delivery and sharing; Povod’s exact loop still requires E2E evidence.**
- Correct Git evidence to the latest located T002 final pass: baseline `d48f01eafa23ef4a0a2b98cb20b74e5052423a74`, handoff `4f9a198d4fa2b18686efa19a59b6ac78281d341d`.
- Add MAX readiness checks for `platform-api2.max.ru`, trusted/Minцифры certificate chain, webhook HTTPS, partner verification/moderation/licence status.
- Keep KudaGo/provider branding out of the main proof until the exact runtime + legal gate is closed.

### Reject / defer

- `2–3 cities` in the hackathon MVP.
- Moscow/SPb marked `BETA` without passed data gates.
- Unrun pilot metrics as evidence.
- Mandatory group/social flow.
- Programmatic group-member addition as a future social primitive.
- “all Moscow events”, “always current price”, “production-ready”, or similar absolutes.
- Smart Povod as the hero live-demo ending until the exact bot→message→deeplink→occurrence path is proven.

## Main blocker

There is still no single accepted evidence bundle proving the frozen P0 end-to-end in MAX with live Moscow data and the required honesty states. The exact official case PDF/rubric is also unavailable in this research environment.

## Next actions

1. Host/Codex: verify current HEAD and read the official case PDF from the local project input.
2. Run the minimal P0 acceptance/evidence campaign.
3. Close Moscow/provider runtime + legal gates.
4. Confirm hackathon-specific MAX provisioning/onboarding.
5. Patch the final deck using `PRESENTATION_BLUEPRINT.md`; only verified claims graduate from `NEEDS EVIDENCE`.
