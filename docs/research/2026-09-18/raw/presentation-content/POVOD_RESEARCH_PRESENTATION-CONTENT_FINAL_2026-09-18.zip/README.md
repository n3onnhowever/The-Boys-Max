# POVOD Research Archive — Presentation Content

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** `presentation-content`  
**Research version:** `FINAL-2026-09-18`  
**Previous result:** «ПОВОД — CONTENT DECK v1», 18.09.2026  
**Verification status:** **FINAL WITH OPEN BLOCKERS**

## What this archive is

A final verification and packaging pass for the presentation-content research thread. It does **not** redesign the product or expand the frozen P0. It converts the previous presentation narrative into an evidence-governed, source-traceable handoff for the later synthesis pass and Codex.

## Final status

The content strategy is strong enough to keep: evidence-first, solo-first, occurrence-level honesty, UNKNOWN, provenance/source, an early live demo, one concise architecture slide, and an evidence scoreboard.

The archive is **not** “fully runtime verified” because major product claims still require direct execution evidence. The exact official case PDF/rubric, current repository HEAD, formal Moscow live-data gate, exact provider legal gate, and hackathon-specific MAX provisioning/onboarding were not closed in this research environment.

## Main conclusion

Do **not** make the presentation broader. Make it more provable.

The strongest final story is:

`intent → hard conditions → concrete Occurrence → date/time/place → price or UNKNOWN → source → save`

MAX should be presented as documented product primitives around that core—not as proof of retention. Social is optional continuation. Smart Povod is P1 unless its bot-enrollment/message/deep-link E2E is actually proven.

## Contents

- `FINAL_REPORT.md` — full 21-section verified report.
- `EXECUTIVE_VERDICT.md` — compact decision.
- `FACT_CHECK_MATRIX.csv` — previous claims vs verified conclusions.
- `CLAIMS_EVIDENCE.csv` — major claim/evidence register.
- `SOURCE_MANIFEST.csv` / `.json` — source manifest.
- `DECISION_MATRIX.csv` — presentation/content decisions.
- `DECISION_DELTA.md` — what changed from the previous result.
- `GAPS_AND_OPEN_QUESTIONS.md` — remaining gaps.
- `RECOMMENDATIONS.md` — actionable recommendations.
- `RISKS.md` — P0/content/platform/data/legal risks.
- `RUNTIME_VERIFICATION_REQUIRED.md` — runtime evidence campaign.
- `CODEX_ACTIONS.md` — host/Codex handoff.
- `machine_summary.json` — synthesis-ready summary.
- `PRESENTATION_BLUEPRINT.md` — verified content blueprint.
- `DEMO_SCRIPT.md` — 90s / 3min / fallback demo.
- `JURY_QA.md` — verified Q&A set.
- `PROHIBITED_CLAIMS.md` — claims that must not be made without evidence.
- `DESIGNER_HANDOFF.md` — material manifest, not visual design.
- `evidence/` — verification notes and source-access limitations.

## Evidence language

- `CONFIRMED`
- `VERIFIED BY OFFICIAL DOCS`
- `VERIFIED BY SOURCE CODE`
- `VERIFIED BY RUNTIME`
- `LIKELY`
- `PROPOSED`
- `NEEDS RUNTIME VERIFICATION`
- `NEEDS LEGAL VERIFICATION`
- `UNKNOWN`
- `REJECTED`

No static file, README, mock screenshot, or design artifact is treated as runtime evidence.
