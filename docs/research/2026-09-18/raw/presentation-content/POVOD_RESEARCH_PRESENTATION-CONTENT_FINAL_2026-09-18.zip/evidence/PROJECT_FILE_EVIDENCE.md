# Project File Evidence

## POVOD_TEST_DECK_V1.pptx — 17.09.2026

Directly inspected through File Library.

Relevant observations:
- service slide says it is a test deck / `NO-CODE CONCEPT`;
- product already states solo-first / social-next;
- problem slide says events exist in “dozens of sources” — evidence not attached there;
- personalization slide shows saved/follows/Smart Povod between sessions as concept;
- Smart Povod notification is a concept screen, not runtime evidence;
- scale slide says “Multi-city с первого дня” and marks Moscow + Saint Petersburg `BETA`;
- validation slide shows `12` volunteers, `2×2`, `48` attempts, `14 days`, but explicitly labels it `NOT RUN`;
- roadmap puts `2–3 cities`, map, basic subscriptions and invite inside hackathon MVP.

Verification conclusion:
- the deck is a useful previous artifact, but several statements are stale relative to the current frozen scope and evidence policy.
- it must not be used as current source of truth.

## T002 host/Git evidence — 16.09.2026

The final located host pass ends with:

- `BASELINE_SHA=d48f01eafa23ef4a0a2b98cb20b74e5052423a74`
- `HANDOFF_SHA=4f9a198d4fa2b18686efa19a59b6ac78281d341d`
- `BASELINE_WHITESPACE_CHECK=PASS`
- `PROHIBITED_TRACKED_PATHS=PASS`
- `FINAL_STATUS=CLEAN`
- `REMOTE=NONE`

The source baseline includes:
- Docker/Compose files;
- API/Mini App/worker;
- domain/contracts/persistence/platform modules;
- migrations;
- tests;
- docs/tasks/handoffs.

The T002 handoff explicitly states that this source/control baseline does **not** establish:
- npm/build;
- Docker;
- PostgreSQL;
- Redis;
- browser;
- MAX;
- live provider;
- live AI;
- end-to-end acceptance.

Verification conclusion:
- use T002 only for source-control/static structure claims.
- current 18 Sep HEAD remains UNKNOWN until host/Codex checks it.
