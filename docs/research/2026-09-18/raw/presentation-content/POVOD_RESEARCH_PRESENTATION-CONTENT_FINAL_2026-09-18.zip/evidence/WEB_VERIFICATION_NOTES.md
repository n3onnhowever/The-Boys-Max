# Web Verification Notes — accessed 2026-09-18

This file records the conclusions used from current public sources. It does not mirror full copyrighted documentation.

## MAX API
URL: https://dev.max.ru/docs-api  
Owner: ООО «MAX»

Verified:
- current docs instruct use of `platform-api2.max.ru`;
- docs also instruct adding/trusting the Минцифры certificate chain;
- `GET /chats` is no longer supported from June 2026;
- group member add has a September 2026 breaking change.

## MAX API changelog
URL: https://dev.max.ru/docs-api/changelog-api

Verified:
- September 2026 notice for restriction of `POST /chats/{chatId}/members`;
- June 2026 removal/non-support of `GET /chats`.

## Group member add
URL: https://dev.max.ru/docs-api/methods/POST/chats/-chatId-/members

Verified:
- limited from 2026-09-09;
- removed from 2026-09-30;
- after that, API does not provide a ready method to add participants to group chat.

Presentation consequence:
- social flow must not depend on automated participant addition.

## Mini Apps
URL: https://dev.max.ru/docs/webapps/introduction

Verified:
- Mini App deep link format `https://max.ru/<botName>?startapp=<payload>`;
- payload up to 512 chars and restricted character set;
- docs advise not to transmit confidential data openly in payload;
- direct external `startapp` flow can open Mini App **without launching the bot**;
- `:share` documented for iOS, Android and web; desktop support in development;
- media share flow can use bot-sent message + `shareMaxContent`.

Presentation consequence:
- `startapp` is useful exact-context transport, but it does not prove bot enrollment.
- Smart Povod requires its own E2E.
- sharing claims need a platform matrix.

## MAX Bridge
URL: https://dev.max.ru/docs/webapps/bridge

Verified:
- `window.WebApp.initData` is intended for server-side validation;
- `initDataUnsafe` must not be used for validation;
- `auth_date` can support invalidation; docs show a recommended interval of about one hour.

Presentation consequence:
- “validated MAX identity” must be backed by server-side runtime evidence.

## Partner onboarding / bot creation
URLs:
- https://dev.max.ru/docs/chatbots/bots-create/create
- https://dev.max.ru/docs/maxbusiness/connection

Verified for normal public partner flow:
- platform services are documented for RF-resident legal entities, IPs and self-employed profiles;
- profile verification is required;
- bot undergoes moderation.

Important limitation:
- no public hackathon-specific exception/provisioning was verified. Because this is a student hackathon, the normal business flow must **not** be interpreted as proof that hackathon teams cannot receive special access.

## Placement rules
URL: https://dev.max.ru/docs/legal/rules

Verified:
- app placement is documented as requiring an active licence agreement;
- developer bears obligations for rights, compatibility, data processing and compliance.

Presentation consequence:
- hackathon account/licence state is a manual/legal readiness item.

## Webhooks
URL: https://dev.max.ru/docs-api/methods/POST/subscriptions

Verified:
- webhook is the main event delivery mechanism;
- HTTP and self-signed certificate reception are not supported under current guidance; use HTTPS/trusted certificates.

## KudaGo API / open licence
URL: https://docs.kudago.com/api/  
Owner: ООО «Реван» / Revan LLC

Verified:
- official API documentation lists v1.4;
- Moscow `msk` is a documented location;
- open licence permits commercial/personal/noncommercial use subject to conditions;
- reused data/parts must contain direct open indexable links to the exact source material;
- misleading third parties about the rightsholder is prohibited;
- sale/benefit from transferring KudaGo materials to third parties is restricted;
- rightsholder can change terms;
- no accuracy/availability warranty equivalent to a Povod SLA is established.

Not verified by this page alone:
- exact MAX Mini App/WebView indexability interpretation;
- exact long-term storage/cache/retention;
- all image/third-party rights;
- formal Povod provider approval.

## Public hackathon announcement
URL: https://istu.ru/material/hakaton-po-sozdaniyu-servisov-dlya-nacionalnogo-messendzhera-max
Published: 2026-08-21
Owner: ИжГТУ им. М.Т. Калашникова

Verified:
- track “Досуг и развлечения” covers services for events, volunteering, tourism and sport;
- 40 projects are to be selected for the final;
- final/awards announced for 2026-10-29 at Kazan Digital Week in Kazan;
- jury described as including representatives of federal bodies, VK, MAX and RTU MIREA.

Limitation:
- this is not the exact official case PDF/rubric and cannot replace it for page-level compliance.
