# Source Access Limitations

## Exact canonical files

The following filenames were searched in File Library but were not directly returned as their own files:

- `POVOD_FINAL_SCOPE_FREEZE_MVP.md`
- `POVOD_PRODUCT_SPEC_V1.md`
- `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`
- `POVOD_PRODUCT_CONTRACT_V1.json`
- `MOSCOW_DATA_GATE_RECEIPT.json`

The current project-owner request explicitly restates the controlling frozen P0 and conflict rule, so this report uses that restatement as the binding context for this pass.

**Required host action:** read the exact local copies before final synthesis and flag any mismatch as `CONFLICT WITH CURRENT SOURCE OF TRUTH`.

## Official case PDF

The exact case PDF/rubric was not available in File Library or as a directly usable official web document during this pass.

T002 evidence indicates an official PDF under local `input/official` was deliberately excluded from Git source-control material.

**Required host action:** inspect the local official PDF without committing it, then produce page-level compliance mapping.

## Current repository

The connected GitHub tool did not expose a `The-Boys-Max` repository. Therefore the research cannot state the current 18.09.2026 HEAD.

Latest direct evidence is T002 from 16.09.2026.

## Runtime

This research process did not execute the app, provider, Docker stack, MAX clients, or bot.

Any “works” claim remains `NEEDS RUNTIME VERIFICATION` unless an external accepted runtime artifact is later attached.

## Legal interpretation

Official terms were read as technical/product constraints. This is not legal advice. Ambiguities around provider cache/indexability/images and hackathon-specific MAX placement/onboarding require manual/legal confirmation.
