# Presentation Blueprint — Verified Content

This is a content blueprint, not a design specification.

## Narrative

1. **Intent:** “Свободный вечер есть. Решения ещё нет.”
2. **Fragmentation:** finding a list is not the same as assembling a trustworthy decision.
3. **Solo-first answer:** conditions → concrete occurrence.
4. **Show it:** live demo begins early.
5. **Trust:** date/time/place + price or UNKNOWN + source.
6. **Personalization:** hard constraints first, ranking second.
7. **Why MAX:** documented Mini App / identity / bot / deep-link / sharing primitives; Povod E2E is separately proven.
8. **Live data:** city/provider only after gate.
9. **Scale:** repeat the gate, do not paint the map.
10. **Architecture:** separate facts, eligibility, ranking and delivery.
11. **Public evidence validation:** desk research, not invented interviews.
12. **What is actually proven:** evidence scoreboard.
13. **Team:** ownership of critical path.
14. **Close:** one trustworthy reason to go out, inside MAX.

## Slide 1 — «Свободный вечер есть. Решения ещё нет.»
**Main thought:** user needs a decision, not a catalogue.  
**Support:** time/budget/place/format constrain the choice; a generic event is insufficient.  
**Evidence:** public desk-research facts only if traceable; otherwise no quantified problem claim.  
**Asset:** one concrete demo intent, labelled scenario rather than statistic.  
**Speaker note:** start with an evening, not a market.  
**Transition:** “Сегодня такой ответ часто приходится собирать по частям.”

## Slide 2 — «Проблема — не найти список. Проблема — собрать решение.»
**Support:** discover → check exact conditions → verify source; optional coordination later.  
**Evidence:** current public desk-research source map; no simulated journey.  
**Asset:** compact fragmentation diagram.  
**Transition:** “Поэтому мы сделали личный сценарий законченным сам по себе.”

## Slide 3 — «Повод — персональная афиша внутри MAX.»
**Support:** interests/conditions; eligible events; detail; source; save.  
**Evidence:** source-of-truth product contract.  
**Asset:** `MAX → conditions → For You → occurrence → source → save`.  
**Transition:** “Покажем это на одном вечере.”

## Slide 4 — «Один вечер → один конкретный Повод.»
**Support:** Moscow, date/time, budget, selected occurrence.  
**Evidence:** real runtime only.  
**Asset:** actual feed/filter/detail captures.  
**Transition:** **LIVE DEMO NOW.**

## Slide 5 — «Если данных нет — Повод не притворяется, что знает.»
**Support:** Event ≠ Occurrence; UNKNOWN; source.  
**Evidence:** real KNOWN + genuine UNKNOWN runtime cases.  
**Asset:** two real detail states.  
**Transition:** “Когда фактам можно доверять, персонализация становится полезной.”

## Slide 6 — «Персонализация начинается с условий, а не с магии.»
**Support:** eligibility before ranking; saved as explicit signal; follow/Smart Povod P1.  
**Evidence:** contract + hard-filter runtime.  
**Asset:** `conditions → eligible set → ranking`.  
**Transition:** “А MAX нужен не для того, чтобы просто завернуть сайт.”

## Slide 7 — «MAX даёт контекст выбора, возврата и шеринга.»
**Support:** Mini App; validated init data; bot delivery if enrolled; startapp exact context; optional user-driven share.  
**Important wording:** do **not** say MAX proves retention. `startapp` alone does not start the bot.  
**Evidence:** official MAX docs + Povod runtime receipts separately.  
**Asset:** primitives diagram with runtime badges.  
**Transition:** “Но никакая платформа не спасает плохие данные.”

## Slide 8 — «Live data — только после data gate.»
**Support:** Moscow only; raw→normalized; edge cases; source.  
**Evidence:** accepted Moscow gate receipt.  
**Asset:** provider→normalizer→gate→Moscow.  
**Transition:** “И тот же gate — наш механизм масштабирования.”

## Slide 9 — «Масштабируем способ подключения, а не обещание покрытия.»
**Support:** ProviderAdapter; canonical domain; city quality gate; second city only later.  
**Evidence:** contracts/source + future gate.  
**Asset:** repeated adapter/gate pipeline.  
**Transition:** “Такое разделение видно и в архитектуре.”

## Slide 10 — «Рекомендации не переписывают факты.»
**Support:** source/adapter → canonical catalog → eligibility → ranking → API/MAX.  
**Evidence:** current source + runtime labels.  
**Asset:** one architecture diagram.  
**Transition:** “Теперь главное — что из этого действительно доказано.”

## Slide 11 — «Проверяем гипотезы публичными данными, а не выдуманным пилотом.»
**Support:** public source triangulation; competitor/platform/data/legal evidence; no simulated respondents.  
**Evidence:** source manifest and research archives.  
**Limit:** this does not prove Povod usability.  
**Asset:** evidence-source map.  
**Transition:** “Поэтому отдельно показываем границу между знанием и предположением.”

## Slide 12 — «Что реально доказано на момент защиты.»
**Evidence classes:** source-of-truth / official docs / source code / runtime / legal.  
**Asset:** compact scoreboard with evidence IDs.  
**Rule:** only show as main slide if core rows are mostly green; otherwise move detail to backup.  
**Transition:** “За каждый участок критического пути есть владелец.”

## Slide 13 — «The Boys — ownership критического пути.»
**Evidence:** real roster only.  
**Asset:** person → responsibility, no inflated CV.  
**Transition:** “И всё это ради одного простого результата.”

## Slide 14 — «Повод живёт там, где пользователь уже общается.»
**Support:** find for yourself; trust the details; save; later return/share.  
**Close:** “Не показать всё. Помочь выбрать один реальный повод — под твои условия и с честными данными.”  
**Evidence:** the accepted demo just shown.

## Backup set
- architecture;
- data model;
- Moscow/provider gate;
- MAX identity/security;
- MAX integration/platform matrix;
- provider/legal;
- public-evidence validation;
- scale;
- roadmap;
- compliance matrix;
- evidence index.

## What to remove from the old deck
- 2–3-city MVP;
- Moscow/SPb BETA badges;
- old 12/48/14 pilot as result;
- map as mandatory core;
- basic subscriptions/invite in P0;
- “one context = less switching” as measured outcome;
- concept Smart Povod notification presented as working;
- broad “dozens of sources” phrasing without evidence.
