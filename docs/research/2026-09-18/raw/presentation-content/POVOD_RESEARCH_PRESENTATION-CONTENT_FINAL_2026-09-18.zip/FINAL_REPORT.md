# FINAL REPORT — Presentation Content Verification

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** presentation-content  
**Date:** 18.09.2026  
**Status:** FINAL WITH OPEN BLOCKERS

## Status legend

- **CONFIRMED** — directly supported by binding project material or direct evidence.
- **VERIFIED BY OFFICIAL DOCS** — current official external documentation supports the statement.
- **VERIFIED BY SOURCE CODE** — verified from current source; this topic could only confirm the located 16 Sep source baseline, not the 18 Sep HEAD.
- **VERIFIED BY RUNTIME** — direct executed evidence exists.
- **LIKELY** — evidence supports but does not prove.
- **PROPOSED** — recommendation/project proposal.
- **NEEDS RUNTIME VERIFICATION** — static/docs evidence is insufficient.
- **NEEDS LEGAL VERIFICATION** — exact legal applicability remains open.
- **UNKNOWN** — cannot be responsibly determined here.
- **REJECTED** — contradicted, obsolete, out of scope, or unsafe to claim.

---

# 1. EXECUTIVE SUMMARY

The previous content-deck direction survives verification: the strongest presentation is not a feature catalogue. It is a single evidence-backed story from a concrete intent to a concrete occurrence.

The canonical pitch remains:

**“Повод помогает перейти от ‘хочу куда-нибудь выбраться’ к конкретному событию, которому можно доверять — внутри MAX.”**

The primary narrative is still:

`MAX → validated identity → conditions → live Moscow events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → open original → optional save`

The final verification introduces four material corrections:

1. The earlier interview/usability plan is superseded by an explicit project decision to use public-information / desk research in this phase.
2. MAX must not be described as automatically “closing” a retention loop: official docs show that a direct `startapp` can open a Mini App **without launching the bot**. Smart Povod therefore needs separate bot-enrollment/message E2E evidence.
3. The old test deck’s 2–3 city MVP, Moscow/SPb `BETA`, map/subscriptions/invite in MVP and unrun pilot metrics conflict with the frozen P0 or evidence policy.
4. Current MAX platform constraints add presentation/readiness implications: `platform-api2.max.ru`, trusted/Minцифры certificate chain, normal public partner verification/moderation/licence requirements, and removal of group-participant add on 30.09.2026.

The content research is therefore ready for synthesis, while the product/demo remains blocked on runtime, provider/legal, exact case and account-provisioning evidence.

---

# 2. FINAL VERDICT

**FINAL WITH OPEN BLOCKERS.**

## Keep
- Evidence-first narrative.
- Solo-first.
- Moscow-only P0.
- Occurrence-level honesty.
- UNKNOWN as a first-class user-visible state.
- Visible source/provenance and original-source opening.
- Hard constraints before ranking.
- Demo before architecture.
- Concise architecture and evidence-scoreboard slides.
- Scale through repeated data gates rather than pre-claimed coverage.

## Change
- Desk research replaces interviews/usability as the current validation method.
- MAX wording becomes “documented primitives + Povod E2E to prove”, not “proven retention”.
- Smart Povod is P1 and cannot be a hero demo ending until its exact path is proven.
- Social must be user-driven and optional; no programmatic group-add dependency.
- Add platform onboarding/licence/certificate readiness to evidence requirements.
- Correct T002 evidence to the latest located final pass.

## Block
Do not finalize “works”, “live Moscow”, “validated identity”, “saved persists”, “Smart Povod”, or provider approval claims until direct evidence is attached.

---

# 3. WHAT WAS VERIFIED

## Project materials
- Binding project context supplied in the final-verification request.
- Previous presentation-content result.
- `POVOD_TEST_DECK_V1.pptx`.
- T002 host PowerShell/Git evidence from 16.09.2026.

## File-library search
Exact named canonical files were searched:
- `POVOD_FINAL_SCOPE_FREEZE_MVP.md`
- `POVOD_PRODUCT_SPEC_V1.md`
- `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`
- `POVOD_PRODUCT_CONTRACT_V1.json`
- `MOSCOW_DATA_GATE_RECEIPT.json`

They were **not directly retrievable** by exact file name from File Library in this research environment. The final-verification request itself explicitly restates the controlling frozen rules and is treated as binding for this report. A host/Codex pass over the actual local files remains required.

## External current sources
Primary official sources were rechecked for:
- MAX API changes.
- MAX Mini App deep links and sharing.
- MAX Bridge init data.
- MAX normal partner onboarding and bot moderation.
- MAX placement rules.
- MAX group-member method removal.
- MAX webhook transport.
- KudaGo API/open licence.
- Public hackathon track/finalist/final-date information.

See `SOURCE_MANIFEST.csv/json`.

---

# 4. CURRENT STATE AS OF 18.09.2026

## Product/scope
**CONFIRMED**
- solo-first;
- Moscow-only P0;
- occurrence-level details;
- honest UNKNOWN;
- source/provenance;
- source opening;
- optional save;
- social optional;
- no silent P0 expansion.

## Presentation content
**PROPOSED / VERIFIED AGAINST CURRENT SCOPE**
- 10–14-slide evidence-first deck;
- recommended 14-slide blueprint;
- live demo after scenario, before architecture;
- architecture after product;
- explicit evidence status slide;
- backup slides for technical/provider/security/compliance detail.

## Source baseline
**CONFIRMED for latest located 16 Sep T002 pass**
- baseline: `d48f01eafa23ef4a0a2b98cb20b74e5052423a74`
- handoff: `4f9a198d4fa2b18686efa19a59b6ac78281d341d`
- whitespace check: PASS
- prohibited tracked paths: PASS
- final tree: CLEAN
- remote: NONE

T002 explicitly does **not** prove build, Docker, PostgreSQL, Redis, browser, MAX, live provider, live AI or end-to-end behavior.

## Current HEAD
**UNKNOWN**
The connected GitHub account did not expose the `The-Boys-Max` repository. No 18 Sep HEAD/runtime state can be inferred from T002.

## Live/runtime
**NEEDS RUNTIME VERIFICATION**
- MAX mobile;
- MAX web;
- signed identity;
- live Moscow data gate;
- KNOWN/UNKNOWN runtime;
- source opening;
- save persistence;
- provider failure state;
- Smart Povod;
- optional share.

## Provider
KudaGo remains a technically documented candidate, not an approved Povod provider in this report. Exact product/legal/runtime acceptance remains open.

---

# 5. KEY FINDINGS

### KF-01 — The strongest differentiator is truthful decision support, not catalogue size
**TYPE:** INFERENCE / RECOMMENDATION  
The deck should foreground a concrete occurrence with conditions, UNKNOWN and provenance rather than “more events”.

### KF-02 — UNKNOWN is presentation-worthy
**TYPE:** RECOMMENDATION  
A real UNKNOWN case demonstrates the product contract more strongly than another feature.

### KF-03 — MAX is a platform argument, not a measured-outcome argument
**TYPE:** FACT + INFERENCE  
Official docs verify Mini Apps, signed init data, deep links and sharing. They do not verify that Povod improves retention.

### KF-04 — `startapp` does not prove bot enrollment
**TYPE:** FACT  
Official Mini App docs explicitly describe a direct deep link opening the Mini App without launching the bot.

### KF-05 — Programmatic group-member add is a dead-end dependency
**TYPE:** FACT / RECOMMENDATION  
The method is removed on 30.09.2026. Optional social should use user-driven sharing/deep links.

### KF-06 — MAX normal public onboarding is itself a readiness dependency
**TYPE:** FACT / BLOCKER  
Current public docs require verified RF-resident business/self-employed profiles in the normal path; placement rules require a licence agreement. A hackathon exception was not verified.

### KF-07 — KudaGo provenance has legal relevance
**TYPE:** FACT  
Its open licence requires direct indexable links to the exact original material when reused.

### KF-08 — Static code is still not runtime evidence
**TYPE:** FACT  
The latest located T002 handoff says so explicitly.

### KF-09 — The old deck is a useful anti-regression artifact
**TYPE:** INFERENCE  
It clearly reveals stale assumptions that must not leak into the final presentation.

---

# 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

See `DECISION_DELTA.md` and `FACT_CHECK_MATRIX.csv`.

Material changes:
- interviews/usability → desk research for this phase;
- MAX “closed retention loop” → platform primitives + E2E requirement;
- social share → no programmatic group-add dependency;
- old multi-city → Moscow-only;
- T002 SHAs corrected;
- MAX onboarding/licence/API2/cert requirements added to readiness;
- provider/source attribution made more legally explicit.

Unchanged:
- solo-first;
- occurrence;
- UNKNOWN;
- provenance;
- hard constraints;
- early demo;
- evidence scoreboard;
- architecture after product.

---

# 7. CONFIRMED FACTS

1. P0 is frozen around the solo-first flow supplied by the project owner.
2. Moscow is the only intended demo city in P0.
3. Social is optional continuation.
4. The old test deck contains a 2–3-city MVP and Moscow/SPb BETA framing that is stale.
5. The old deck marks its proposed pilot `NOT RUN`.
6. Current MAX docs provide `startapp` Mini App deep links up to 512 characters.
7. Current MAX docs state a direct `startapp` can open the Mini App without launching the bot.
8. MAX Bridge `initData` is intended for server validation; `initDataUnsafe` is not valid authentication proof.
9. MAX docs recommend using `auth_date` to invalidate old init data, with about one hour shown as a recommended interval.
10. `:share` is documented for iOS, Android and web; desktop support is in development.
11. MAX group-member add is scheduled for removal on 30.09.2026.
12. Current API docs direct bots/apps to `platform-api2.max.ru` and mention the Minцифры certificate chain.
13. MAX webhook docs reject HTTP/self-signed webhook delivery.
14. Normal public MAX partner onboarding requires a verified RF-resident legal entity/IP/self-employed profile.
15. MAX placement rules require an active licence agreement.
16. KudaGo official API docs expose v1.4 and Moscow (`msk`).
17. KudaGo's open licence permits use subject to conditions and requires direct open/indexable exact-source links.
18. KudaGo provides no warranty equivalent to a product SLA.
19. The public hackathon track “Досуг и развлечения” includes event-related services.
20. Latest located T002 final pass is the `d48f01e...` / `4f9a198...` pair and remains source-control evidence only.

---

# 8. RECOMMENDATIONS

See `RECOMMENDATIONS.md`.

Priority order:
1. current HEAD + official case;
2. P0 runtime campaign;
3. Moscow/provider runtime+legal gate;
4. MAX provisioning;
5. final screenshot/evidence board;
6. patch deck;
7. record fallback demo.

No new infrastructure is recommended by this content research.

---

# 9. REJECTED / DEFERRED OPTIONS

## REJECTED
- social-first/group-first narrative;
- 2–3 city P0;
- Moscow/SPb BETA without gates;
- unrun pilot metrics presented as results;
- programmatic group-add dependency;
- “all events”, “always current”, “perfect AI” claims;
- static code represented as runtime;
- provider represented as partner/approved without evidence.

## DEFER
- map as hero/P0 feature;
- Smart Povod hero demo;
- second city;
- optional share demo if platform path is not runtime verified;
- provider brand/logo in main deck.

---

# 10. RISKS

See `RISKS.md`.

Highest risks:
- demo evidence gap;
- live-data/provider gate;
- normal MAX onboarding vs hackathon provisioning;
- current HEAD staleness;
- official case/rubric gap;
- provider attribution/legal exact-use gap;
- venue/provider outage;
- concept/runtime screenshot confusion.

---

# 11. BLOCKERS

1. Exact official case PDF/rubric not available here.
2. Current repository HEAD not verified on 18 Sep.
3. Frozen P0 E2E not proven in this archive.
4. Moscow data gate not closed here.
5. Provider exact legal/runtime gate not closed here.
6. Hackathon-specific MAX onboarding/provisioning not verified.

These blockers prevent the research status from being “FINAL VERIFIED RESEARCH”.

---

# 12. OPEN QUESTIONS

See `GAPS_AND_OPEN_QUESTIONS.md`.

Most consequential:
- exact case requirements;
- hackathon MAX account path;
- actual current HEAD;
- provider approval;
- exact source-link/indexability treatment inside final client;
- Smart Povod enrollment permission path.

---

# 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`.

Minimum defense gate:
- build identity;
- clean build/start;
- MAX mobile;
- MAX web;
- valid/tampered/stale initData;
- live Moscow provider;
- occurrence KNOWN/UNKNOWN;
- source;
- hard filters;
- save persistence;
- source-unavailable;
- fallback recording.

Smart Povod/share only if included in the final demo.

---

# 14. REQUIRED MANUAL / LEGAL CHECKS

## Manual
- official case page mapping;
- current HEAD;
- team roster;
- final runtime-vs-concept asset labels;
- final event IDs;
- MAX account status.

## Legal
- MAX placement/licence/onboarding exact state for hackathon;
- KudaGo exact reuse/cache/indexability/images/commercial interpretation;
- any organizer-specific terms that supersede normal public partner flow.

---

# 15. EXACT CHANGES FOR «ПОВОД»

## Main deck
- Keep 14-slide blueprint from `PRESENTATION_BLUEPRINT.md`.
- Rewrite validation slide to public-evidence validation.
- Remove 2–3 cities and SPb BETA.
- Remove map/subscriptions/invite from P0 list.
- Narrow MAX slide wording.
- Put Smart Povod behind “verified P1” language until E2E.
- Add evidence IDs/statuses.
- Keep provider name in backup until approved.
- Update T002 evidence references.

## Demo
- Finish P0 at save.
- UNKNOWN/source is mandatory demonstration if real evidence exists.
- Smart Povod/social are optional continuations, never required to prove personal value.

## Q&A
- State what is static, official-doc, runtime, legal, or unknown.
- Do not turn “architecture supports” into “works”.
- Be explicit that current public MAX onboarding rules may differ from organizer-provisioned hackathon access.

---

# 16. IMPACT ON P0 / P1 / STRETCH

## P0
**No scope additions.**
Only evidence/readiness changes:
- MAX runtime/account readiness;
- Moscow/provider gate;
- source/UNKNOWN proof;
- save persistence;
- honest failure states.

## P1
- Follow/Smart Povod remains after stable core.
- New requirement is evidentiary, not scope expansion: prove bot relationship/message/deep-link path before presenting it as working.

## STRETCH
- second city only after separate gate;
- optional user-driven share;
- no mandatory group construction.

---

# 17. WHAT NOT TO DO

- Do not turn the deck into a market-size or feature-count presentation.
- Do not simulate research respondents.
- Do not present a concept notification as a delivered Smart Povod.
- Do not silently substitute fixture/mock events when provider fails.
- Do not call a provider partner without an agreement.
- Do not label Moscow/another city active without gate evidence.
- Do not claim `startapp` proves a started/enrolled bot.
- Do not rely on the soon-removed group-member API.
- Do not say “production-ready”.
- Do not add infrastructure to make a presentation slide sound more sophisticated.

---

# 18. SELF-CRITIQUE / RED TEAM

### Attack: “The deck is over-indexing on UNKNOWN/source and under-selling delight.”
**Finding:** Valid concern.  
**Response:** Keep the presentation human and visual, but UNKNOWN/source remain differentiators because they are both product-trust and data/legal boundary mechanisms. Do not make the entire deck defensive.

### Attack: “Fourteen slides are too many.”
**Finding:** Possible. Exact defense timing is unknown because official case/rubric is unavailable.  
**Response:** 14 is a content blueprint, not a requirement. Merge scale/architecture or team/close first if timing is shorter. Do not remove demo/UNKNOWN/evidence before low-value slides.

### Attack: “Desk research cannot validate Povod usability.”
**Finding:** Correct.  
**Response:** Do not claim it does. It validates problem/context/platform/competitive/public patterns. Runtime usability remains unproven unless real sessions are later run.

### Attack: “Normal MAX business onboarding may not apply to a student hackathon.”
**Finding:** Correct and important.  
**Response:** Public docs describe the normal path; organizer-specific hackathon provisioning could supersede it. That is why the report marks a manual open question rather than an impossibility claim.

### Attack: “KudaGo licence might be sufficient; why keep legal gate open?”
**Finding:** The official open licence is real, but exact use includes Mini App/WebView behavior, caching/transformation, images and indexability.  
**Response:** P0 can reduce legal surface by using metadata/source links and avoiding optional content, but exact approval must come from the provider/legal research gate.

### Attack: “Evidence scoreboard exposes weaknesses.”
**Finding:** It can, if most rows are red.  
**Response:** Do not show a large failure board on defense. The recommendation is to use it only after the core proof is mostly green; otherwise move detailed gaps to backup and keep the main deck truthful.

### Attack: “Smart Povod is what makes MAX special; deferring it weakens the pitch.”
**Finding:** It is a strong P1 story.  
**Response:** Better a truthful optional P1 demo than a fabricated retention loop. If E2E closes, it can return to the main path immediately.

### Attack: “A source link being indexable inside MAX may be impossible to reason about.”
**Finding:** Exact interpretation is legal/technical and unresolved.  
**Response:** Keep source CTA regardless for UX; separately close provider applicability. If it fails, change provider/use terms rather than weaken provenance.

### Attack: “The previous research used stale T002 SHAs.”
**Finding:** Confirmed.  
**Response:** Corrected in this archive; demonstrates why evidence IDs and current-head receipts are required.

### Overengineering check
No new technology is recommended. The verification pass mostly removes scope and adds proof obligations.

---

# 19. MISSING AREAS CHECK

## What might have been forgotten?
- normal MAX account/legal onboarding;
- API2/certificate migration;
- imminent group-member API removal;
- direct `startapp` not starting bot;
- distinction between public problem evidence and product usability evidence;
- current HEAD drift after 16 Sep;
- exact-case page-level compliance;
- provider source-link licence consequence.

These were additionally checked.

## Still impossible to close here
- exact official case/rubric;
- current HEAD;
- actual MAX account status;
- actual app runtime;
- accepted Moscow receipt;
- exact provider legal approval.

## Requires separate runtime
Listed in section 13.

## Requires human/manual decision
Deck timing, roster, provider branding, Smart Povod inclusion, final event IDs.

## Requires legal consultation/manual legal decision
MAX licence/onboarding applicability and provider exact-use interpretation.

## Requires Codex/host
Current source, official PDF, runtime acceptance and evidence capture.

## Can be considered closed
- narrative direction;
- frozen P0 interpretation used here;
- rejection of old multi-city/pilot claims;
- public MAX deep-link/initData/share/group-add semantics as of 18 Sep;
- source/control evidence limitations;
- presentation evidence policy.

---

# 20. SOURCE MANIFEST

The authoritative manifest is:
- `SOURCE_MANIFEST.csv`
- `SOURCE_MANIFEST.json`

Primary-source priority was followed wherever public official documentation was available.

Important limitation: the exact case PDF and exact named local canonical docs were not directly readable from File Library in this environment; they are explicitly delegated to the host/Codex pass rather than guessed.

---

# 21. FINAL CHECKLIST

- [x] Major research claims are in `CLAIMS_EVIDENCE.csv`.
- [x] Current external platform claims were re-searched on 18.09.2026.
- [x] Official MAX/KudaGo sources were prioritized.
- [x] Dates and September 2026 MAX breaking changes were checked.
- [x] No GitHub project quality ranking was invented.
- [x] Latest located T002 final SHAs were corrected.
- [x] Runtime claims are not inferred from source files.
- [x] P0 was not silently expanded.
- [x] Old deck conflicts are explicitly documented.
- [x] Recommendations are actionable.
- [x] Rejected/deferred options are recorded.
- [x] Open questions are recorded.
- [x] Source manifest exists in CSV + JSON.
- [x] Decision delta exists.
- [x] `machine_summary.json` exists.
- [x] `CODEX_ACTIONS.md` exists.
- [x] Required runtime and legal/manual checks are separated.
- [x] Self-critique/red-team completed.
- [x] Missing-areas check completed.
- [ ] Exact official case page mapping — **OPEN BLOCKER**.
- [ ] Current 18 Sep HEAD/runtime acceptance — **OPEN BLOCKER**.
- [ ] Moscow/provider formal acceptance — **OPEN BLOCKER**.
- [ ] Hackathon-specific MAX provisioning/legal state — **OPEN BLOCKER**.

Archive integrity is validated during ZIP creation; see `ARCHIVE_MANIFEST.txt`.
