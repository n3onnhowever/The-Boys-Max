# Gaps and Open Questions

## BLOCKERS

1. **Exact official case PDF/rubric** — not accessible in this research environment.
2. **Current repository HEAD and current app state** — connected GitHub did not expose `The-Boys-Max`; latest direct Git evidence found is from 16.09.2026.
3. **MAX P0 E2E** — no accepted receipt here for mobile + web launch, signed identity, feed, occurrence, UNKNOWN/source, save.
4. **Moscow live-data gate** — formal accepted gate receipt not available here.
5. **Provider exact legal gate** — KudaGo remains technical candidate, not approved.
6. **Hackathon-specific MAX provisioning** — public docs describe normal business-partner onboarding; organizer exception/path is unknown.

## OPEN QUESTIONS

- What exact scoring criteria, timing and mandatory submission artifacts are in the official case?
- Does the hackathon provide bot/Mini App tokens or bypass the normal public partner onboarding path?
- What is the final current HEAD/commit and are all screenshots produced from it?
- Which provider is formally approved for the defense build?
- How is source-link indexability interpreted inside the final MAX Mini App/WebView?
- What exact cache/retention/transformation rights are accepted for the chosen provider?
- Does the chosen Mini-App-first entry create the relationship needed for later bot messaging?
- Is `share` actually needed for the defense, or should it remain backup only?
- Is the final talk timing compatible with 14 slides + 90-second demo?

## Requires runtime test

- MAX mobile and web.
- initData positive/tampered/stale.
- Moscow provider live fetch/normalization.
- KNOWN and UNKNOWN price.
- exact source opening.
- filter eligibility.
- save persistence.
- provider unavailable/degraded state.
- Docker clean build/start/health.
- Smart Povod if shown.
- share platform path if shown.

## Requires human/manual decision

- final team roster/ownership slide;
- whether Smart Povod appears in main deck or backup after runtime;
- whether provider name/logo appears;
- final deck length after official timing check;
- which exact event IDs are frozen for demo.

## Requires legal/manual review

- MAX licence/onboarding state for the hackathon account;
- KudaGo exact reuse/caching/indexability/images/commercial interpretation.

## Requires Codex/host

- inspect current repo, HEAD and source-of-truth files;
- read `input/official/*.pdf` locally;
- run acceptance commands and save immutable evidence;
- patch presentation-content docs only after evidence status changes.

## Closed enough for synthesis

- solo-first P0 narrative;
- Moscow-only scope;
- Occurrence/UNKNOWN/source as core story;
- social optionality;
- old multi-city/pilot claims rejected;
- MAX startapp/share/initData public semantics;
- imminent group-add API removal;
- KudaGo attribution condition as an official fact;
- latest located T002 final SHAs.
