# Runtime Verification Required

Static source existence does not satisfy these checks.

## RV-01 — Current build identity
Record:
- current branch
- `git rev-parse HEAD`
- `git status --short`
- dependency lockfile state
- build artifact identifier

**Pass:** immutable commit/build attached to all later evidence.

## RV-02 — Clean build/start
From a clean state:
- install using the project's locked dependency procedure;
- build;
- start required services;
- hit health endpoint;
- record elapsed times and logs.

Do not invent a performance SLA. Report measured values.

## RV-03 — MAX mobile launch
Capture real MAX mobile client:
`bot/entry → Mini App → For You`.
Record client version/device/build.

## RV-04 — MAX web launch
Repeat in MAX web. Do not substitute standalone browser rendering.

## RV-05 — Identity validation
At minimum:
1. valid `initData` accepted;
2. modified field/hash rejected;
3. stale `auth_date` rejected per chosen policy;
4. session created server-side;
5. `initDataUnsafe` alone cannot authenticate.

## RV-06 — Live Moscow provider
Save:
- request parameters;
- timestamp;
- response status;
- body digest/hash;
- minimal lawful raw sample or redacted receipt;
- normalized Event/Occurrence output;
- source URL.

## RV-07 — Occurrence honesty
Demonstrate:
- concrete date/time/place;
- one KNOWN price;
- one genuine UNKNOWN/conditional price;
- no `UNKNOWN → 0/free` conversion;
- no fabricated coordinates.

## RV-08 — Source/provenance
From detail:
- visible source;
- opens the correct original material;
- no open redirect;
- source URL sanitized/allowlisted according to final policy.

## RV-09 — Hard constraints
Use a known candidate set:
- ineligible time/budget/city item must not be restored by ranking score;
- eligible items may be ranked.

## RV-10 — Save persistence
Save → reload → new request/session as defined by product → item remains correctly tied to validated user.

## RV-11 — Failure states
Inject/observe:
- provider timeout/unavailable;
- empty result;
- malformed provider record;
- missing price/place;
- stale data condition if implemented.

UI must not silently substitute fake live data.

## RV-12 — Smart Povod (P1 only if shown)
Prove:
`eligible/enrolled user → bot message → exact event context → startapp → exact occurrence`.
Also prove what establishes permission/relationship for proactive messaging.

## RV-13 — Share (optional)
Test the exact selected mechanism on each platform claimed. Do not claim desktop `:share` readiness while official docs mark it in development.

## RV-14 — Fallback demo
Record a final 90-second screen capture from the same accepted build/data state. Store evidence IDs and timestamps.

## Evidence output format

Each check should produce a small manifest:
```json
{
  "evidence_id": "RV-XX-...",
  "commit": "...",
  "captured_at": "...",
  "platform": "...",
  "data_mode": "live|verified_snapshot|fixture",
  "result": "PASS|FAIL",
  "artifacts": ["..."]
}
```
