# Recommendations

## P0-facing recommendations

1. **Keep the main narrative narrow.** The hero flow is `MAX → validated identity → conditions → live Moscow event → Occurrence → date/time/place → price or UNKNOWN → source → optional save`.
2. **Put the live demo after the concrete scenario slide**, before architecture. If runtime evidence is incomplete, use a clearly labelled timestamped fallback recording rather than pretending a mock is live.
3. **Make occurrence honesty a hero idea.** One real KNOWN-price case + one real UNKNOWN case + source opening is stronger than more feature slides.
4. **Treat personalization as eligibility first.** Do not say “AI knows you”; show hard conditions, then ranking among eligible options.
5. **Present MAX as primitives, not outcomes.** Official docs prove Mini Apps, signed init data, deep links and sharing mechanisms. They do not prove Povod retention, conversion or a working Smart Povod.
6. **Keep social optional.** Use user-driven share/deep links if they are runtime verified. Do not depend on programmatic group-member addition.
7. **Make the evidence scoreboard a main slide** only if it is updated immediately before the defense. Static code, platform docs, runtime, user/public evidence and legal evidence must remain separate.
8. **Use provider names in backup until approved.** In the main deck, say “verified live source” only after the gate passes. Never imply partnership.
9. **Replace interview/pilot language with desk-research evidence** for this phase. If real usability work is later performed, add it as a new evidence class, not retroactively.
10. **Use a truthful fallback demo**: provider outage → explicit source-unavailable/degraded state + last verified recording/receipt, never silent mock substitution.

## Presentation wording

Preferred:
- “One verified demo city: Moscow.”
- “Price from the source, or honest UNKNOWN.”
- “Source is visible and can be opened.”
- “MAX gives us documented Mini App, bot, deep-link and sharing primitives.”
- “A new city appears only after a data gate.”

Avoid:
- “all Moscow events”
- “always current”
- “AI perfectly recommends”
- “seamless retention”
- “production-ready”
- “works on every MAX client”
- “KudaGo is our partner”

## Evidence discipline

Every runtime screenshot/video should be tagged with:
- build/commit
- timestamp
- environment
- platform/client
- evidence ID
- whether data are live, snapshot, or fixture

A concept/mock image should say `CONCEPT`; a runtime image should say `RUNTIME`.
