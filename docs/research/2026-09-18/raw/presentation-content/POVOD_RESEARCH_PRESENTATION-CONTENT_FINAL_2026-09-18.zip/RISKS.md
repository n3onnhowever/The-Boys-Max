# Risks

## P0 risks

### R-P0-01 — Main demo depends on unclosed runtime evidence
**Severity:** Critical  
**Status:** OPEN  
**Risk:** A polished narrative can overstate a product that has not passed the exact frozen end-to-end path.  
**Mitigation:** Run the acceptance campaign in `RUNTIME_VERIFICATION_REQUIRED.md`.

### R-P0-02 — Moscow live-data gate not formally closed in this topic
**Severity:** Critical  
**Status:** OPEN  
**Risk:** The deck could say “live Moscow” while provider/runtime receipts are incomplete.  
**Mitigation:** accepted `MOSCOW_DATA_GATE_RECEIPT` + raw/normalized evidence + edge cases.

### R-P0-03 — Current HEAD unknown
**Severity:** High  
**Status:** OPEN  
**Risk:** Presentation screenshots/architecture may represent the 16 Sep baseline instead of the defense build.  
**Mitigation:** host/Codex record HEAD + status + build.

## MAX/platform risks

### R-MAX-01 — Normal partner onboarding vs hackathon access
Official public docs require a verified RF-resident legal entity/IP/self-employed profile for the normal partner platform, bot moderation, and placement rules require a licence agreement. A hackathon-specific exception/provisioning path was not verified publicly.

**Impact:** could block a public bot/Mini App demo even if code is ready.  
**Action:** confirm organizer-provided credentials/provisioning in writing or in the actual account.

### R-MAX-02 — Smart Povod enrollment assumption
A direct `startapp` can open the Mini App without launching the bot.  
**Impact:** opening the Mini App does not itself prove the later proactive-bot-message relationship.  
**Action:** test actual user enrollment/message eligibility.

### R-MAX-03 — Breaking group API
`POST /chats/{chatId}/members` is scheduled for removal on 30.09.2026.  
**Impact:** social flow must not depend on it.  
**Action:** user-driven sharing/deep links only.

### R-MAX-04 — Platform matrix
`:share` is documented for iOS, Android and web; desktop support is still in development. Other bridge methods can have their own platform matrix.  
**Action:** do not extrapolate one capability to all clients.

### R-MAX-05 — Transport/certificate
Current docs require `platform-api2.max.ru`; webhook HTTP/self-signed TLS are not supported.  
**Action:** runtime preflight.

## Provider/data/legal risks

### R-DATA-01 — “free” vs price semantics
Provider flags do not necessarily prove zero total cost.  
**Action:** keep raw evidence and honest UNKNOWN/conditional semantics.

### R-DATA-02 — Attribution/indexability
KudaGo's official licence requires direct indexable links to the exact original material when data are reused.  
**Action:** exact MAX/WebView applicability and link behavior need legal/manual verification.

### R-DATA-03 — Provider terms can change
KudaGo terms reserve unilateral changes and provide no availability/data-accuracy warranty.  
**Action:** snapshot source terms and keep ProviderAdapter/fallback strategy; do not claim SLA.

### R-DATA-04 — Images/descriptions/third-party rights
API access does not automatically settle every third-party content right for the exact presentation/product use.  
**Action:** prefer metadata/source-link P0 until cleared.

## Presentation/UX risks

### R-PRES-01 — Fake precision
Numbers without a completed study are worse than no numbers.  
**Action:** remove old pilot numbers and unsupported “dozens of sources” type claims unless desk research supplies traceable evidence.

### R-PRES-02 — Architecture becoming the story
**Action:** product/demo first, architecture later, one slide.

### R-PRES-03 — Concept screenshots mistaken for runtime
**Action:** explicit `CONCEPT` vs `RUNTIME` labels in asset manifest.

## Operational risks

- venue Wi-Fi/provider outage;
- token/session expiry;
- stale live data during defense;
- bot moderation/account state changes;
- source site unavailable;
- provider response schema/availability drift.

Prepare a verified fallback recording and evidence receipt, not a fake live response.
