# Prohibited / Evidence-Gated Claims

Do not use these without direct evidence:

- «все события города»
- «все события Москвы»
- «полная афиша Москвы»
- «самая полная афиша»
- «по всей России»
- «самый быстрый»
- «экономит N минут»
- «всегда актуальные события»
- «всегда актуальная цена»
- «цены в реальном времени»
- «бесплатно» merely because a provider flag says `free=true`
- «ИИ идеально подбирает»
- «ИИ знает, куда вам хочется»
- «лучшие события именно для вас»
- «пользователи хотят…» without traceable evidence
- «пользователи поняли…» without real user evidence
- «проверено пользователями» when only desk research exists
- «повышает retention»
- «повышает conversion»
- «бесшовная авторизация» before runtime
- «работает на всех клиентах MAX»
- «работает в MAX mobile и web» before RV-03/RV-04
- «отказоустойчивый»
- «безопасный» as an absolute
- «production-ready»
- «масштабируется без ограничений»
- «KudaGo — наш партнёр»
- «официальная интеграция с KudaGo»
- «данные лицензированы для нашего exact flow» before exact legal gate
- «мы гарантируем актуальность источника»
- «точная геолокация всех событий»
- «MAX сам возвращает пользователя» without a proven enrollment/message path
- «startapp запускает бота» — contradicted by current official docs
- «мы можем автоматически добавить друзей в групповой чат» as a durable API strategy

## Safer phrasing

Instead of:
> «всегда актуальная цена»

Use:
> «показываем цену, которую получили от источника; если её нет — UNKNOWN».

Instead of:
> «охватываем Россию»

Use:
> «новый город появляется только после data gate».

Instead of:
> «AI выбирает лучше»

Use:
> «сначала применяем явные условия пользователя, затем ранжируем допустимые варианты».

Instead of:
> «MAX даёт retention»

Use:
> «MAX предоставляет Mini App, bot, deep-link и sharing primitives; эффект и наш end-to-end loop подтверждаем отдельно».

Instead of:
> «KudaGo интегрирован»

Use only after gate. Until then:
> «мы тестируем технического кандидата на роль источника».
