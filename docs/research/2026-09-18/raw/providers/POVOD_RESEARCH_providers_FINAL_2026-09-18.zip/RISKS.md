# RISKS

## P0 legal

**L1 — KudaGo MAX/indexability ambiguity — BLOCKER.**
The licence clearly requires direct indexable links to concrete source materials, but does not clearly resolve whether a closed/embedded MAX surface itself must be indexable or whether a direct crawlable target is enough.

**L2 — KudaGo storage/cache/PriceSnapshot ambiguity — BLOCKER for durable retention.**
No explicit cache TTL, durable storage, retention or historic-price clause was located.

**L3 — KudaGo advertising material — BLOCKER unless reliably excluded/authorized.**
The licence imposes special advertising restrictions, while the reviewed event schema does not document `is_ad` or `erid`.

**L4 — Third-party media rights.**
API availability is not proof that every image may be republished. KudaGo itself shows third-party image-source metadata.

## P0 technical/data

**T1 — runtime receipt incomplete.**
Documentation cannot replace the frozen 12/12 run.

**T2 — cancellation/freshness.**
No documented KudaGo cancellation flag or `updated_at` was found. A cancelled/rescheduled event can become materially harmful data.

**T3 — unknown rate limit.**
KudaGo global request quota/fair-use limit is not published in reviewed docs.

**T4 — provider outage/accuracy.**
KudaGo expressly disclaims accuracy and availability. Povod must preserve error/source-unavailable/UNKNOWN states.

## Fallback

**F1 — Timepad rights not currently verified.**
The current legal endpoint could not be fetched in this pass.

**F2 — Radario provenance/deep link.**
Reviewed API schema did not establish a public canonical event URL.

**F3 — PRO.Культура standard partner burden.**
The standard agreement is operationally incompatible with an instant hackathon fallback unless a custom agreement changes it.

**F4 — Ticketscloud is partnership/ticketing oriented.**
Using it only to avoid a KudaGo legal question can add more contractual and technical scope than it removes.

## Operational

- Terms can change; freeze provider evidence before submission/release.
- Do not retain unapproved raw content in backups “just in case”.
- No silent fallback to scraping.
