# GAPS AND OPEN QUESTIONS

## Still open

1. KudaGo written interpretation for MAX Mini App/WebView and indexability.
2. KudaGo permission/limits for normalized durable storage and caching.
3. KudaGo PriceSnapshot/history and purge/retention policy.
4. KudaGo image reuse, third-party source handling and transformations.
5. KudaGo reliable advertising-content exclusion.
6. KudaGo global rate/fair-use limit.
7. KudaGo authoritative cancellation/update mechanism.
8. Frozen KudaGo runtime receipt 12/12.
9. Timepad current legal terms/reuse permission.
10. Timepad cancellation/update semantics.
11. Radario credentials, reuse rights, canonical source/deep link, rate limits.
12. Current 2026 Moscow Open Data event-feed existence and dataset-specific terms.
13. Byte-for-byte reconciliation with canonical POVOD project files that were unavailable in File Library.

## Human/manual decision

- Whether the team is willing to ship only after written KudaGo clarification or wants to pursue a different contractual provider even if integration time increases.
- Which legal evidence standard the team/organizer accepts for hackathon submission.

## Legal consultation

A lawyer is useful if the rightsholder will not answer the indexability, monetization or content-right questions. This research does not replace legal advice.

## Codex/host

Codex can implement provider gates, evidence capture, schema restrictions and failure states. Codex cannot resolve licence meaning or invent permission.

## Considered closed

- KudaGo licence does require per-material direct source links.
- KudaGo trademark rights are excluded from the open licence.
- KudaGo open licence can change/be revoked.
- API v1.4 is the latest version listed in the official KudaGo changelog.
- Timepad GET /v1/events is documented as public/unauthenticated, while the general rate limit is 60 responses/IP/min.
- Standard PRO.Культура partner route is not a zero-onboarding hackathon fallback.
- No reason was found to expand frozen P0 into multi-provider aggregation.
