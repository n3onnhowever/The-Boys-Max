# RECOMMENDATIONS — practically actionable only

## P0

1. Keep **KudaGo = CONDITIONAL_PRIMARY / NOT_APPROVED**.
2. Do not switch providers merely because legal questions are uncomfortable; close the two gates first: canonical runtime receipt + written KudaGo use-case confirmation.
3. Do not implement automatic multi-provider failover in P0. There is currently no second provider with both technical and legal approval.
4. Keep provider-derived P0 data factual and minimal: provider/provider_event_id, exact source URL, title, occurrence start/end nullable, venue/address/coords nullable, categories, age restriction, raw price/is_free, fetched_at, provenance/version. Preserve `UNKNOWN`; never manufacture zero price or missing place/time.
5. P0 visuals should be owned/category placeholders. Provider images/descriptions/body/tagline stay disabled until rights are specifically cleared.
6. Attribution must be event-level and exact. Plain text “Источник: KudaGo” without a link is not sufficient under the text of the KudaGo licence.
7. Do not decide the indexability question by engineering interpretation. Obtain written provider confirmation.
8. Keep cache/durable storage/PriceSnapshot disabled or tightly evidence-scoped until KudaGo confirms permitted retention.
9. Treat cancellation as UNKNOWN unless an authoritative provider signal is verified.
10. Make provider failure visible as `source-unavailable`; do not silently reuse stale data outside an approved retention policy.

## Parallel fallback work, without expanding product scope

- Send one focused rights/use-case request to **Timepad**.
- Send one access/source-link/rights request to **Radario**.
- Do not build complete adapters before those answers.
- Do not onboard PRO.Культура under its standard terms for emergency P0.

## P1 / after hackathon

- If needed, formalize a custom PRO.Культура partnership or Radario/Ticketscloud relationship.
- Add multi-provider precedence/dedup/conflict resolution only after a second provider is actually approved.
- Add image pipeline only after source-specific media rights and purge rules are known.
