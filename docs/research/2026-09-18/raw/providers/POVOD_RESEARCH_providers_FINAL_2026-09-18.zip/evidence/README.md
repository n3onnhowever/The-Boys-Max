# Evidence index

This directory intentionally stores **research notes and evidence descriptors**, not complete copyrighted provider pages.

Files:
- `PROJECT_SOURCE_SEARCH.md` — canonical POVOD File Library search result/limitation.
- `NO_RUNTIME_EVIDENCE_AVAILABLE.md` — explicit runtime evidence boundary.
- `WEB_VERIFICATION_NOTES.md` — first-party web verification notes.
- `LEGAL_QUESTIONS_KUDAGO.md` — exact provider questions.

Authoritative external URLs and access dates are recorded in `../SOURCE_MANIFEST.csv` and `../SOURCE_MANIFEST.json`.
