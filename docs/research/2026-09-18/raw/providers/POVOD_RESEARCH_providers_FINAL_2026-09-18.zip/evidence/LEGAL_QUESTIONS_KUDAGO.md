# REQUIRED MANUAL / LEGAL CHECKS

## KudaGo — exact questions for written confirmation

The purpose is not to obtain abstract legal advice; it is to obtain a provider-side written interpretation of the exact use case.

1. Does the current KudaGo open licence allow data to be displayed inside a **MAX Mini App / embedded WebView** that itself may not be crawlable by search engines?
2. In clause 85, must the **page that contains the source link** itself be indexable, or is it sufficient that the link is direct, crawlable and points to the public concrete KudaGo material?
3. Is a visible clickable label **«Источник: KudaGo» → exact event `site_url`** inside the MAX Mini App sufficient attribution?
4. If not, can the requirement be satisfied through an additional publicly indexable canonical page owned by Povod that contains the same event reference and exact KudaGo source link?
5. May Povod persist normalized factual fields from API events server-side: provider ID, title, dates/occurrences, venue, address, coordinates, categories, age restriction, raw price text, is_free and source URL?
6. Is server/browser/Redis/CDN caching allowed, and are there maximum TTL/refresh requirements?
7. May Povod retain historical **PriceSnapshot/raw price text** after KudaGo changes the upstream event?
8. Is there a maximum retention period? What must happen to records if an event is deleted upstream?
9. What purge/back-up behavior is required if the open licence is revoked or API access is stopped?
10. May descriptions/body/tagline be displayed or transformed/summarized?
11. Does the licence cover images returned by the API? May they be proxied, cached, resized or delivered through a CDN? What attribution is required for `image.source`?
12. Can advertising materials appear in `/events`? If yes, is there a documented flag/feed/API field that allows them to be excluded reliably before display?
13. Is use in a free consumer Mini App acceptable under the restriction on receiving benefit from transferring materials to third parties? How would future sponsorship/advertising/affiliate monetization change the answer?
14. What current request/rate/fair-use limits apply to production API use?
15. Is registration, approval or notification required for production use?
16. Is there an official channel for licence/API change notifications?
17. May the textual label `KudaGo` be used solely for factual source attribution without using the logo?
18. Does the licence term “сайт Пользователя” include web apps, mobile apps and Mini Apps/WebViews?

**Evidence accepted by Povod:** written response from the provider/rightsholder or an authorized legal/integration contact, tied to the described use case. Informal “should be fine” is not enough for the gate.

## Timepad

1. Current legal terms or written provider confirmation permitting a third-party MAX Mini App to display normalized public event metadata obtained from `GET /v1/events`.
2. Whether event `name`, dates, location, coordinates, categories, ticket prices and direct event URL may be stored/cache-displayed, and under what retention/attribution rules.
3. Whether organizer descriptions and poster images may be republished/proxied/resized by a third-party aggregator.
4. Required source attribution/deep-link behavior.
5. Cancellation/update semantics for public event data.
6. Confirmation of current rate/fair-use limits for the planned server-side polling profile.

## Radario

1. Issue scoped API credentials and identify what companies/events the key can read.
2. Confirm the right to display returned event metadata in a MAX Mini App.
3. Provide or confirm a canonical public event/source URL/deep link suitable for Povod's “open source” P0 requirement.
4. Confirm request/rate limits and allowed caching/retention.
5. Confirm image/description rights and attribution.
