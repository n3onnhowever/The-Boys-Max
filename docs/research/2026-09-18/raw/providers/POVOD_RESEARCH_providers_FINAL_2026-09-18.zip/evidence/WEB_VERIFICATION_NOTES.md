# WEB VERIFICATION NOTES — accessed 2026-09-18

## KudaGo
Primary page: https://docs.kudago.com/api/

Verified:
- licence owner: ООО «Реван»;
- simple non-exclusive licence;
- commercial/personal/non-commercial use allowed subject to restrictions;
- derivative works allowed with direct open-for-indexing links to concrete KudaGo source, no nofollow/noindex;
- requirement applies to any use/borrowing/copying;
- advertising-material restriction;
- trademarks excluded;
- third-party-right responsibility on licensee;
- no selling/other benefit from transfer of site materials to third parties;
- unilateral term changes and revocation;
- no accuracy/API-availability warranty;
- latest changelog API entry v1.4 dated 2018-02-02;
- events endpoint, page_size<=100, dates/place/price/is_free/images/site_url.
Direct text searches on the current docs page found no matches for:
- `updated_at`
- `is_ad`
- `erid`
- `cancel`
These are documentation-absence findings, not proof that a backend field or private mechanism cannot exist.

KudaGo robots.txt was checked separately. Generic sections disallow `/public-api` and `/media/`; a `YandexActivity` section explicitly allows `/public-api` before disallowing `/`. This is crawler policy and must not be treated as API licence language.

## Timepad
Primary method page: https://dev.timepad.ru/api/get-v1-events/
Verified:
- GET /v1/events;
- public event info documented as not requiring authentication;
- limit <=100;
- event URL, start/end, location/address/coordinates, categories, numeric ticket prices and registration summary.
General API page documents 60 responses per IP per minute.
Token page warns not to expose privileged tokens client-side.
A server-side official example explicitly demonstrates obtaining public events and constructing photo/name/link/city output.
Current legal endpoint linked from docs (`https://welcome.timepad.ru/about/legal`) returned 502 to this research fetch, so current content-reuse rights were not verified.

## PRO.Культура.РФ
Current partner PDF and API/partner pages were checked.
The standard partner path is a formal public-offer/integration-key model with substantial eligibility and operating requirements. The PDF was analyzed as a PDF (including page-level visual inspection earlier in the research process), not inferred from snippets alone.

## Radario
Official integration and API 1.1 pages were checked.
The docs show intended own-site/external-system event integration, required credentials and event/place/ticket structures. No canonical public event deep-link field was established in the reviewed event schema.

## Ticketscloud
Official partner page, document index and HTTP API v2 docs were checked. The model is contractual ticket distribution/partner integration, not established here as an open general-purpose city-event feed.

## Moscow Open Data
Official portal was attempted, but a current 2026 event feed with schema/freshness/licence could not be verified in this pass. Tool access problems are not reported as a portal outage.
