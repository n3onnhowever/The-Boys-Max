# POVOD provider + licensing + fallback research
**Project:** «Повод»  
**Team:** The Boys  
**Research version:** FINAL-2026-09-18  
**Verification status:** **FINAL WITH OPEN BLOCKERS**  
**Verification date:** 2026-09-18  
**Topic:** providers / licensing / fallback / future multi-provider boundary  
**Previous result:** provider + licensing + fallback research in this same chat, 18.09.2026.

> This is engineering/provider research, not legal advice. Legal statements below are limited to what the reviewed provider documents say; ambiguous clauses remain `NEEDS LEGAL VERIFICATION`.

---

## 1. EXECUTIVE SUMMARY

KudaGo remains the strongest **technical primary candidate** for the frozen Moscow P0, but it remains **NOT APPROVED**. Two independent gates are still open:

1. **Runtime gate:** the canonical KudaGo v1.4 receipt has not been re-executed/closed 12/12 in this final pass.
2. **Legal/use gate:** the current KudaGo open licence clearly allows commercial use and derivative works subject to restrictions, but it also requires direct open-for-indexing links to each concrete source material and contains advertising, trademark, third-party-right and monetization restrictions. It does not explicitly resolve MAX Mini App/WebView applicability, durable normalized storage/cache/retention, PriceSnapshot history, provider-image reuse, reliable ad filtering or revocation purge behavior. [S01]

The previous recommendation is therefore preserved in form but tightened in evidence language:

**KUDAGO = CONDITIONAL_PRIMARY / NOT_APPROVED.**

There is also **no approved automatic fallback today**. Timepad is the strongest low-friction technical fallback candidate, but current content-reuse/legal terms could not be verified because the official legal endpoint returned 502 in this research fetch. Radario is a plausible B2B integration route but requires credentials and a confirmed canonical source/deep link plus rights scope. Standard PRO.Культура.РФ partner terms are too operationally heavy for an emergency hackathon fallback. Ticketscloud is a ticket-distribution partnership rather than a demonstrated open city-event feed. [S03-S18]

No recommendation expands frozen P0. Multi-provider aggregation remains deferred; only a small provider/provenance boundary is recommended.

A second material limitation: the named POVOD source-of-truth files were not retrievable from the accessible File Library in this session. The frozen constraints explicitly supplied in this conversation were respected, but **byte-for-byte source-of-truth conflict verification was not possible**. See `evidence/PROJECT_SOURCE_SEARCH.md`.

---

## 2. FINAL VERDICT

### Provider decision

**Primary:** KudaGo — `CONDITIONAL_PRIMARY`, `NOT_APPROVED`.  
Approval requires both:
- canonical frozen runtime receipt = PASS;
- provider-side written confirmation for the unresolved use/licence questions.

**Fallback:** no provider is currently `APPROVED_FALLBACK`.

Operational sequence:
1. close KudaGo runtime + legal gates;
2. in parallel, request narrowly scoped rights confirmation from Timepad and access/source-link clarification from Radario;
3. build no full fallback adapter until one passes its legal/access gate;
4. if KudaGo cannot be approved and no fallback passes, provider gate = **NO-GO**, not silent scraping.

### P0 data/content position

Until KudaGo confirms the unresolved rights:
- keep P0 provider data factual/minimal;
- do not add descriptions/body/tagline to display;
- do not use provider images/logos;
- do not retain historical PriceSnapshot;
- do not assume arbitrary durable cache/retention;
- persist exact provenance/source URL only within the permissions ultimately confirmed;
- preserve `UNKNOWN` and source-unavailable states.

### Scope compatibility

**No prompt-level conflict with frozen P0 was found.**  
However, exact reconciliation against the named canonical files is `UNKNOWN` because those files were unavailable. Therefore no source-of-truth file should be edited based solely on field names proposed in this archive.

---

## 3. WHAT WAS VERIFIED

### Project/context
- current chat and previous provider research result;
- user-supplied frozen P0/solo-first constraints;
- explicit open status of KudaGo runtime v1.4 receipt/legal gate;
- File Library exact-name search for canonical POVOD documents.

### KudaGo
- current official API page;
- current open licence;
- current published changelog;
- event-list/detail schema and example;
- page-size cap;
- source URL;
- price/is_free;
- image-source example;
- current robots.txt;
- direct absence searches for `updated_at`, `cancel`, `is_ad`, `erid`.

### Fallbacks
- Timepad public-event API, auth exception, rate limit, event fields, image mechanics and integration examples;
- attempted Timepad current legal page;
- PRO.Культура partner page, API model and current partner-agreement PDF;
- Radario current integration page and API 1.1 docs;
- Ticketscloud partner/doc/API surfaces;
- Moscow Open Data as a candidate discovery path.

### Not verified by runtime
No API was executed by this final verification pass. See section 13 and `RUNTIME_VERIFICATION_REQUIRED.md`.

---

## 4. CURRENT STATE AS OF 18.09.2026

| Area | Status | Evidence state |
|---|---|---|
| KudaGo Moscow technical candidate | LIKELY / project-context promising | Official schema verified; current canonical runtime receipt still open |
| KudaGo API documentation | VERIFIED BY OFFICIAL DOCS | S01 |
| KudaGo commercial-use grant | CONFIRMED with restrictions | S01 |
| KudaGo per-material direct attribution | CONFIRMED | S01 |
| KudaGo inside MAX Mini App | NEEDS LEGAL VERIFICATION | Licence says user's “site”; Mini App not explicit |
| KudaGo durable normalized storage | NEEDS LEGAL VERIFICATION | No explicit cache/retention clause located |
| KudaGo PriceSnapshot history | NEEDS LEGAL VERIFICATION | Not expressly addressed |
| KudaGo images | NEEDS LEGAL VERIFICATION | Third-party source example + licensee responsibility |
| KudaGo ad exclusion | BLOCKER / NEEDS LEGAL VERIFICATION | Advertising restriction confirmed; no documented is_ad/erid field |
| KudaGo cancellation/update signal | UNKNOWN | No cancel/updated_at term found in reviewed docs |
| KudaGo global rate limit | UNKNOWN | page_size<=100 only; global rate not found |
| KudaGo frozen runtime receipt | BLOCKER | not executed/closed here |
| Timepad technical fallback | VERIFIED BY OFFICIAL DOCS, NEEDS RUNTIME | public events schema strong |
| Timepad reuse rights | NEEDS LEGAL VERIFICATION | current official legal endpoint inaccessible in pass |
| Radario technical partner integration | VERIFIED BY OFFICIAL DOCS, NEEDS ACCESS/RUNTIME | API 1.1, keys |
| Radario public event source URL | UNKNOWN | not established in reviewed event schema |
| PRO.Культура standard path | VERIFIED, REJECTED for emergency P0 | current partner terms |
| Ticketscloud generic fallback | REJECTED for P0 without partnership | current partner/docs |
| Moscow Open Data current event feed | UNKNOWN / DEFER | not verified |
| Multi-provider aggregation | DEFER | no P0 need |
| Exact SoT conflict check | OPEN GAP | canonical files unavailable |

---

## 5. KEY FINDINGS

### 5.1 KudaGo licence is permissive, but not “free of conditions”

**FACT.** KudaGo's licence permits commercial, personal and non-commercial use subject to restrictions, and permits derivative works. [S01]

**FACT.** Any borrowed/copied/used data or part must contain a direct link open for indexing, without `nofollow`/`noindex`, to the **concrete** KudaGo source material. [S01]

**FACT.** Advertising materials have special restrictions; trademarks are excluded; the licensee must avoid third-party-right infringement; receiving benefit from transferring KudaGo site materials to third parties is restricted. [S01]

**INFERENCE.** A provider-name label without a direct event link does not satisfy the text. A clickable exact `site_url` is much closer to the requirement, but whether the MAX surface containing it must itself be indexable is not stated clearly enough to treat as settled.

**RECOMMENDATION.** Keep this as a provider-side written-confirmation gate.

### 5.2 MAX Mini App is not expressly covered

**FACT.** The licence defines API as software used to transfer materials from KudaGo to the user's “site”. [S01]

**OPEN QUESTION.** Does the rightsholder treat Mini Apps/WebViews/apps as equivalent for this licence? The document does not say.

Do not “solve” this by a local legal interpretation.

### 5.3 Storage/cache/history remain unresolved

No reviewed clause states:
- maximum cache TTL;
- durable normalized storage permission;
- retention duration;
- delete/upstream purge behavior;
- backup purge after revocation;
- historical PriceSnapshot rules.

Absence of a prohibition is **not** being treated here as an affirmative permission.

### 5.4 Images are technically available but not cleanly rights-cleared for P0

KudaGo API returns images. Its official example contains a third-party image-source URL, and the licence puts third-party-right compliance on the licensee. [S01]

**RECOMMENDATION:** owned Povod/category visuals in P0.

### 5.5 Advertising is a stronger blocker than earlier “content caution”

KudaGo expressly says some materials are advertising and places responsibility/restrictions on their use. [S01] Searches of the current documented API page did not find `is_ad` or `erid`.

Therefore:
- “we will filter ads automatically” is **not confirmed**;
- text heuristics such as searching for `erid` are not a legally reliable classifier;
- provider guidance or an authoritative exclusion mechanism is required.

### 5.6 Freshness/cancellation are under-specified

The reviewed KudaGo event documentation did not expose a documented `updated_at` or cancellation field under the searched terms.

This matters because P0 promises a **concrete occurrence**. A source link does not protect UX if Povod displays a stale time for a cancelled/rescheduled event.

**RECOMMENDATION:** keep cancellation truth `UNKNOWN` unless an authoritative signal is found; add refresh behavior only as an engineering proposal after runtime evidence.

### 5.7 robots.txt was previously at risk of being overinterpreted

Generic KudaGo robot rules disallow `/public-api` and `/media`, but there is also a bot-specific `YandexActivity` section that allows `/public-api`. [S02]

More importantly, robots.txt is a crawler directive, not the API licence.

**CORRECTED CONCLUSION:** it does not establish that API use is forbidden and it does not resolve whether MAX attribution meets licence clause 85.

### 5.8 Timepad: technically strong, legal confidence downgraded

The public-event method explicitly says public event information requires no authentication and exposes useful P0 facts and direct event URL. General docs publish a 60 responses/IP/min limit. [S03-S04]

But the current official legal page linked from developer docs returned 502 during this research fetch. [S09]

**FINAL POSITION:** first technical fallback candidate, **not approved for production/republication** until current terms or written permission are obtained.

### 5.9 PRO.Культура: not an emergency fallback under standard terms

Current standard partner terms require, among other things:
- partner onboarding/key;
- qualifying open/launched cultural resource;
- region-wide coverage constraints;
- analytics/counters;
- recurring audit;
- import of all current regional events/places within specified timelines;
- returned links/view data;
- branding;
- separate keys per resource. [S12]

That is an integration partnership, not a drop-in backup API.

### 5.10 Radario: better B2B integration framing, but provenance gap

Radario explicitly documents GET `/events` for displaying events on one's own site/external system; current API docs are v1.1 and require credentials. [S13-S14]

However, the reviewed event schema did not establish a public canonical event URL under the searched URL field names.

Because frozen P0 requires **open source**, this must be solved before Radario can be considered a full fallback.

### 5.11 Ticketscloud: ticketing partnership, not a proven open catalogue

Official materials frame access around ticket/distributor relationships. [S15-S17]

This can be valuable later but does not reduce P0 risk unless the team already has the appropriate agreement and catalogue access.

---

## 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

| Previous conclusion | Final verified conclusion | Delta | Why |
|---|---|---|---|
| KudaGo primary candidate | KudaGo conditional primary; NOT APPROVED | **UNCHANGED AFTER VERIFICATION** | Official docs still support strong schema and open licence, but runtime and legal gates remain. |
| Closed/non-indexable MAX may conflict with indexable-link requirement | Exact clickable source link is clearly required; whether the containing MAX surface itself must be indexable is NOT explicit | **STRENGTH REDUCED** | Previous wording risked implying a legal conclusion stronger than the licence text. Manual owner interpretation remains required. |
| robots.txt /public-api restriction is relevant to indexing | robots.txt is crawler policy only; generic rules disallow /public-api, but a YandexActivity section allows it; it does not decide API-use rights or attribution compliance | **CORRECTED** | Red-team inspection found bot-specific exceptions and separated crawler directives from licence. |
| Timepad is recommended metadata-only fallback after confirmation | Timepad remains the first technical fallback candidate, but no production fallback is approved; current legal text could not be fetched | **LEGAL CONFIDENCE DOWNGRADED** | Official legal endpoint returned 502 during verification; previous content-rights statements could not be reconfirmed. |
| PRO.Культура is a formal but heavy fallback | Standard PRO.Культура path is rejected for emergency P0 more firmly | **STRENGTHENED** | Current partner PDF confirms launched/open resource, region-wide scope, metrics/audits, all-event/place import, returned stats/links and branding obligations. |
| Radario is plausible B2B fallback | Still plausible, but source/deep-link is now an explicit P0 blocker | **NEW MATERIAL GAP** | Reviewed Radario event schema did not establish eventUrl/siteUrl/purchaseUrl, while Povod P0 requires opening the source. |
| KudaGo freshness concerns mostly runtime | No documented updated_at and no documented cancellation flag are explicit evidence gaps | **NEW FINDING** | Current API docs were searched directly for updated_at/cancel terms. |
| KudaGo ads require care | No documented is_ad/erid event field was found; reliable automatic exclusion remains unproven | **STRENGTHENED** | Direct field-absence checks were added. |
| Images should be avoided in P0 | Own visuals/provider-image exclusion remains recommended | **UNCHANGED AFTER VERIFICATION** | KudaGo example includes third-party image source and third-party-right responsibility; Timepad technical image endpoints do not establish reuse rights. |
| Multi-provider architecture future only | Keep only thin ProviderAdapter/provenance boundary; no multi-provider engine P0 | **UNCHANGED AFTER VERIFICATION** | Nothing in final verification justifies expanding frozen P0. |

Full machine-friendly delta is in `DECISION_DELTA.md`.

---

## 7. CONFIRMED FACTS

1. **FACT / CONFIRMED:** KudaGo commercial use is allowed subject to licence restrictions. [S01]
2. **FACT / CONFIRMED:** direct open-for-indexing links to concrete KudaGo source material are required for any use/borrowing/copying. [S01]
3. **FACT / CONFIRMED:** KudaGo licence excludes trademarks and contains special advertising restrictions. [S01]
4. **FACT / CONFIRMED:** KudaGo may change terms without warning and revoke the open licence. [S01]
5. **FACT / VERIFIED BY OFFICIAL DOCS:** API v1.4 is the latest version listed in KudaGo's changelog, dated 2018-02-02. [S01]
6. **FACT / VERIFIED BY OFFICIAL DOCS:** events schema supports occurrence dates, place, category, price/is_free, images and exact KudaGo site URL; page_size max is 100. [S01]
7. **FACT / VERIFIED BY OFFICIAL DOCS:** KudaGo example image may reference a third-party source. [S01]
8. **FACT / VERIFIED BY OFFICIAL DOCS:** searches of the docs page did not find `updated_at`, `cancel`, `is_ad` or `erid`. This is documentation absence, not proof of backend impossibility. [S01]
9. **FACT / VERIFIED BY OFFICIAL DOCS:** Timepad public-event method says authentication is not required; general docs publish 60 responses/IP/min. [S03-S04]
10. **FACT / CONFIRMED:** standard PRO.Культура partnership has substantial eligibility/operational obligations. [S12]
11. **FACT / VERIFIED BY OFFICIAL DOCS:** Radario API 1.1 requires keys and supports event/place/ticket structures; official integration material documents own-site/external-system use. [S13-S14]
12. **FACT / CONFIRMED:** no new provider runtime was executed in this final pass.
13. **FACT / CONFIRMED:** the exact named POVOD source-of-truth files were not available through File Library search in this pass.

---

## 8. RECOMMENDATIONS

See `RECOMMENDATIONS.md`. Core items:

- keep KudaGo as conditional primary;
- close runtime + legal gates rather than rewrite P0;
- own visuals only;
- no provider long-form content/images/history until cleared;
- exact event-level source link;
- fail closed on unresolved ad/content-right cases;
- do not silently fall back to scraping;
- pursue Timepad rights confirmation + Radario source/access confirmation in parallel;
- no multi-provider engine in P0.

---

## 9. REJECTED / DEFERRED OPTIONS

### REJECT P0
- automatic scraping of KudaGo/Timepad/mos.ru/theatre/event pages;
- silent use of undocumented/private mobile endpoints;
- KudaGo provider logo under assumption that open-data licence covers trademarks;
- provider-image hotlink/proxy/cache without confirmed rights;
- preserving historical KudaGo prices “because storage is technically easy”;
- automatic fallback to an unapproved provider.

### DEFER
- PRO.Культура custom partnership;
- Radario full adapter before keys/rights/source URL;
- Ticketscloud ticket-selling integration;
- Moscow Open Data unless a current dataset passes its own gate;
- sports vertical providers;
- multi-provider dedup/precedence/conflict engine.

---

## 10. RISKS

See `RISKS.md`. Highest P0 risks:
- KudaGo MAX/indexability interpretation;
- runtime receipt not closed;
- ad-material identification;
- storage/cache/retention uncertainty;
- stale/cancelled event semantics;
- no approved fallback;
- terms drift.

---

## 11. BLOCKERS

### B1 — KudaGo canonical runtime receipt
**Status:** BLOCKER / NEEDS RUNTIME VERIFICATION.

### B2 — MAX Mini App / attribution interpretation
**Status:** BLOCKER / NEEDS LEGAL VERIFICATION.

### B3 — Advertising-material control
**Status:** BLOCKER if feed can contain advertising and no reliable exclusion/authorization exists.

### B4 — Durable storage/cache if required by implementation
**Status:** BLOCKER for any persistence behavior beyond what provider confirms.

### B5 — No approved fallback
**Status:** architecture/operational blocker only if the project requires provider failover for submission. Frozen P0 does not justify building it automatically.

### Evidence limitation
The named canonical POVOD files were unavailable, so exact contract-diff approval cannot be completed by this research artifact.

---

## 12. OPEN QUESTIONS

See `GAPS_AND_OPEN_QUESTIONS.md`.

Most important:
- what exactly KudaGo means by open-for-indexing link inside MAX;
- whether “site” includes Mini App;
- caching/storage/history/purge;
- ad exclusion;
- cancellation/update;
- rate limits;
- current Timepad content reuse terms;
- Radario source URL/contract scope.

---

## 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`.

Critical rule: the final research does **not** reconstruct the canonical 12 tests because their source file was unavailable. The exact frozen matrix must be run from the canonical project document.

---

## 14. REQUIRED MANUAL / LEGAL CHECKS

See `evidence/LEGAL_QUESTIONS_KUDAGO.md` and `GAPS_AND_OPEN_QUESTIONS.md`.

The goal is a narrow written provider answer, not a general legal essay.

---

## 15. EXACT CHANGES FOR «ПОВОД»

### Change now — project status/evidence, not product scope
1. Keep provider status machine-readably `NOT_APPROVED` until runtime and legal gates pass.
2. Add/retain evidence references for each gate rather than a single boolean.
3. Add `cancellation_signal = UNKNOWN` and `rate_limit = UNKNOWN` if the canonical provider contract supports capability-state fields.
4. Preserve exact `source_url` per event/occurrence output.
5. Disable provider media/long-form content and PriceSnapshot history until rights are resolved.
6. Ensure source-unavailable state exists end-to-end.

### Proposed code boundary
A thin `ProviderAdapter` only:
- list/get provider events;
- normalize into existing event/occurrence contract;
- expose capability/evidence status.
Do not implement cross-provider dedup in P0.

### CONFLICT WITH CURRENT SOURCE OF TRUTH
**None identified from the prompt-level frozen scope.**

**Exact conflict status against named files: UNKNOWN**, because those files were unavailable. If an existing canonical contract explicitly requires durable PriceSnapshot or provider images in P0, this research would conflict with it and the synthesis pass must resolve that explicitly rather than silently changing scope.

---

## 16. IMPACT ON P0 / P1 / STRETCH

### P0
**Keep:**
- Moscow;
- KudaGo conditional primary;
- occurrence truth;
- price/UNKNOWN;
- provenance/source;
- own visuals;
- no social dependency.

**Change in evidence discipline:**
- do not mark provider approved until two gates close;
- record cancellation/rate/ad/storage as capabilities with evidence status.

### P1
- a fallback adapter only after one fallback provider passes rights/access/runtime;
- optional richer content/images only after rights confirmation.

### Stretch
- multi-provider dedup;
- multiple price-source resolution;
- official/ticket-provider precedence;
- sport-specific feeds;
- custom governmental partnership.

---

## 17. WHAT NOT TO DO

- Do not call KudaGo `APPROVED` because the licence says “commercial use”.
- Do not state that MAX definitely violates the indexability clause; the text is ambiguous.
- Do not state that a clickable source link definitely satisfies the clause; provider confirmation is still needed.
- Do not use robots.txt as a substitute for licence analysis.
- Do not infer cache/retention permission from absence of a prohibition.
- Do not infer image rights from image URLs being present.
- Do not infer ad-safety from absence of visible ad text in a sample.
- Do not reconstruct missing canonical runtime cases from memory and call them canonical.
- Do not silently switch to Timepad while its current reuse terms are unverified.
- Do not use PRO.Культура standard API as a quick backup without accepting its actual partner obligations.
- Do not scrape as the “fallback”.
- Do not build a multi-provider architecture merely because future providers exist.

---

## 18. SELF-CRITIQUE / RED TEAM

### Attack 1: “You are being too conservative; open licence already allows derivatives.”
True that derivatives and commercial use are allowed. But the same licence adds direct-link, advertising, trademark, third-party and transfer-benefit restrictions. Storage/cache/MAX semantics are not explicit. The conservative gate is justified because one provider answer can close it cheaply; inventing permission cannot.

### Attack 2: “Indexability obviously means only the target link.”
That is plausible, but not written clearly enough to elevate to FACT. The previous research risked leaning toward this interpretation. Final result deliberately downgrades it to provider-confirmation question.

### Attack 3: “robots.txt proves public-api cannot be indexed.”
False as a blanket claim: bot-specific directives differ, and robots is not licence text. This was corrected.

### Attack 4: “Timepad docs literally show how to build an event list; why not use it?”
The technical intent is strong, but a developer example is not necessarily a complete grant to republish organizer-created text/images in a third-party aggregator. Current legal text was not fetched. Therefore use factual metadata only after rights confirmation.

### Attack 5: “PRO.Культура is government/open data, therefore safest.”
Its **standard partner terms** impose substantial ongoing obligations and resource eligibility. “Government source” does not mean “drop-in open feed”. A custom agreement could change this, so it is deferred, not declared legally impossible.

### Attack 6: “Radario is better because it has a B2B API.”
Potentially, but P0 also needs a visible primary source/deep link. Reviewed schema did not establish one. Credentials and contract scope add lead time.

### Attack 7: “Why not implement all adapters now to reduce risk?”
That increases code paths, dedup/conflict rules and QA while none of the fallbacks is approved. The risk reduction is illusory. Preserve a small adapter boundary; build a second adapter only after rights/access evidence.

### Attack 8: “No images makes UX worse.”
Yes, but the frozen P0 is about reliable occurrence discovery, source and price truth. Owned category visuals preserve UX without introducing third-party media risk.

### Attack 9: “No update timestamp makes KudaGo unusable.”
Not necessarily. Periodic refetch may be sufficient at hackathon scale. But its behavior and cancellation semantics must be measured rather than assumed.

### Attack 10: “This report says FINAL but canonical files were unavailable.”
For that reason the verification status is explicitly **FINAL WITH OPEN BLOCKERS**, not “FINAL VERIFIED RESEARCH”. The archive is final for this research pass and exposes the evidence gap.

---

## 19. MISSING AREAS CHECK

### What might have been forgotten?
- cancellation/reschedule semantics — newly checked and still unresolved;
- update/freshness cursor — newly checked;
- ad-identification field — newly checked;
- bot-specific robots rules — corrected;
- source/deep-link availability for fallback providers — explicitly checked for Radario;
- legal availability of current Timepad terms — rechecked and downgraded;
- exact canonical file availability — explicitly searched.

### Additional areas checked
- Timepad API documentation inconsistency around general token guidance vs public-event exception;
- PRO.Культура per-resource keys and standard operating obligations;
- Radario API version 1.1 and credentials;
- Ticketscloud contractual partner framing.

### Still impossible to close
- KudaGo legal ambiguities without provider/human answer;
- runtime behavior without a live run;
- exact source-of-truth conflict check without canonical files;
- Timepad current reuse terms while the legal endpoint is unavailable;
- current Moscow open-data event feed without dataset-specific evidence.

### Requires runtime
KudaGo canonical 12/12; selected fallback only after legal/access confirmation.

### Requires human/manual
Provider correspondence and decision whether evidence is sufficient to release.

### Requires legal consultation
Only if provider-side clarification is unavailable or ambiguous, especially indexability/monetization/media issues.

### Requires Codex/host
Evidence runner, mapper tests, provider capability states, attribution component and failure handling.

### Closed
Core KudaGo licence obligations; documented API version/fields; standard PRO.Культура partner burden; no justification for multi-provider P0 expansion.

---

## 20. SOURCE MANIFEST

See `SOURCE_MANIFEST.csv` and `SOURCE_MANIFEST.json`.

Primary sources dominate all decision-critical claims. No GitHub/open-source project is part of this provider decision, so the GitHub maintenance checklist is **not applicable** to this research topic.

The only official source that could not be read when needed was the Timepad legal endpoint; that failure is recorded as a gap rather than substituted with an old cached/secondary legal claim.

---

## 21. FINAL CHECKLIST

- [x] major claims entered into claim/evidence matrix;
- [x] time-sensitive provider claims rechecked on 18.09.2026;
- [x] primary/official sources prioritized;
- [x] API versions recorded where published;
- [x] licence/contract surfaces reviewed;
- [x] runtime claims not invented;
- [x] KudaGo remains NOT APPROVED while receipt is open;
- [x] frozen P0 not expanded;
- [x] source-of-truth availability limitation documented;
- [x] delta from previous analysis recorded;
- [x] rejected/deferred options recorded;
- [x] open questions recorded;
- [x] source manifest CSV+JSON generated;
- [x] decision matrix generated;
- [x] machine summary generated;
- [x] CODEX_ACTIONS generated;
- [x] evidence folder generated;
- [x] archive contents validated after ZIP creation;
- [x] no full copyrighted provider documents copied into archive.

**Final research state: FINAL WITH OPEN BLOCKERS.**
