# CODEX_ACTIONS

These are implementation/evidence tasks **after** the project source tree and canonical contracts are available. They do not authorize changing frozen product scope.

## 1. Do not change

- solo-first product flow;
- Moscow as the P0 demo city;
- `Event != Occurrence`;
- honest `UNKNOWN` for missing/conditional price/time/place;
- required provenance/source link;
- visible loading/empty/error/source-unavailable states;
- no mandatory group/social flow;
- no all-Russia claim without a separate data gate;
- no automatic multi-provider implementation in P0.

## 2. Provider contract/config

Locate the canonical equivalent of `POVOD_KUDAGO_PROVIDER_CONTRACT_V1.json`. Do not guess its current structure.

Proposed gate fields to add **only if compatible with the canonical contract**:
- `approval_status`: `NOT_APPROVED | APPROVED`;
- `runtime_gate.status`;
- `legal_gate.max_mini_app`;
- `legal_gate.attribution_indexability`;
- `legal_gate.normalized_storage`;
- `legal_gate.cache`;
- `legal_gate.price_history`;
- `legal_gate.images`;
- `legal_gate.ad_filter`;
- `legal_gate.monetization`;
- `legal_gate.purge_revocation`;
- `rate_limit.status`;
- `cancellation_signal.status`;
- evidence references/hashes and checked_at.

If the canonical contract already has equivalent fields, use them rather than creating duplicates.

## 3. P0 mapper hardening

Ensure mapper can consume only the approved minimal factual subset. Add tests:
- missing `place`;
- missing coordinates;
- empty/missing price;
- `is_free=true` with conditional/deposit-like raw price text must not silently become unconditional zero unless the canonical price policy explicitly permits it;
- `end_date/end_time=null`;
- multiple occurrences;
- exact provider `site_url`;
- malformed/partial provider response;
- provider timeout/5xx.

No descriptions/images should be mapped into P0 display until their legal capability flag is approved.

## 4. Attribution

Implement a single reusable SourceLink component:
- visible provider name;
- exact canonical source URL;
- opens external primary source;
- no provider logo dependency;
- telemetry only if privacy/source-of-truth allows it.

Do not add `nofollow/noindex` behavior or claim legal compliance until KudaGo answers the exact indexability question.

## 5. Storage

Until legal gate passes:
- do not create durable PriceSnapshot history from KudaGo;
- do not add provider image cache;
- do not add description/body archives;
- limit test raw responses to protected evidence artifacts and the canonical evidence-retention policy.

After permission, implement TTL/purge exactly as confirmed, not from this research's proposed examples.

## 6. Runtime evidence runner

Create/reuse the canonical data-gate runner so every case emits:
- run_id;
- case_id from frozen spec;
- request fingerprint;
- timestamp;
- HTTP status;
- SHA-256 of raw response;
- normalized observation;
- expected predicate;
- result;
- evidence path.

The runner must fail the approval gate unless every canonical case passes.

## 7. Fallback spikes

Only after written rights/access confirmation:
- `TimepadProviderAdapter` spike: public events, Moscow filter, source URL, time/place/price mapping, rate handling.
- `RadarioProviderAdapter` spike: v1.1 headers, event/place/ticket joins, canonical public source URL.

Do not merge either adapter into the P0 path while provider status is `NOT_APPROVED`.

## 8. Terms evidence

Persist provider legal evidence outside product source code or in an approved compliance directory:
- source URL;
- fetched/checked date;
- content hash where legally/technically appropriate;
- human approval record;
- provider email/letter reference.

Do not copy entire copyrighted pages into the repository if a URL/hash/excerpt record is sufficient.
