# RUNTIME VERIFICATION REQUIRED

No new provider runtime was executed in this verification pass. Documentation checks do **not** upgrade runtime status.

## A. KudaGo frozen gate — BLOCKER

Execute the **exact frozen matrix already defined by the project** in `POVOD_MOSCOW_DATA_GATE_V1.md` / `MOSCOW_DATA_GATE_RECEIPT.json`. Those files were not retrievable in this research session, so this archive intentionally does not reconstruct or replace the canonical 12-test matrix from memory.

Required receipt for every frozen case:
- exact request URL/parameters;
- UTC timestamp;
- HTTP status;
- response headers needed to diagnose rate/cache behavior;
- raw response bytes or an approved protected raw artifact;
- SHA-256;
- expected condition;
- observed result;
- PASS/FAIL/INCONCLUSIVE;
- test-run ID;
- runtime environment.

**Approval rule:** 12/12 canonical PASS, not “most tests passed”.

### Supplementary checks recommended without changing the frozen matrix

These are additions to evidence, not replacements for the canonical cases:
- unauthenticated `v1.4/events` call from the intended server environment;
- pagination at `page_size=100`;
- Moscow filter and future-window filtering;
- `expand=dates,place` behavior;
- null/missing `end_date`, `end_time`, place, coordinates;
- raw `price` + `is_free` contradictions/conditional-price cases;
- exact `site_url` reachability;
- timeout/5xx/connection failure and Povod `source-unavailable` state;
- 429/fair-use behavior under a safe low-rate probe only;
- whether upstream has any observable cancellation/update signal not documented on the docs page.

Do not load-test a third-party service without permission.

## B. Timepad — only if fallback is still pursued after legal confirmation

- unauthenticated server-side `GET /v1/events` from the intended host;
- city=Москва coverage and occurrence/date semantics;
- direct event `url`;
- coordinates/address nullability;
- ticket price/registration edge cases;
- cancellation/update behavior;
- 429 behavior consistent with documented 60 responses/IP/minute limit;
- source-unavailable handling.

## C. Radario — only after credentials and source-link clarification

- API 1.1 headers and key scope;
- `GET /events`;
- event→place→coordinates join;
- ticket type prices/availability;
- canonical public source/deep link;
- documented/observed cache behavior;
- error/rate behavior.

## Runtime claims forbidden until evidence exists

Do not state:
- KudaGo “works in production”;
- KudaGo “is stable”;
- Moscow coverage is sufficient **today** solely from docs;
- Timepad fallback “works”;
- Radario credentials/scope are available;
- any provider’s exact P95 latency/uptime;
- MAX can open a specific provider deep link end-to-end;
unless corresponding runtime evidence is attached.
