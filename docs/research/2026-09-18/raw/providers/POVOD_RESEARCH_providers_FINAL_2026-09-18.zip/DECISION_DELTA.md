# DECISION DELTA

## 1. KudaGo primary candidate
- **PREVIOUS CONCLUSION:** KudaGo primary candidate
- **FINAL VERIFIED CONCLUSION:** KudaGo conditional primary; NOT APPROVED
- **DELTA:** UNCHANGED AFTER VERIFICATION
- **WHY:** Official docs still support strong schema and open licence, but runtime and legal gates remain.

## 2. Closed/non-indexable MAX may conflict with indexable-link requirement
- **PREVIOUS CONCLUSION:** Closed/non-indexable MAX may conflict with indexable-link requirement
- **FINAL VERIFIED CONCLUSION:** Exact clickable source link is clearly required; whether the containing MAX surface itself must be indexable is NOT explicit
- **DELTA:** STRENGTH REDUCED
- **WHY:** Previous wording risked implying a legal conclusion stronger than the licence text. Manual owner interpretation remains required.

## 3. robots.txt /public-api restriction is relevant to indexing
- **PREVIOUS CONCLUSION:** robots.txt /public-api restriction is relevant to indexing
- **FINAL VERIFIED CONCLUSION:** robots.txt is crawler policy only; generic rules disallow /public-api, but a YandexActivity section allows it; it does not decide API-use rights or attribution compliance
- **DELTA:** CORRECTED
- **WHY:** Red-team inspection found bot-specific exceptions and separated crawler directives from licence.

## 4. Timepad is recommended metadata-only fallback after confirmation
- **PREVIOUS CONCLUSION:** Timepad is recommended metadata-only fallback after confirmation
- **FINAL VERIFIED CONCLUSION:** Timepad remains the first technical fallback candidate, but no production fallback is approved; current legal text could not be fetched
- **DELTA:** LEGAL CONFIDENCE DOWNGRADED
- **WHY:** Official legal endpoint returned 502 during verification; previous content-rights statements could not be reconfirmed.

## 5. PRO.Культура is a formal but heavy fallback
- **PREVIOUS CONCLUSION:** PRO.Культура is a formal but heavy fallback
- **FINAL VERIFIED CONCLUSION:** Standard PRO.Культура path is rejected for emergency P0 more firmly
- **DELTA:** STRENGTHENED
- **WHY:** Current partner PDF confirms launched/open resource, region-wide scope, metrics/audits, all-event/place import, returned stats/links and branding obligations.

## 6. Radario is plausible B2B fallback
- **PREVIOUS CONCLUSION:** Radario is plausible B2B fallback
- **FINAL VERIFIED CONCLUSION:** Still plausible, but source/deep-link is now an explicit P0 blocker
- **DELTA:** NEW MATERIAL GAP
- **WHY:** Reviewed Radario event schema did not establish eventUrl/siteUrl/purchaseUrl, while Povod P0 requires opening the source.

## 7. KudaGo freshness concerns mostly runtime
- **PREVIOUS CONCLUSION:** KudaGo freshness concerns mostly runtime
- **FINAL VERIFIED CONCLUSION:** No documented updated_at and no documented cancellation flag are explicit evidence gaps
- **DELTA:** NEW FINDING
- **WHY:** Current API docs were searched directly for updated_at/cancel terms.

## 8. KudaGo ads require care
- **PREVIOUS CONCLUSION:** KudaGo ads require care
- **FINAL VERIFIED CONCLUSION:** No documented is_ad/erid event field was found; reliable automatic exclusion remains unproven
- **DELTA:** STRENGTHENED
- **WHY:** Direct field-absence checks were added.

## 9. Images should be avoided in P0
- **PREVIOUS CONCLUSION:** Images should be avoided in P0
- **FINAL VERIFIED CONCLUSION:** Own visuals/provider-image exclusion remains recommended
- **DELTA:** UNCHANGED AFTER VERIFICATION
- **WHY:** KudaGo example includes third-party image source and third-party-right responsibility; Timepad technical image endpoints do not establish reuse rights.

## 10. Multi-provider architecture future only
- **PREVIOUS CONCLUSION:** Multi-provider architecture future only
- **FINAL VERIFIED CONCLUSION:** Keep only thin ProviderAdapter/provenance boundary; no multi-provider engine P0
- **DELTA:** UNCHANGED AFTER VERIFICATION
- **WHY:** Nothing in final verification justifies expanding frozen P0.
