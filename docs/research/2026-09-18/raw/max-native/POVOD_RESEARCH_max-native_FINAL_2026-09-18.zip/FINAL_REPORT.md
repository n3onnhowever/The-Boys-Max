# FINAL REPORT — MAX-NATIVE TECHNICAL VERIFICATION

**Project:** «Повод»  
**Team:** The Boys  
**Date:** 18.09.2026  
**Research version:** FINAL-2026-09-18  
**Verification status:** **FINAL WITH OPEN BLOCKERS**  
**Topic slug:** `max-native`

---

# 1. EXECUTIVE SUMMARY

Финальный verification-pass подтверждает основу предыдущего исследования: для «Повода» наиболее нативный и одновременно наименее рискованный способ интеграции с MAX — **Mini App как основной продуктовый интерфейс, серверная валидация MAX identity, server-side product state и Bot API как дополнительный канал возврата**, а не bot-first приложение и не group-first социальная механика.

Замороженный P0 расширять не нужно.

Главный P0 остаётся:

`MAX → validated identity → preferences/conditions → live events → concrete Occurrence → date/time/place → price or UNKNOWN → provenance/source → open source → optional save`.

После повторной проверки четыре вывода изменились или стали существенно точнее:

1. **`open_app.payload` существует в released official TypeScript SDK v0.3.1.** Предыдущий вывод о том, что payload отсутствует в official helper, был ошибочным. Но runtime-семантика payload не доказана.
2. **MAX UI v0.5.0 имеет более жёсткую compatibility reality, чем docs:** release package требует exact React/ReactDOM `19.2.8`, тогда как публичная UI-страница говорит React 18+.
3. **Smart Povod получил новый legal/contract gate.** Technical `POST /messages` не означает автоматическое право отправлять сервисные/массовые сообщения. Official Requirements §1.5 содержит прямое договорное ограничение.
4. **Публичный релиз зависит не только от кода:** eligible verified partner profile, действующий License Agreement, bot moderation и legal/data obligations могут быть реальными schedule blockers.

**VERIFIED BY RUNTIME:** none. В этом research-pass MAX client/host runtime не запускался.

---

# 2. FINAL VERDICT

## Architecture verdict

**KEEP.**

Целевая формула:

**MAX Mini App → server-validated `initData` → Povod backend/domain → personalized feed → exact Occurrence → source**.

MAX bot используется там, где он действительно добавляет MAX-native ценность: возврат пользователя, явная activation flow, P1 notification. Bot не должен дублировать афишу или становиться обязательным входом.

## P0 verdict

**NO PRODUCT-SCOPE EXPANSION.**

Нужны только technical/compliance corrections, если их ещё нет:
- signed identity validation;
- current Bot API domain/cert trust;
- webhook lifecycle;
- safe source opening;
- cross-platform server state;
- frontend dependency compatibility check;
- release/legal readiness check.

## P1 verdict

Follow как серверная сущность безопасен и полезен. Smart Povod message delivery можно включать только после:
- explicit bot activation/lifecycle;
- exact bot→occurrence runtime proof;
- legal/contract permission.

## Stretch verdict

Shared Plan остаётся optional continuation. Наиболее сильный candidate:

`shareMaxContent → startapp opaque invite → recipient validated identity → preview → explicit join`.

Не строить обязательный MAX group.

---

# 3. WHAT WAS VERIFIED

## Official platform

Перепроверены:
- Mini Apps and attachment to bot;
- `start` / `startapp`;
- MAX Bridge;
- identity validation;
- platform differences;
- BackButton/openLink/openMaxLink;
- sharing APIs;
- storage limitations;
- Bot API;
- outbound message endpoint/limits;
- update events;
- webhook lifecycle;
- API changelog;
- platform changelog;
- group-member deprecation;
- partner onboarding and bot moderation;
- MAX Rules/Requirements/privacy templates.

## Official GitHub/source

Перепроверены:
- `max-messenger/max-bot-api-client-ts`;
- v0.3.1 `OpenAppButton` source;
- button actualization commit removing ChatButton;
- `max-messenger/max-ui` v0.5.0 package metadata;
- Go API client and v2.4.0 tag;
- `maxbot` v1.1.0;
- official demo bot and todo example;
- official-org Python fork.

## External OSS

Used only for comparison:
- xTCry/max-io;
- junior2wnw/master-bot;
- maxigo-bot/maxigo-bot;
- alor-broker/max-mini-app.

## Project material

Reviewed available `POVOD_TEST_DECK_V1.pptx` as a **secondary/test artifact**, not source of truth.

## Not verified

The named canonical POVOD source-of-truth files and current The Boys repository were not accessible after repeated File Library/GitHub search. Exact file/code compliance therefore remains open.

---

# 4. CURRENT STATE AS OF 18.09.2026

## Mini App

**FACT / VERIFIED BY OFFICIAL DOCS.** Mini App is attached to a bot and is not an independently managed MAX service. [S01, S12]

**FACT.** `startapp` is the principal Mini App deep-context transport, with max 512 characters and restricted characters. It can open Mini App without first establishing bot dialogue. [S01, S11]

**INFERENCE.** A user can therefore complete P0 without ever becoming a bot-notification recipient. This matters for Smart Povod enrollment.

## Bridge

**FACT.** `initData` is raw signed launch data; `initDataUnsafe` cannot be used as identity validation authority. [S02, S03]

**FACT.** Platform values include `ios`, `android`, `desktop`, `web`. [S02]

**FACT.** `version` is not part of identity signature. [S02]

**FACT.** DeviceStorage/SecureStorage are not available in Web; SecureStorage has a small key limit. [S02]

**RECOMMENDATION.** Core user state stays server-side.

## Bot API

**FACT.** Requests must use `platform-api2.max.ru`; current certificate trust change is part of the critical API changelog. [S05, S07]

**FACT.** Global rate and per-dialog send limits are documented and are far above likely hackathon traffic when used carefully. [S07, S10]

**FACT.** Production delivery should be webhook-first. [S08, S10]

## SDK/source state

### TypeScript client

Official release baseline: `@maxhub/max-bot-api` v0.3.1, MIT, active repository. [S22]

**CRITICAL SOURCE FACT:** released source includes optional `payload` on `OpenAppButton` and corresponding helper argument. [S23]

### MAX UI

Official v0.5.0 release is recent. [S25]

Public docs describe React 18+, but v0.5.0 package has exact peer dependencies:
- React 19.2.8;
- ReactDOM 19.2.8.

Therefore “MAX UI works with our frontend” is not a fact until current Povod package versions are checked.

### Go

Official client is active; tag `v2.4.0` exists even though GitHub `releases/latest` returned older `v2.3.5`. Official `maxbot v1.1.0` depends on client v2.4.0. [S26, S27]

This shows why release objects and language module tags must be tracked separately.

---

# 5. KEY FINDINGS

## 5.1 Identity is the critical MAX primitive for P0

Correct boundary:

`raw initData → backend validation → signed user.id → local Povod user`.

Not acceptable as authority:
- `initDataUnsafe`;
- JSON body `user_id`;
- URL query `plan_id`;
- unvalidated `start_param`;
- frontend role/ownership state.

Profile data must be treated as nullable/changeable metadata, not identity key.

## 5.2 Own session is a design option, not MAX requirement

Previous wording was too strong.

Two defensible P0 implementations:

**A. validate once → short-lived server session**
- clean backend authorization;
- avoids shipping raw launch data every request;
- requires cookie/session runtime proof.

**B. validate signed initData on sensitive calls**
- stateless;
- simpler if embedded cookie persistence is problematic;
- repeated validation and freshness management.

No hackathon need for a refresh-token ecosystem.

## 5.3 `open_app.payload` is source-confirmed, runtime-unconfirmed

The existence of the field is now **VERIFIED BY SOURCE CODE** at v0.3.1.

Still unknown:
- exact mapping into Mini App launch context;
- behavior on every target client;
- interaction with `web_app` and existing open instance;
- fallback UX on Web.

This should be one of the first spikes, not a feature built on faith.

## 5.4 ChatButton/start_payload is stale direction

Current public button list excludes ChatButton, and official SDK source explicitly removed it in August 2026. An old repo markdown section remains stale.

Conclusion: current API docs + current released types win over stale README/docs sections.

## 5.5 MAX UI is not required for MAX-native behavior

The most valuable native behaviors are:
1. trusted MAX identity;
2. correct BackButton/navigation;
3. platform-safe viewport/layout;
4. source links;
5. MAX internal transitions/share;
6. theme/polish.

If adding MAX UI forces React migration, the library decreases P0 reliability. Existing UI + Bridge + MAX visual guidelines is a legitimate MAX-native implementation.

## 5.6 Smart Povod is a contractual feature, not just a Bot API call

Official Requirements §1.5 means engineering alone cannot clear outbound notification behavior.

Explicit opt-in/follow remains a strong UX/privacy design, but it is **not sufficient evidence of contractual permission**.

## 5.7 Shared Plan belongs to Povod domain, MAX supplies transport

Povod owns:
- plan;
- occurrence binding;
- membership;
- invite token;
- authorization.

MAX supplies:
- identity;
- native share UI;
- deep link/open transition.

This removes dependency on soon-removed group member management.

---

# 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

Detailed delta: `DECISION_DELTA.md`.

Material changes:
- `open_app.payload` corrected from weak/negative source claim to source-confirmed;
- MAX UI downgraded from default recommendation to compatibility-conditional;
- session model downgraded from “needed” to architecture proposal;
- Smart Povod got a legal gate;
- public release readiness got partner/moderation/license gates;
- ChatButton rejection strengthened by current source diff;
- Go version reporting now separates tags from GitHub Release objects.

Unchanged:
- Mini App primary;
- bot retention;
- raw signed identity validation;
- opaque context tokens;
- no group-first;
- server state;
- webhook production;
- platform-api2;
- runtime spike requirement.

---

# 7. CONFIRMED FACTS

## Identity
- `initData` is signed launch authority. [S02, S03]
- `initDataUnsafe` is not validation authority. [S02]
- validation algorithm is documented. [S03]
- profile fields require defensive schema handling. [S03]

## Deep links
- bot `start`: up to 128 chars. [S10, S11]
- Mini App `startapp`: up to 512 chars. [S01, S11]
- `:share`: iOS/Android/Web; Desktop not equivalent/currently developing. [S11]

## Sharing
- `shareMaxContent` exists. [S02]
- `shareContent` is not Web-universal. [S02]

## Bot/webhook
- outbound message endpoint exists. [S07]
- lifecycle updates exist. [S09]
- webhook has explicit TLS/timing/retry rules. [S08]

## Breaking changes
- current domain = platform-api2. [S05]
- `GET /chats` removed. [S05]
- group member add removal scheduled 30.09.2026. [S15]

## Legal/release
- partner eligibility is restricted to documented RF-resident business/self-employed profiles. [S16, S17]
- bot moderation can take up to 48 working hours. [S16]
- public placement requires a valid License Agreement. [S18]
- required legal information/data obligations exist. [S18, S19]
- account/data deletion requirement exists for the documented MAX-account-derived-data scenario. [S18]
- message-category restriction exists. [S19]

---

# 8. RECOMMENDATIONS

## P0

**RECOMMENDATION:** keep a thin MAX integration boundary.

Frontend adapter owns Bridge calls; backend integration owns Bot API/webhook/auth. Event/search/occurrence domain remains platform-neutral.

**RECOMMENDATION:** validate `initData` server-side and make signed `user.id` the only MAX identity key.

**RECOMMENDATION:** keep state server-side because Web cannot depend on SecureStorage/DeviceStorage.

**RECOMMENDATION:** use current API domain and verify trust from the real host/container.

**RECOMMENDATION:** choose session after runtime, not before.

**RECOMMENDATION:** use MAX UI only if it is already compatible or cheap to adopt. Do not migrate framework for cosmetic native value.

**RECOMMENDATION:** clear partner/license/moderation gate now.

## P1 — Smart Povod

- Follow server-side.
- Explicit activation through bot `start` token.
- Bind on `bot_started`.
- Maintain bot lifecycle state.
- Deduplicate notifications.
- Spike `open_app.payload`.
- Obtain agreement/legal permission before real notification use.

## Stretch — Shared Plan

- server-side SharedPlan;
- random opaque invite;
- internal share + startapp;
- recipient validates itself;
- explicit join;
- no group member-add dependency.

---

# 9. REJECTED / DEFERRED OPTIONS

## REJECTED
- group-first architecture;
- automatic MAX group member management;
- ChatButton/start_payload dependency;
- trusting `initDataUnsafe`;
- raw `plan_id` as authorization;
- DeviceStorage/SecureStorage as primary account state;
- long polling in production;
- forced React migration solely for MAX UI;
- copying unlicensed external Mini App code;
- declaring Smart Povod legal because API technically allows sending.

## DEFER
- Shared Plan until core stable;
- haptics/biometrics/NFC/device-only polish;
- elaborate distributed queue/rate infrastructure;
- extra third-party MAX frameworks without concrete gap;
- generalized `start_context` service until P1/Stretch actually needs it.

---

# 10. RISKS

See `RISKS.md`.

Top risks by project impact:
1. release account/license/moderation state unknown;
2. Smart Povod legal permission unknown;
3. no client runtime evidence;
4. current project source inaccessible;
5. MAX UI compatibility risk;
6. docs/source drift;
7. webhook/certificate host-level assumptions.

---

# 11. BLOCKERS

## BLOCKER B1 — release readiness UNKNOWN

Until manually cleared:
- eligible verified partner profile;
- active License Agreement;
- bot publication/moderation;
- token availability.

This can block public/demo placement independently of code quality.

## BLOCKER B2 — canonical files/repo unavailable

Blocks exact source-level signoff. Does not invalidate official MAX capability findings.

## BLOCKER B3 — Smart Povod legal gate

Blocks P1 message sending, not solo P0.

## BLOCKER B4 — runtime evidence missing

If judging claims include “works in MAX mobile and web”, required matrix must be executed.

---

# 12. OPEN QUESTIONS

See `GAPS_AND_OPEN_QUESTIONS.md`.

No inference should close:
- `open_app.payload` client mapping;
- `shareMaxContent` Web/Desktop;
- first proactive message to Mini-App-only user;
- embedded cookie lifecycle;
- actual signed agreement permission;
- current repo implementation.

---

# 13. REQUIRED RUNTIME TESTS

See `RUNTIME_VERIFICATION_REQUIRED.md`.

Minimum P0:
- identity positive/negative;
- startapp exact occurrence;
- session strategy;
- BackButton/source navigation;
- webhook/TLS/platform-api2.

Social/Smart probes remain outside P0 if features remain deferred.

---

# 14. REQUIRED MANUAL / LEGAL CHECKS

1. Partner account type and verification.
2. License Agreement presence/current version.
3. Bot moderation/publication.
4. Token availability.
5. Privacy/Terms/operator/support disclosure.
6. User account/data deletion mechanism.
7. Smart Povod message category permission.
8. Any MAX branding rights beyond platform-provided usage.
9. Final Rules/Requirements recheck immediately before public release.

---

# 15. EXACT CHANGES FOR «ПОВОД»

These are conditional code deltas to verify, not claims that current files are wrong.

## Authentication
- one raw-initData backend validator;
- no identity from `initDataUnsafe`;
- nullable profile schema;
- auth_date policy;
- negative tests.

## Client integration
- one Bridge adapter;
- BackButton wired to router;
- `openLink` for source;
- feature-detected share fallbacks.

## Backend MAX
- current base URL;
- header auth;
- webhook secret;
- idempotency;
- lifecycle handling.

## UI
- inspect React version before MAX UI;
- preserve current component stack if incompatible.

## Context routing
P0 should not get a generalized token subsystem unless external exact-context routing already needs it. Add token registry only when Smart/Shared is implemented.

## Compliance
Minimal legal/data deletion surface if absent. Do not create a large settings feature.

## Presentation
Correct stale test-deck roadmap rather than widening source-of-truth P0.

---

# 16. IMPACT ON P0 / P1 / STRETCH

## P0

KEEP:
- identity;
- preferences;
- live feed;
- occurrence;
- source;
- save;
- mobile/Web target.

TECHNICAL CORRECTIONS ONLY:
- endpoint/cert;
- validation;
- webhook;
- dependency gate;
- release/legal readiness.

NO NEW SOCIAL FEATURE.

## P1

- Follow remains reasonable.
- Smart Povod = technical + runtime + legal gates.
- Notification only after explicit activation and permission check.

## Stretch

- Shared Plan/invite;
- internal MAX share;
- optional extra native polish.

---

# 17. WHAT NOT TO DO

- Do not make bot the whole UX.
- Do not trust client identity.
- Do not store core account state only on device.
- Do not use old `platform-api.max.ru`.
- Do not depend on removed `GET /chats`.
- Do not build group member add.
- Do not trust stale Chat docs.
- Do not force MAX UI.
- Do not copy external code without licence.
- Do not claim Smart Povod is contractually cleared.
- Do not claim cross-platform support without runtime.
- Do not turn compliance into a large product-scope expansion.

---

# 18. SELF-CRITIQUE / RED TEAM

## What if Mini App + bot retention is wrong?

If contractual messaging restrictions make Smart Povod unusable, Mini App-only P0 still stands. Therefore bot retention is an enhancement, not structural dependency. This makes the architecture resilient to this risk.

## What if own session is overengineering?

It can be. The final recommendation explicitly keeps signed-initData revalidation as a simpler fallback.

## What if MAX UI is the fastest path to native UI?

Only if current project is already compatible. If it requires React migration, the hidden cost exceeds P0 benefit.

## What if shareMaxContent is not universal?

Then `:share`/copy fallback remains. Social is not P0, so failure does not threaten core.

## What if open_app payload does not behave as expected?

Use documented `startapp` path. The P1 design should never depend on undocumented runtime without spike.

## What if official examples are good enough evidence?

They are not. Todo uses an older client; official repo markdown itself can lag current types. Examples teach patterns, not runtime truth.

## What if sophisticated rate/queue architecture is needed?

At hackathon scale, 30 rps is unlikely to justify distributed infrastructure. A small outbox/limiter is enough only when Smart notifications are actually enabled.

## What if opaque token registry is overengineering?

For base P0 it may be. Defer it until external deep context is needed. For Shared Plan/Smart, capability tokens materially reduce IDOR/tampering risk.

## What if legal checks are not part of technical scope?

They directly affect whether technical flows can be deployed. The correct response is to add gates, not to redesign P0.

---

# 19. MISSING AREAS CHECK

## Additionally checked in final pass

- legal placement requirements;
- message-category restrictions;
- data deletion obligations;
- moderation schedule;
- platform changelog;
- released SDK source vs docs;
- MAX UI peer dependencies;
- repository licence-file presence;
- Python client freshness;
- Go release/tag mismatch;
- stale project presentation scope.

## Still impossible to close

- actual signed License Agreement;
- actual team MAX partner state;
- actual current source code;
- exact canonical file contents;
- client runtime;
- deployment certificate trust;
- real dependency tree.

## Requires runtime

See runtime file.

## Requires human/manual

- partner/moderation/token status;
- Desktop acceptance scope;
- choosing session fallback based on runtime.

## Requires legal

- Smart Povod messaging permission;
- project-specific privacy/data basis;
- source vendoring if any licence ambiguity.

## Requires Codex/host

- exact file changes;
- tests;
- client/host probes;
- deployment evidence.

## Closed enough

- identity validation model;
- start/startapp distinction;
- API host;
- webhook constraints;
- group member removal;
- TS `open_app.payload` source presence;
- ChatButton removal direction;
- Web storage limits;
- social remains optional.

---

# 20. SOURCE MANIFEST

See `SOURCE_MANIFEST.csv` and `SOURCE_MANIFEST.json`.

Source hierarchy:
1. official MAX docs/changelogs/terms;
2. official MAX GitHub source/releases/tags;
3. project material;
4. external OSS for comparison only.

No major recommendation is based only on blogs, SEO, Reddit or unverified README claims.

---

# 21. FINAL CHECKLIST

- [x] Major claims have evidence/status.
- [x] Time-sensitive claims rechecked on 18.09.2026.
- [x] Official sources prioritized.
- [x] API breaking changes checked.
- [x] GitHub releases/tags/source checked.
- [x] Licence metadata checked.
- [x] Runtime claims separated.
- [x] No runtime run is invented.
- [x] P0 not expanded by social research.
- [x] Conflicts/potential conflicts surfaced.
- [x] Recommendations actionable.
- [x] Rejected/deferred options recorded.
- [x] Open questions recorded.
- [x] Source manifest generated.
- [x] Decision delta generated.
- [x] Machine summary generated.
- [x] Codex handoff generated.
- [x] Runtime spike specified.
- [x] Legal/manual gates specified.
- [ ] Canonical POVOD source files line-reviewed — **BLOCKED: unavailable**.
- [ ] The Boys repository source-reviewed — **BLOCKED: unavailable**.
- [ ] MAX client runtime completed — **NOT RUN**.

## CONFLICT WITH CURRENT SOURCE OF TRUTH

### Verified conflict in project material, not canonical source files

The available test deck roadmap puts 2–3 cities, map, basic subscriptions and invite into hackathon MVP. The canonical context supplied by the user freezes a narrower solo-first P0.

**Criticality:** HIGH for communication/scope drift; lower for code if deck is draft.  
**Recommendation:** change the deck, not P0.  
**Can defer?** Before final presentation: no.

### Potential compliance conflict

If current canonical P0 documents omit a minimum legal information/data deletion path, MAX Rules may require one for public placement because Povod derives local identity/data from MAX account information.

**Criticality:** HIGH for public placement.  
**Recommendation:** implement only the smallest compliant path if absent.  
**Can defer?** Only if public MAX placement is not occurring before the check.

### No other verified source-of-truth conflict

Because the canonical files were unavailable, this report does not silently amend them.
