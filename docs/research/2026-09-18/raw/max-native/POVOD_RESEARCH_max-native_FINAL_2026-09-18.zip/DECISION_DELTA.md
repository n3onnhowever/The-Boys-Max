# DECISION DELTA — PREVIOUS vs FINAL VERIFIED

## D01 — `open_app` exact context

**PREVIOUS CONCLUSION:** official TS helper was treated as not exposing payload; exact occurrence via `open_app` had weak API evidence.

**FINAL VERIFIED CONCLUSION:** released official `@maxhub/max-bot-api` source at **v0.3.1** includes `OpenAppButton.payload?: string | null` and `openApp(..., payload?)`.

**STATUS:** VERIFIED BY SOURCE CODE for field/helper existence; **NEEDS RUNTIME VERIFICATION** for client semantics.

**IMPACT:** Smart Povod exact-return path is stronger than previously thought, but cannot be called end-to-end working without target-client execution.

## D02 — ChatButton / `start_payload`

**PREVIOUS CONCLUSION:** not in current public button list; do not rely on it.

**FINAL:** strengthened. Official SDK commit `28f92face...` dated 27.08.2026 removed `ChatButton` and its `start_payload` helper. Repo markdown still mentions Chat and is stale.

**STATUS:** REJECTED for new architecture.

## D03 — MAX UI adoption

**PREVIOUS:** use MAX UI as base UI library.

**FINAL:** conditional. Public docs say React 18+, while `@maxhub/max-ui@0.5.0` release package declares exact peer deps React/ReactDOM `19.2.8`.

**IMPACT:** do not upgrade React only to gain MAX UI before hackathon. Bridge + current/custom components is a safe fallback.

## D04 — MAX UI licence confidence

**PREVIOUS:** MIT.

**FINAL:** package.json declares MIT, but repository tree did not expose standalone LICENSE file.

**IMPACT:** dependency use is plausible; do not vendor/copy source without licence hygiene check.

## D05 — own session

**PREVIOUS:** separate server session was presented as effectively required.

**FINAL:** MAX requires launch validation, not a particular app-session model.

**STATUS:** PROPOSED, not platform fact.

**ACTION:** prefer short-lived HttpOnly session only if runtime works; fallback to revalidating signed initData on sensitive calls. No refresh-token system for hackathon.

## D06 — Smart Povod notifications

**PREVIOUS:** primarily technical flow: activation → bot message → exact occurrence.

**FINAL:** technical flow remains plausible but has a new **NEEDS LEGAL VERIFICATION** gate. Requirements §1.5 restrict API/integration use for service and other mass-message categories except contractually permitted cases.

**IMPACT:** blocker for P1 messaging, not solo P0.

## D07 — public release readiness

**PREVIOUS:** mostly technical integration gates.

**FINAL:** added mandatory operational/legal checks: eligible verified partner profile, License Agreement, bot moderation (up to 48 working hours), legal info and account/data deletion where applicable.

## D08 — group-based social flow

**UNCHANGED AFTER VERIFICATION.** Bot-managed group member adding remains a dead-end because the endpoint is scheduled for removal on 30.09.2026.

## D09 — `shareMaxContent` + `startapp`

**UNCHANGED AFTER VERIFICATION**, with tighter wording: method existence is documented; complete Web/Desktop runtime support is not proven.

## D10 — server-side MAX identity

**UNCHANGED AFTER VERIFICATION.** Raw `initData` must be validated server-side; `initDataUnsafe` is not authentication authority. Added nuance: nullable profile fields must be tolerated.

## D11 — API endpoint/webhook

**UNCHANGED AFTER VERIFICATION.** `platform-api2.max.ru`, current certificate trust, webhook production.

## D12 — source-of-truth coverage

**FINAL:** limitation persists after repeated search. Named canonical files and The Boys repo were not accessible. Exact repo/source diff is delegated to Codex/host.
