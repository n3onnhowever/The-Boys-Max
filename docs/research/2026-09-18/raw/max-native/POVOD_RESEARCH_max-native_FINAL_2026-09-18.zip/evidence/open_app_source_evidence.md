# Official TS SDK source evidence — `open_app.payload`

Checked at official repository `max-messenger/max-bot-api-client-ts`, release tag `v0.3.1`.

Observed source model:
- `OpenAppButton` includes optional `payload`;
- helper `openApp(...)` accepts optional `payload` and places it into the returned button object.

This evidence is summarized rather than copying full source.

**Proves:** released official TypeScript SDK models/sends a payload field for `open_app`.

**Does NOT prove:** how every current MAX client maps payload into Mini App launch context, whether it equals `start_param`, or identical behavior on Android/iOS/Web/Desktop.

Status: **VERIFIED BY SOURCE CODE / NEEDS RUNTIME VERIFICATION**.
