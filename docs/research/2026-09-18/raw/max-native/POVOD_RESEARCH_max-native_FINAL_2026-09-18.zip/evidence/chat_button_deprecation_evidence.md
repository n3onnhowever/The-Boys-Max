# ChatButton/source drift evidence

Official TS SDK commit:
`28f92face3e74b93e2aa2ee89f1ebb5ad4131531`
Date: 2026-08-27
Message: `Buttons actualization`

Observed change:
- `ChatButton` type removed;
- chat helper removed;
- current direction adds/retains supported message/clipboard/open-app button forms.

At check time, repository markdown `docs/04-keyboard.md` still contained a Chat section.

Conclusion: current public API docs + released/current type source win over stale repository markdown. `ChatButton/start_payload` is **REJECTED** for new Povod architecture.
