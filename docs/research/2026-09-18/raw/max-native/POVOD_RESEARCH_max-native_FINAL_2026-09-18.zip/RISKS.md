# RISKS

## P0

### Release account/moderation not ready — HIGH
Status unknown. Partner eligibility, verified profile, License Agreement, bot publication/token were not available to this research. Official moderation can take up to 48 working hours.

### Canonical files/repo unavailable — HIGH for audit completeness
Cannot prove current implementation matches the research. Codex source diff required.

### MAX UI induces React migration — MEDIUM-HIGH
v0.5.0 exact React 19.2.8 peers can turn styling into framework migration.

## Technical

- Docs/source drift: official SDK source and markdown already disagree about button set.
- API churn: domain changed, GET /chats removed, group-member endpoint scheduled for removal.
- Web differs from mobile: storage/system-share/biometric capabilities.
- Session transport assumptions may fail in embedded clients.

## Security

- Client identity/context trust → impersonation/IDOR.
- Long-lived context tokens → replay/forwarding.
- Webhook spoof/duplicates → repeated side effects.
- Bot token leakage → full integration compromise.

## Legal/compliance

### Smart Povod messaging permission — HIGH for P1
Requirements §1.5 imposes contractual restrictions on outbound message categories.

### Missing legal disclosure/privacy/delete path — HIGH for public placement
Rules require legal/data obligations; exact project implementation unknown.

### MAX UI source licence hygiene — MEDIUM if vendoring
package.json declares MIT; no standalone LICENSE detected.

### External unlicensed code — HIGH if copied
`alor-broker/max-mini-app` had no detected repository licence.

## UX

- Treating “MAX-native” as “use every MAX API” adds gimmicks and fragility.
- Group-first drift can consume demo time and contradict solo-first.

## Operational

- Webhook can be auto-unsubscribed after extended delivery failure.
- Deployment container may have certificate trust mismatch.
- MAX legal/platform terms can change; final recheck is necessary.
