# EXECUTIVE VERDICT

**Status: FINAL WITH OPEN BLOCKERS — 18.09.2026**

## Verdict

Архитектуру P0 менять не нужно.

Наиболее надёжная MAX-native форма «Повода»:

**Mini App → validated `initData` → Povod backend → personal feed → exact Occurrence → source**.

Bot остаётся отдельным каналом возврата и P1-retention. Social flow остаётся optional continuation.

## Keep

- solo-first P0;
- Mini App как главный UI;
- server-side validation raw `initData`;
- server-side product state;
- Bridge wrapper для BackButton/openLink/openMaxLink/share/platform;
- `startapp` как transport short opaque context token;
- webhook-first production;
- explicit source CTA.

## Change / correct

- `open_app.payload`: source-confirmed in official TS SDK v0.3.1, runtime still required.
- MAX UI: conditional only after current React compatibility check.
- own session: architecture choice, not MAX requirement.
- Smart Povod: `NEEDS LEGAL VERIFICATION` before real notification sending.
- ChatButton/start_payload: reject as stale/removed direction.

## Main blockers

1. Manual release readiness: eligible verified partner profile, active License Agreement, bot moderation/token.
2. Smart Povod legal permission under actual agreement.
3. Runtime: `open_app.payload`, `shareMaxContent` Web/Desktop, session cookies, exact navigation.
4. Canonical POVOD files and current repo unavailable to this research runtime.

## Next action

Run one bounded MAX spike on Android + iOS + Web and parallel release/legal checklist. Do not widen functional P0.
