# GAPS AND OPEN QUESTIONS

## Runtime

1. Does `open_app.payload` become the expected exact Mini App context on current Android, iOS and MAX Web?
2. Does `shareMaxContent({text, link})` work on MAX Web/Desktop?
3. Does bot `link` → `https://max.ru/<bot>?startapp=...` stay native or introduce a new-tab/browser round trip?
4. Can proactive `POST /messages?user_id=` work for a user who only launched Mini App and never generated `bot_started`? Do not rely on it.
5. Do same-origin HttpOnly Secure cookies persist reliably in MAX mobile WebViews and MAX Web?
6. Exact BackButton/router/viewport behavior in current Povod implementation.
7. Does deployment runtime trust the certificate chain for `platform-api2.max.ru`?
8. Does webhook subscription persist/restore correctly after deploy failures?

## Legal/manual

1. Does the operator already have an eligible verified MAX partner profile?
2. Is the current License Agreement in force?
3. Is the bot already `Опубликован` and is the token available?
4. Does the actual agreement permit the Smart Povod message category?
5. Are Privacy Policy, terms/operator/support information already present?
6. Is there a free user-request path to delete local Povod account/data?

## Repository/source of truth

Unknown until Codex/host inspection:
- current React version;
- MAX UI installed or not;
- existing Bridge wrapper;
- auth/session implementation;
- Bot API base URL;
- webhook implementation;
- deep-link/token model;
- legal routes/screens;
- current P0 flags and social/Smart code.

## Closed enough

- startapp/start limits;
- server validation algorithm;
- `initDataUnsafe` not auth;
- platform values and Web storage limitations;
- current API base;
- webhook lifecycle;
- ChatButton removal direction;
- official TS `open_app.payload` source existence;
- group-member API removal;
- partner eligibility/moderation rules;
- contractual message restriction existence;
- account/data deletion requirement existence.
