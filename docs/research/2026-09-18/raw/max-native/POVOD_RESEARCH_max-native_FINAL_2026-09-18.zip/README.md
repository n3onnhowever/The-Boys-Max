# POVOD Research Archive — MAX-native integration

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** MAX-native architecture, identity, Mini Apps, Bot API, sharing, Smart Povod, Shared Plan, retention  
**Research version:** FINAL-2026-09-18  
**Previous result:** deep MAX-native technical analysis in the same research chat, 18.09.2026  
**Verification status:** **FINAL WITH OPEN BLOCKERS**

## Главный вывод

Замороженный solo-first P0 расширять не нужно. Целевая форма остаётся:

**MAX Mini App → server-validated MAX identity → Povod backend/domain → Occurrence → source**.

Bot — канал возврата/retention, а не основной интерфейс. Shared Plan — optional continuation.

После verification четыре существенные корректировки:

1. `open_app.payload` действительно есть в released official TypeScript SDK v0.3.1; runtime-семантику всё равно надо проверить.
2. `@maxhub/max-ui@0.5.0` нельзя навязывать без compatibility check: release package требует exact React/ReactDOM `19.2.8`, хотя публичная UI docs говорит более широко о React 18+.
3. Smart Povod — не только technical, но и legal/contract gate: MAX Requirements §1.5 ограничивают категории исходящих сообщений через API, кроме случаев, прямо разрешённых договором.
4. Публичное размещение зависит от partner profile, License Agreement, bot moderation и минимальных legal/data obligations.

## Ограничение verification

Названные канонические файлы `POVOD_FINAL_SCOPE_FREEZE_MVP.md`, `POVOD_PRODUCT_SPEC_V1.md`, `POVOD_PRODUCT_SPEC_V1_1_DATA_SAFETY_PATCH.md`, `POVOD_PRODUCT_CONTRACT_V1.json`, `POVOD_UI_TRANSLATION_V2_SPEC.md` не были найдены доступным File Library поиском; The Boys repo также не был доступен через подключённый GitHub. Поэтому exact code/file diff вынесен в `CODEX_ACTIONS.md`.

Доступный `POVOD_TEST_DECK_V1.pptx` использован только как вторичный project material и не переопределяет frozen P0.

## Что внутри

- `FINAL_REPORT.md` — полный отчёт.
- `EXECUTIVE_VERDICT.md` — краткое решение.
- `FACT_CHECK_MATRIX.csv`, `CLAIMS_EVIDENCE.csv` — claim → evidence.
- `SOURCE_MANIFEST.csv/json` — все реально использованные источники.
- `DECISION_MATRIX.csv` — варианты без искусственного ranking.
- `DECISION_DELTA.md` — изменения к предыдущему анализу.
- `GAPS_AND_OPEN_QUESTIONS.md` — пробелы.
- `RECOMMENDATIONS.md` — actionable actions.
- `RISKS.md` — risks.
- `RUNTIME_VERIFICATION_REQUIRED.md` — bounded runtime spike.
- `CODEX_ACTIONS.md` — handoff для repo/host.
- `machine_summary.json` — synthesis input.
- `evidence/` — компактные supporting snapshots.
