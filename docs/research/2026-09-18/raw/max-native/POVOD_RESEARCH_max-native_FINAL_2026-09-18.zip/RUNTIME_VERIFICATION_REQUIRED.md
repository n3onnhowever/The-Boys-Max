# RUNTIME VERIFICATION REQUIRED

**Research runtime status:** no MAX client runtime was executed during this pass. Nothing here is `VERIFIED BY RUNTIME`.

## Minimal client matrix

- Android — current MAX client.
- iOS — current MAX client.
- MAX Web — current production client.
- Desktop — only if actual acceptance requires it.

## R1 — identity

- valid raw `initData` → backend PASS;
- tampered `user.id` → reject;
- tampered `start_param` → reject;
- duplicate `hash`/other param → reject;
- bad hash → reject;
- stale `auth_date` → reject per policy;
- null username/photo → no crash;
- local identity only from signed user id.

Save sanitized tests/logs, never token/initData secrets.

## R2 — startapp exact occurrence

Open `https://max.ru/<bot>?startapp=o_<opaque>`.
Verify exact occurrence, expiry/revocation fallback, and user-bound token denial from a second account.

## R3 — session strategy

If using cookie session: test HttpOnly Secure same-origin session across Android/iOS/Web and reload/navigation/API calls.

If unreliable: prove the smallest fallback by revalidating signed launch data. Do not build refresh tokens first.

## R4 — native navigation

- BackButton route behavior;
- root hide/nested show;
- `openLink(source)` from explicit user click;
- `openMaxLink(?start=...)` bot activation.

## R5 — Shared Plan (Stretch)

Account A: create plan → `p_` invite → `shareMaxContent`.
Account B: own identity validation → preview → explicit Join → same plan.
Also test `:share`/copy fallback and IDOR/expiry/revocation.

## R6 — `open_app.payload`

Send one bot message with an `open_app` button carrying opaque occurrence token. Verify exact context on each required client. If it fails, use startapp deep-link fallback.

## R7 — Smart Povod (only after legal gate)

`?start=sp_<token>` → `bot_started` → bind dialog → one test message → CTA exact occurrence → stop/remove lifecycle disables push state.

No broad notification test before legal permission is cleared.

## R8 — webhook

- HTTPS/443 + full chain;
- secret header validation;
- invalid secret rejected;
- valid event idempotent;
- duplicate event no duplicate domain effect;
- response well below 30s;
- subscription present after deploy/restart.

## R9 — API host/TLS

From actual host/container, prove TLS + harmless authenticated API call to `platform-api2.max.ru`; scan config/code for legacy host.

## Exit

P0 can ship without R5–R7 if social/Smart are not P0. P0 should not claim MAX mobile/Web compatibility until R1–R4 and R8–R9 pass on the actual required matrix.
