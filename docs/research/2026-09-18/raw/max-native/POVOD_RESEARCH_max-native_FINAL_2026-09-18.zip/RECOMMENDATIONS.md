# RECOMMENDATIONS — actionable only

## P0 — do now

1. Keep frozen solo-first flow. No mandatory bot dialogue/group before personal event value.
2. Verify one auth boundary: frontend sends raw `initData`; backend validates HMAC/freshness and derives signed `user.id`.
3. Hide MAX-specific client calls behind a thin Bridge adapter.
4. Decide session only after runtime: short-lived HttpOnly session if reliable; otherwise signed-initData revalidation. No refresh-token infrastructure for hackathon.
5. Keep interests/saves/follows state server-side.
6. Use `platform-api2.max.ru`; verify host/container trust, not only browser.
7. Webhook-first production with secret, idempotency and subscription health.
8. Do not force MAX UI: inspect current React first. If incompatible, keep current UI and use Bridge/MAX visual guidance.
9. Check release readiness now: partner profile, License Agreement, bot moderation/token.
10. Fix stale presentation scope; do not change source-of-truth P0 to match draft slides.

## P1 — after P0 stable

### Smart Povod
- server-side Follow;
- explicit bot activation via `?start=sp_<opaque>`;
- bind on `bot_started`;
- outbox/dedupe only if actually needed;
- spike `open_app.payload` exact return;
- disable push capability on `bot_stopped`/`dialog_removed`;
- do not enable real notification campaign until legal/contract permission is confirmed.

## Stretch — Shared Plan

- backend SharedPlan;
- >=128-bit opaque `p_` token, hash at rest;
- `shareMaxContent` + `startapp`;
- recipient validates own MAX identity;
- preview + explicit Join;
- no automatic MAX group membership;
- `:share`/copy fallback.

## Dependency policy

- TS SDK: only if backend already Node/TS; pin reviewed release.
- Go client/maxbot: only if backend already Go; pin exact module tags.
- Python official-org fork: audit before use; code is stale relative to current platform changes.
- Third-party frameworks: references, not default dependencies.
