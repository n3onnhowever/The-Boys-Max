# CODEX ACTIONS — repository/host handoff

Exact project paths are intentionally not invented because The Boys repo was unavailable to this research runtime.

## 0. Do not change

- frozen P0;
- solo-first;
- provider/domain model;
- do not make social mandatory;
- do not add Kafka/Redis/framework solely for MAX;
- do not migrate React solely for MAX UI;
- do not enable Smart Povod sending before legal gate;
- do not use ChatButton/group-member-add architecture.

## 1. Locate/audit

Find actual equivalents of frontend `package.json`, Mini App bootstrap, Bridge wrapper, auth client, backend auth service, MAX API config, webhook handler/subscription bootstrap, env templates, user/favorite/follow models, router/detail, deployment cert config, privacy/terms/delete surfaces.

Search strings:
`initDataUnsafe`, `initData`, `platform-api.max.ru`, `platform-api2.max.ru`, `startapp`, `start_param`, `open_app`, `shareMaxContent`, `shareContent`, `DeviceStorage`, `SecureStorage`, `chat_title`, `start_payload`, `/chats/`, `X-Max-Bot-Api-Secret`, bot-token names, raw `plan_id`/`occurrence_id` in share URLs.

Save grep result as evidence.

## 2. Identity contract

Implement/verify `validate_max_init_data(raw)`:
- duplicate-aware parse;
- exactly one hash;
- canonical decode/sort;
- HMAC per MAX docs;
- constant-time compare as hardening;
- auth_date policy;
- signed user parse;
- require user id;
- nullable profile fields;
- never trust client identity.

Tests: valid, bad/missing/duplicate hash, duplicate key, tampered user/start_param, stale/future auth_date, null profile fields.

## 3. Session spike

Test same-origin HttpOnly Secure cookie Android/iOS/Web before building a session subsystem. If it fails, use signed-initData revalidation or smallest safe fallback. No refresh-token rotation for hackathon.

## 4. Client adapter

Create/verify one semantic MAX adapter for platform/version, BackButton, openLink/openMaxLink, shareMaxContent/shareContent and feature fallback. Pages should not call `window.WebApp` everywhere.

## 5. MAX UI gate

Read current React/ReactDOM. If not compatible with `@maxhub/max-ui@0.5.0` exact peers, do not add/upgrade only for MAX UI. If compatible, pin exact version and visual-test.

## 6. Bot API

- base `https://platform-api2.max.ru`;
- header auth only;
- bot token server-only;
- host trust store PASS;
- no legacy host.

If Node/TS, official SDK v0.3.1 is verified baseline; still hide behind adapter.

## 7. Webhook

- HTTPS;
- shared secret;
- idempotency;
- fast safe 200;
- duplicate-safe handlers;
- subscription startup/health check;
- no simultaneous production long polling.

## 8. Context tokens — only when P1/Stretch starts

Minimal conceptual fields: `token_hash`, `kind`, `resource_id`, optional `expected_user_id`, `expires_at`, `revoked_at`, optional uses.

Use >=128-bit random base64url, short prefixes `o_`, `sp_`, `p_`. Never authorize from raw resource id.

## 9. Smart Povod spike — legal gate first

Follow → explicit `?start=sp_<token>` → `bot_started` → one test message → `open_app` payload → exact occurrence. Save outgoing body, sanitized update, received context and route result. Handle `bot_stopped`/`dialog_removed`.

## 10. Shared Plan spike — Stretch

Plan → opaque invite → `shareMaxContent` → `startapp` → second user → preview → explicit join. Add IDOR/expired/revoked tests. No MAX group auto-membership.

## 11. Compliance audit

Locate or add smallest compliant surfaces: operator/app info, Privacy Policy, Terms, support contact, account/data deletion request path. Do not create a large settings subsystem.

## 12. Host evidence

Save TLS/API smoke, webhook public HTTPS, subscription check, env/static scan proving bot token absent from frontend.

## 13. Evidence files to produce

`max_runtime_matrix.json`, `max_identity_validation_tests.txt`, `max_webhook_smoke.json`, `max_open_app_payload_probe.json`, `max_share_probe.json`, `max_tls_probe.txt`, `max_dependency_snapshot.json`, `max_legal_manual_gate.md`.

Every evidence record: date, client/app version, PASS/FAIL/UNKNOWN.

## 14. Presentation cleanup

Find slide/source that says hackathon MVP = 2–3 cities/map/subscriptions/invite. Align with actual source-of-truth freeze before final presentation export.
