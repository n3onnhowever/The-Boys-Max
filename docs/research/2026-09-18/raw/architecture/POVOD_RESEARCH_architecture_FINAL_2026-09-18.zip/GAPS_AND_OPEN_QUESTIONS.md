# GAPS AND OPEN QUESTIONS

## BLOCKERS

### B1 — current repository HEAD/runtime
The connected GitHub context cannot see `The-Boys-Max`. The freshest accessible baseline is dated 2026-09-16 and has no remote. It explicitly does not prove runtime acceptance.

Needed:
- current Git SHA;
- `package.json` / lock;
- Node version;
- Compose services/images;
- current worker code;
- database and Redis/Valkey runtime;
- current migration state.

### B2 — provider-specific operational envelope
Needed from the selected provider/live gate:
- exact documented quota if any;
- observed 429 behavior;
- `Retry-After` behavior;
- timeout distribution;
- pagination/resume behavior;
- stable occurrence/session identifiers;
- partial response semantics.

## OPEN QUESTIONS

1. Is one periodic provider sync sufficient for P0?
2. Is stale-on-read refresh actually required for P0?
3. Is BullMQ already in current HEAD?
4. Is Redis/Valkey already required by another verified component?
5. Is Node >=22.12 in local and Docker runtime?
6. Is PostgreSQL >=13 and canonical?
7. Are DB credentials allowed to create/update job schema?
8. Is PgBouncer present and, if so, which pooling mode?
9. How should a provider without stable session IDs reconcile reschedules?
10. What is the freshness SLO for Moscow demo data?

## HUMAN / MANUAL DECISIONS

- Choose acceptable event freshness interval.
- Decide whether to remove an existing queue only if it is unverified/dead code; never rewrite a working P0 merely for preference.
- Approve provider-specific occurrence reconciliation rules.
- Confirm any hosting scheduler if the no-queue path is chosen.

## LEGAL CHECKS

Not a P0 blocker under the recommended design.

Only if later selected:
- Redpanda BSL/RCL;
- Inngest server SSPL/future license;
- Redis exact version/license option;
- hosted workflow-platform terms/data residency.
