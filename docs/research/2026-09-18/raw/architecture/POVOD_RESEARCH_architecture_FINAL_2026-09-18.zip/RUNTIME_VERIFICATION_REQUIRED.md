# RUNTIME VERIFICATION REQUIRED

Nothing in this research is `VERIFIED BY RUNTIME` for the final Povod queue architecture.

## Gate 0 — capture actual project state

Save:
```text
git rev-parse HEAD
git status --short
node --version
npm --version
package.json dependency extract
lockfile queue/redis dependency extract
docker compose config --services
docker compose config --images
PostgreSQL SELECT version()
Redis/Valkey INFO server if a service exists
```

Also capture the current contents or hashes of:
- `apps/worker/main.ts`
- `compose.yaml`
- `compose.release.yaml`
- `package.json`
- lockfile
- `packages/persistence/db.ts`
- `packages/platform/governor.ts`
- `packages/platform/governor.lua`

## Decision after Gate 0

### Existing BullMQ + Redis/Valkey
Do not migrate. Run the failure suite below.

### No queue and only one periodic sync
Do not add a queue. Test the scheduled command + durable `provider_sync_run`.

### Need durable delayed/retried jobs + Node >=22.12 + PostgreSQL >=13
Create an isolated pg-boss spike on a branch. Candidate exact version: `12.33.2`.

## Failure suite

1. enqueue → restart → still executes;
2. SIGKILL before business commit → retry;
3. SIGKILL after business commit before handler ack → retry with zero duplicate effect;
4. same provider payload twice → same canonical entity set;
5. partial pagination failure → no absence deletion;
6. malformed item → item failure/quarantine, batch continues where safe;
7. 429 + Retry-After → delayed retry;
8. 503/network timeout → bounded retry;
9. permanent 4xx/schema rejection → no retry storm;
10. exhausted attempts → visible terminal/DLQ state;
11. graceful SIGTERM → no new admission, active work handled according to library contract;
12. schedule survives restart;
13. older observation arrives after newer → no rollback;
14. DB outage during external side-effect preparation → side effect does not happen without durable intent.

## Evidence to save

- command log;
- exact Git SHA;
- exact package lock diff;
- Docker service/version output;
- test results;
- DB row counts before/after duplicate/kill tests;
- one 429/Retry-After trace if provider can safely reproduce it;
- one partial sync trace;
- one worker SIGKILL/recovery trace.

## Pass rule

Only after this evidence may the selected queue path be marked `VERIFIED BY RUNTIME`.
