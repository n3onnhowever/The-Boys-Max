# POVOD Research Archive — Architecture

**Project:** «Повод»  
**Team:** The Boys  
**Topic:** Architecture / async jobs / queues / durable execution  
**Research version:** FINAL-2026-09-18  
**Verification status:** FINAL WITH OPEN BLOCKERS  
**Verification date:** 2026-09-18

## What is inside

This archive is the canonical verification package for the Architecture Red Team performed in the existing research thread. It does **not** restart product design and it does **not** expand the frozen P0.

Core project constraint used throughout:

`MAX → validated MAX identity → interests/constraints → live events → concrete Occurrence → date/time/place → price or honest UNKNOWN → provenance/source → open primary source → optional save`

Social continuation remains optional. Smart Povod notifications remain P1.

## Final status

The technology comparison itself is closed enough to stop re-running queue bake-offs during implementation.

**Final architecture rule:**
1. First test whether P0 needs a generic queue at all. If one periodic provider sync plus durable database checkpoints is sufficient, do not introduce a queue framework.
2. If durable background jobs are required and the current runtime is Node.js `>=22.12` with canonical PostgreSQL `>=13`, use **pg-boss as the conditional P0 default**, after a repository/runtime gate and exact-version smoke test.
3. If the current HEAD already contains a **runtime-verified BullMQ + Redis/Valkey path**, keep it through the hackathon rather than migrating.
4. Do not introduce Kafka, Redpanda, Temporal, Trigger.dev or Inngest for frozen P0.

The current project HEAD as of 18 September was not accessible through the connected GitHub account, and the available 16 September baseline explicitly does not prove npm/build/Docker/PostgreSQL/Redis/MAX/live-provider/E2E runtime. Therefore the selection of pg-boss is a **recommendation contingent on a short runtime gate**, not a claim about current implementation.

## Most important corrections to the previous result

- `pg-boss` changed from an apparently unconditional selection to a **conditional implementation decision**.
- A **no-generic-queue P0** is now an explicit simpler option.
- BullMQ v6 PostgreSQL is officially feature-parity at the API level; it is deferred because the PostgreSQL backend is very new, not because features are missing.
- Smart Povod notification delivery is **P1**, not P0.
- A fallback Occurrence ID built from mutable start time / venue is rejected as a permanent identity.
- Retry counts, timeouts and concurrency values are proposals until the actual provider contract/runtime is verified.
- Redis licensing was added to the verification: Redis 8+ is tri-licensed (RSALv2 / SSPLv1 / AGPLv3); BullMQ also officially supports Valkey, which is BSD-3-Clause. This does not create a reason to add either datastore to P0.

## Archive map

- `FINAL_REPORT.md` — full verified report.
- `EXECUTIVE_VERDICT.md` — short decision memo.
- `FACT_CHECK_MATRIX.csv` — claim/evidence status.
- `CLAIMS_EVIDENCE.csv` — normalized claim-to-evidence table.
- `DECISION_MATRIX.csv` — technology decision matrix.
- `SOURCE_MANIFEST.csv` / `.json` — primary-source manifest.
- `DECISION_DELTA.md` — previous vs final conclusion.
- `GAPS_AND_OPEN_QUESTIONS.md` — remaining unknowns.
- `RECOMMENDATIONS.md` — actionable recommendations only.
- `RISKS.md` — technical, operational, data, security and legal-adjacent risks.
- `RUNTIME_VERIFICATION_REQUIRED.md` — executable verification gate.
- `CODEX_ACTIONS.md` — implementation handoff.
- `machine_summary.json` — synthesis-friendly summary.
- `evidence/` — metadata and verification notes; no copyrighted source copies.

## Quality status

All major conclusions in this archive are labeled as FACT, INFERENCE, RECOMMENDATION, PROPOSAL, OPEN QUESTION or BLOCKER. No «works / stable / production-ready» claim is made for the Povod runtime without runtime evidence.
