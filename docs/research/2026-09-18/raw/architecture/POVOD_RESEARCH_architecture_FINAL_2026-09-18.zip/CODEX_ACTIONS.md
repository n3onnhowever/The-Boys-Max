# CODEX ACTIONS

This file is an implementation handoff. It does not authorize changing frozen P0 scope.

## Non-negotiable decisions

Do not change:
- solo-first P0;
- MAX validated identity;
- Event vs Occurrence split;
- honest UNKNOWN;
- provenance/source;
- optional save;
- social flow optional;
- Smart Povod notifications remain P1;
- no Kafka/Redpanda/Temporal/Trigger/Inngest in P0.

## Phase A — read-only repository gate

Codex/host must inspect current HEAD and produce a small evidence artifact containing:
1. Git SHA / clean state;
2. Node version;
3. package + lock queue/redis/postgres dependencies;
4. Compose services/images;
5. DB version;
6. current worker path;
7. current provider-sync entrypoint;
8. whether Redis/Valkey is used by `governor.*` or another runtime.

No code changes before this gate.

## Phase B — choose exactly one path

### Path 1 — existing runtime-verified BullMQ
KEEP it.
- Do not migrate to pg-boss.
- Add missing business idempotency, partial-sync protection and failure tests.
- If jobs are emitted after PostgreSQL changes into Redis/Valkey, add a transactional outbox unless an equivalent atomic mechanism already exists.

### Path 2 — no generic queue needed
Implement/retain:
- one scheduled idempotent sync command;
- `provider_sync_run` state;
- durable checkpoint;
- bounded retry;
- failure visibility.
Do not grow this into a homemade queue framework.

### Path 3 — pg-boss
Prerequisites:
- Node >=22.12;
- PostgreSQL >=13;
- migration privileges/strategy accepted.

Then:
- pin exact tested pg-boss version (candidate 12.33.2);
- add one queue abstraction module;
- wire `apps/worker/main.ts`;
- create only needed queues/jobs;
- use polling unless LISTEN/NOTIFY has a measured need;
- if LISTEN/NOTIFY is enabled, verify connection/pooler topology;
- do not run long provider HTTP calls inside a long database transaction;
- use the same DB transaction only for short domain-write + enqueue coupling.

## Files likely to change if Path 3 is selected

Exact names must be confirmed from current HEAD:
- `package.json`
- package lock
- `apps/worker/main.ts`
- `packages/persistence/db.ts`
- one new `packages/jobs/*` or minimal `packages/platform/jobs.ts`
- additive migration
- `.env.example`
- `docs/current/DECISIONS.md`
- tests under `tests/integration` / `tests/unit`

Do not edit Mini App UX solely because of queue choice.

## Data model changes to evaluate

Only add fields/tables if missing:
- `provider_sync_run`
- durable checkpoint / page cursor state
- provider event stable key
- provider occurrence stable key when available
- local stable occurrence ID
- `source_version_hash`
- `material_hash`
- observation timestamps
- parse/import error record

## Tests Codex must write

- duplicate import;
- duplicate save;
- kill before commit;
- kill after commit/before return;
- partial page failure;
- 429 delayed retry;
- timeout/503 bounded retry;
- non-retryable schema/4xx;
- DLQ/terminal failure;
- restart schedule;
- stale-after-new;
- reschedule without duplicate occurrence.

## Evidence Codex must preserve

- pre-change Git SHA;
- final Git SHA;
- dependency version;
- compose config;
- DB schema diff;
- test output;
- worker restart/kill logs;
- row-level before/after for duplicate tests.

## Decisions Codex must not “improve”

- no Kafka;
- no Redpanda;
- no Temporal;
- no workflow SaaS/self-host platform;
- no queue per normalization step;
- no P1 notification runtime;
- no multi-provider expansion;
- no Redis/Valkey service unless Path 1 already has it or a separately approved need exists.
