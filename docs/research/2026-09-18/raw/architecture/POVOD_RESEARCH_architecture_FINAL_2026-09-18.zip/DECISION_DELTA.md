# DECISION DELTA — Previous conclusion vs final verified conclusion

| Area | Previous conclusion | Final verified conclusion | Why changed | Impact |
|---|---|---|---|---|
| Primary P0 queue | PostgreSQL + pg-boss stated close to final | pg-boss is the **conditional default only if a generic queue is required and runtime prerequisites pass** | current HEAD/runtime unavailable; architecture must not claim implementation fact | HIGH |
| Need for queue | assumed durable queue | explicitly test **no generic queue** first | one provider/one city/one periodic sync may be simpler | HIGH |
| Existing BullMQ | keep only if already integrated | UNCHANGED AFTER VERIFICATION; keep if runtime-verified | migration risk remains higher than theoretical cleanup | HIGH |
| BullMQ PostgreSQL | treated as immature/uncertain | official docs state full API parity; **defer because backend is new**, not incomplete | v6 PG launched 2026-07-30; early PG fixes observed | MEDIUM |
| Smart Povod notifications | mixed into queue contract discussion | **P1 only; defer from P0** | current source-of-truth scope freeze | HIGH |
| Occurrence fallback ID | event + start + venue could serve as deterministic identity | **rejected as permanent identity**; mutable fields only matching/reconciliation hints | reschedule/move creates false new occurrence | HIGH |
| Retry numbers | 10s, 5 attempts, concurrency 2 presented strongly | numerical values are **PROPOSED spike defaults** | provider quotas/runtime not verified | MEDIUM |
| P0 concurrency | 2 provider HTTP requests | start **1 per provider** until provider evidence supports more | safest fail-soft behavior | MEDIUM |
| pg-boss latest | install current exact version | `12.33.2` is a candidate exact pin **only after smoke tests** | same-day release + active patch cadence | MEDIUM |
| pg-boss notify | implicit fast queue | LISTEN/NOTIFY is optional; polling is fine for P0; pooler caveats recorded | official constructor/backend docs | LOW/MEDIUM |
| Graphile Worker | reject | UNCHANGED AFTER VERIFICATION; rejection strengthened | documented 4h crash-lock and job-key caveats | MEDIUM |
| Kafka | reject P0 | UNCHANGED AFTER VERIFICATION | workload remains job-shaped | HIGH |
| Redpanda | reject P0 | UNCHANGED AFTER VERIFICATION; license details corrected | BSL 1.1 current Community terms | MEDIUM |
| Temporal | defer | UNCHANGED AFTER VERIFICATION | no long-lived workflow requirement | HIGH |
| Trigger.dev | defer | UNCHANGED; self-host footprint shown larger than earlier summary | current compose/dev stack evidence | MEDIUM |
| Inngest | defer | UNCHANGED; built-in idempotency clarified as 24h | current official docs | MEDIUM |
| Redis licensing | not deeply handled | Redis 8+ tri-license verified; Valkey BSD option noted | previously missing licensing layer | MEDIUM |
| Outbox | use crossing DB→external queue | UNCHANGED; same-Postgres domain+pg-boss transaction does not need a separate outbox | atomicity boundary reasoning verified | HIGH |
| Exactly once | avoid external exactly-once claim | UNCHANGED AFTER VERIFICATION | external HTTP side effects remain outside DB transaction | HIGH |
