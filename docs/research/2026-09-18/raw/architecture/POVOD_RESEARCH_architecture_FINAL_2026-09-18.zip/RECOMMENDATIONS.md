# RECOMMENDATIONS — Actionable only

## 1. Stop comparing queues after one repository gate
Run the gate in `RUNTIME_VERIFICATION_REQUIRED.md` and choose:
- existing verified BullMQ → KEEP;
- no generic queue needed → use idempotent scheduled sync + durable DB checkpoint;
- otherwise Postgres + Node>=22.12 → spike pg-boss.

## 2. Make business correctness independent of the queue
Add/confirm database invariants for provider IDs, saves, source observations and material state. Queue deduplication is an optimization only.

## 3. Keep the P0 job surface tiny
At most:
- `provider.sync.v1`;
- `provider.refresh.v1` only if ad-hoc stale refresh is demonstrably required.

Normalization stays in-process within the fetch/write job.

## 4. Correct occurrence identity
Prefer a provider-stable occurrence/session ID. If unavailable, issue a local stable ID and reconcile provider observations with provider-specific matching. Never use mutable date/place as the permanent identity.

## 5. Treat partial sync as partial
Only complete validated reconciliation can drive absence-based stale/removal logic.

## 6. Provider retry policy
- do not retry ordinary 4xx;
- retry transient network/408/429/5xx selectively;
- honor `Retry-After`;
- bounded exponential backoff with jitter;
- start concurrency at 1 per provider until provider evidence supports higher.

## 7. Pin exact queue version after test
Candidate pg-boss: 12.33.2 as of 2026-09-18. Pin the exact version that passes Povod smoke/kill tests; do not float major/minor ranges before submission.

## 8. Keep Smart Povod notification infrastructure in P1
When P1 is activated, add a durable notification-delivery ledger and rate-limit/ambiguous-send handling. Do not build it for P0.

## 9. Preserve an evolution seam, not future infrastructure
Use simple job/domain interfaces so Kafka/Redpanda/Temporal can be introduced later if the workload changes category. Do not deploy them now.
