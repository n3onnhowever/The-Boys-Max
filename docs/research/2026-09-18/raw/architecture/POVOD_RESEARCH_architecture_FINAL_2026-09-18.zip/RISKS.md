# RISKS

## P0 / delivery

| Risk | Severity | Mitigation |
|---|---:|---|
| Choosing queue before seeing current HEAD | High | repository/runtime gate |
| New dependency breaks Node compatibility | High | check Node >=22.12 before pg-boss |
| Queue migration DB permissions fail | High | migration smoke on clean and existing DB |
| Queue work becomes critical-path latency | Medium | keep user reads independent from queue availability |
| New infra consumes hackathon time | High | no Redis/broker/platform unless already verified |

## Data integrity

| Risk | Severity | Mitigation |
|---|---:|---|
| Duplicate imports | High | DB unique keys/upsert/hash |
| Reschedule creates duplicate occurrence | High | stable provider ID/local stable ID + reconciliation |
| Partial sync deletes valid data | Critical | complete/partial state gate |
| Stale response overwrites fresh | High | observation/version guard |
| Parser error becomes UNKNOWN | High | separate error classification |
| Queue dedup assumed exactly-once | High | business DB idempotency |

## Operational

| Risk | Severity | Mitigation |
|---|---:|---|
| 429 retry storm | High | Retry-After, delayed retry, low concurrency |
| provider outage | Medium | bounded retry, failed-run visibility, next schedule |
| worker hard kill | High | kill test; repeat-safe handler |
| DB outage | High | fail closed; no external side effect without durable intent |
| same-DB queue load | Low for P0 | single worker, low concurrency, observe DB |
| same-day library update | Medium | exact version pin + smoke |

## Security
Queue payloads should contain identifiers, not secrets or large raw provider blobs. Credentials remain in existing secret/config path. Do not log provider tokens or MAX credentials.

## Legal
No new legal service is needed by the recommended P0. Redpanda/Inngest/Redis licenses are documented because they were compared, not because they are recommended.
