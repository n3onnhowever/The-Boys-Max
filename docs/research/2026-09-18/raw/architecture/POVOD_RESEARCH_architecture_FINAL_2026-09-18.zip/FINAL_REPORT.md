# FINAL REPORT — Architecture Red Team

## 1. EXECUTIVE SUMMARY

This report verifies the previous Architecture Red Team for «Повод» as of **2026-09-18**. It is a verification pass, not a new architecture exercise.

The principal conclusion survives: **Kafka/Redpanda and durable workflow platforms are unnecessary for the frozen P0.** The previous report, however, was too strong in several implementation-level statements. The corrected decision is conditional on the actual repository/runtime.

### Final architecture policy

**RECOMMENDATION**

1. Prefer **no generic queue** if a single scheduled, idempotent provider sync with durable database checkpoints is sufficient for the real P0.
2. If durable job primitives are needed, **pg-boss is the conditional P0 default** when the actual runtime is Node.js >=22.12 and PostgreSQL >=13, because it avoids a second durable datastore and can enqueue work inside the same PostgreSQL transaction as domain changes.
3. If BullMQ + Redis/Valkey already exists in current HEAD and is **VERIFIED BY RUNTIME**, keep it through the hackathon; migration risk is larger than the theoretical simplification.
4. Defer Kafka, Redpanda, Temporal, Trigger.dev and Inngest until the workload changes category.

**BLOCKER**

No current 18 September project HEAD/runtime was available. The accessible 16 September baseline proves repository structure only and explicitly excludes runtime acceptance. Therefore there is no runtime evidence that PostgreSQL, Redis, BullMQ or pg-boss is currently active.

---

## 2. FINAL VERDICT

### P0

**KEEP**
- frozen solo-first product flow;
- validated MAX identity boundary;
- `Event != Occurrence`;
- provenance and source link;
- honest `UNKNOWN`;
- idempotent persistence;
- existing API / worker / persistence boundaries visible in the baseline.

**CHANGE / ADOPT CONDITIONALLY**
- make background sync correctness database-authoritative;
- choose no generic queue if possible;
- otherwise use pg-boss only after the short repository/runtime gate.

**DEFER**
- Smart Povod notification delivery runtime to P1;
- multi-provider event fan-out;
- Temporal-style workflows;
- event streaming infrastructure.

**REJECT FOR P0**
- Kafka;
- Redpanda;
- self-hosted Trigger.dev;
- self-hosted Inngest;
- custom general-purpose `SKIP LOCKED` queue;
- adding Redis/Valkey only to make a queue library possible;
- BullMQ PostgreSQL as a new pre-deadline adoption.

There is no functional P0 scope expansion in this report.

---

## 3. WHAT WAS VERIFIED

### Project evidence

**FACT — CONFIRMED from available project baseline**

The 2026-09-16 local Git baseline contains:
- `apps/api/*`;
- `apps/worker/main.ts`;
- `compose.yaml` and `compose.release.yaml`;
- migrations;
- `modules/search/core/*`, including normalizers/provider/search;
- `packages/persistence/*`;
- `packages/platform/*`, including `governor.lua`;
- tests including a kill-worker helper.

The same baseline explicitly states it does **not** establish npm/build, Docker, PostgreSQL, Redis, browser, MAX, live-provider, live-AI or end-to-end acceptance.

**OPEN QUESTION**

The canonical named product documents were not directly retrievable by exact filename in the available file index during this pass. Their governing constraints were taken from the current project thread and recovered project context; no hidden scope change was made.

### External technology evidence

Verified against official docs, official repositories, release APIs, license files and standards:
- BullMQ;
- Redis;
- Valkey;
- pg-boss;
- Graphile Worker;
- Apache Kafka;
- Redpanda;
- Temporal;
- Trigger.dev;
- Inngest;
- PostgreSQL queue primitives;
- transactional outbox guidance;
- HTTP 429 / Retry-After semantics;
- MAX messaging limits relevant to future P1 notifications.

No Povod queue implementation was executed in this pass.

---

## 4. CURRENT STATE AS OF 18.09.2026

### Project

| Area | Status | Evidence level |
|---|---|---|
| Frozen P0 | CONFIRMED | project source-of-truth constraints in current thread |
| Repo structure | CONFIRMED for 2026-09-16 baseline | project transcript |
| Current 2026-09-18 HEAD | UNKNOWN | connected GitHub cannot see repository; no fresh archive supplied |
| PostgreSQL runtime | NEEDS RUNTIME VERIFICATION | baseline explicitly does not prove it |
| Redis/Valkey runtime | NEEDS RUNTIME VERIFICATION | baseline explicitly does not prove Redis |
| Existing BullMQ | UNKNOWN | current package/lock not available |
| Existing pg-boss | UNKNOWN | current package/lock not available |
| Worker crash/restart behavior | NEEDS RUNTIME VERIFICATION | no run performed |
| Live provider retry/rate contract | OPEN QUESTION | provider-specific research/runtime gate |
| MAX P1 notification flow | DEFER | outside frozen P0 |

### Open-source projects

All compared projects are active as of 18 September 2026; none of the core compared repositories is archived.

- pg-boss: `12.33.2`, released 2026-09-18; MIT; Node >=22.12.
- BullMQ: `6.3.7`, released 2026-09-18; MIT; PostgreSQL backend introduced in v6.0.0 on 2026-07-30.
- Graphile Worker: `0.18.0`, 2026-09-08; MIT; Node >=22.18, PostgreSQL 12+.
- Apache Kafka: supported release `4.3.1`, 2026-06-25; Apache-2.0.
- Redpanda: `v26.2.2`, 2026-08-22; Community core under BSL 1.1 with Additional Use Grant and four-year change date to Apache-2.0.
- Temporal server: `v1.32.0`, 2026-09-11; MIT.
- Trigger.dev: `v4.6.3`, 2026-09-17; repository Apache-2.0.
- Inngest server/CLI: `v1.45.1`, 2026-09-17; SSPL with future Apache-2.0 grant in repository license.
- Valkey: `9.1.2`, 2026-09-01; BSD-3-Clause.
- Redis 8+: tri-licensed RSALv2 / SSPLv1 / AGPLv3.

Release freshness is **maintenance evidence**, not Povod runtime-quality evidence.

---

## 5. KEY FINDINGS

### 5.1 The problem is currently a job problem, not an event-stream problem

**FACT**

The listed current asynchronous needs center on:
- provider synchronization;
- fetch retries;
- scheduled refresh;
- stale refresh;
- import deduplication.

**INFERENCE**

These are queue/job semantics. They do not require a durable replayable log shared by multiple independently deployed consumers.

**RECOMMENDATION**

Do not introduce Kafka/Redpanda until there are real independently deployed consumers, replay requirements, retained domain events, partition-ordering requirements, or CDC/event-log semantics.

### 5.2 First challenge the premise that P0 needs a queue

**INFERENCE**

For one provider, one city and a single background synchronization path, an idempotent scheduled command plus durable sync/checkpoint tables can be simpler than any queue framework.

**RECOMMENDATION**

Before adding pg-boss, answer one implementation question: does frozen P0 require more than one independently retryable/delayed unit of work?

If no, do not add a generic queue. If yes, use a queue.

### 5.3 pg-boss is the best *conditional* database-backed fit

**FACT — VERIFIED BY OFFICIAL DOCS / SOURCE**

pg-boss:
- requires Node >=22.12;
- targets PostgreSQL 13+;
- supports retries/backoff, delayed work, schedules, queue policies and dead-letter queues;
- can insert jobs using an existing database transaction through its database-adapter path;
- supports LISTEN/NOTIFY, with polling fallback;
- has current same-day maintenance activity and release 12.33.2.

**HIDDEN COSTS**

- schema migration privileges matter;
- LISTEN/NOTIFY may require a dedicated connection;
- PgBouncer transaction/statement pooling is incompatible with LISTEN/NOTIFY semantics;
- recent releases and a fixed July 2026 retry-backoff bug show that exact-version pinning and smoke tests matter;
- `useListenNotify` is not something to turn on merely for elegance; P0 does not need sub-second queue latency.

**RECOMMENDATION**

Candidate: exact tested pg-boss version `12.33.2`. Do not auto-upgrade to latest merely because it is current; pin the version that passes the project smoke suite.

### 5.4 BullMQ is fully capable; the question is dependency shape

**FACT**

BullMQ v6 provides both Redis-family and PostgreSQL backends. Official v6 PostgreSQL documentation states datastore-agnostic API parity for Queue, Worker, QueueEvents, FlowProducer, Job Schedulers, rate limiting, delays, priorities, deduplication, metrics and events.

**FACT**

The PostgreSQL backend was introduced on 2026-07-30. Early 6.0.x releases included PostgreSQL-specific fixes and migration refinements.

**INFERENCE**

The backend is not functionally “incomplete” by documentation, but it has a much shorter production-history window than BullMQ-on-Redis.

**RECOMMENDATION**

- If BullMQ+Redis/Valkey is already verified in Povod: KEEP.
- For a new P0 install: do not choose BullMQ+Redis solely because BullMQ is familiar.
- Do not adopt BullMQ PostgreSQL as a new deadline-critical backend without a dedicated runtime spike; pg-boss has a simpler Postgres-first mental model for this P0.

### 5.5 Redis licensing must be separated from BullMQ licensing

**FACT**

BullMQ is MIT.

Redis 8+ is available under a choice of RSALv2, SSPLv1 or AGPLv3. Redis 7.4–7.8 uses RSALv2/SSPLv1; 7.2 and earlier were BSD-3-Clause.

BullMQ officially documents Valkey support; Valkey is BSD-3-Clause.

**INFERENCE**

Licensing is not a technical blocker to an ordinary self-hosted BullMQ setup, but “BullMQ is MIT” is insufficient as a complete license statement for the stack.

**RECOMMENDATION**

Do not add Redis/Valkey to P0 unless there is another justified role or BullMQ is already present. If a Redis-compatible backend becomes necessary, choose the exact server/version deliberately and record its license.

### 5.6 Graphile Worker has a real P0 recovery drawback

**FACT**

Regular Graphile Worker can leave hard-crashed/SIGKILL jobs locked for at least four hours; automated sweeping makes them available after that threshold. Faster heartbeat recovery is part of Worker Pro.

**FACT**

`job_key` is not a permanent business idempotency ledger; locked jobs can cause a second job to be scheduled, and current docs warn of a high-contention race where `add_job` can return null.

**RECOMMENDATION**

Do not choose Graphile Worker for Povod P0 over pg-boss.

### 5.7 Temporal is a different abstraction

**FACT**

Temporal is a durable execution platform intended to preserve and resume workflow execution across process, network and infrastructure failures.

**INFERENCE**

Povod currently has jobs, not a workflow graph that lives for days and waits for signals/human actions.

**RECOMMENDATION**

Consider Temporal only if a future flow has several durable activities plus timers/signals/compensations and needs complete workflow history.

### 5.8 Trigger.dev and Inngest are maintained but add platform surface

**FACT**

Trigger.dev self-hosting currently pulls a platform stack including PostgreSQL, Redis, ClickHouse and s2 in its published Docker setup; its development stack also includes Electric and MinIO.

**FACT**

Inngest self-host defaults to in-memory Redis + SQLite for single-node convenience; scaling/self-host guidance introduces external Redis and PostgreSQL. Its documented event/function idempotency window is 24 hours.

**INFERENCE**

Both can give excellent developer ergonomics, but neither removes infrastructure for Povod self-hosting; they replace a small queue problem with a platform problem.

**RECOMMENDATION**

DEFER.

### 5.9 Queue-level deduplication is not business idempotency

**FACT / INFERENCE**

Any queue can redeliver after crashes, lock expiry or ambiguous side effects. HTTP calls cannot generally be made atomic with a PostgreSQL transaction.

**RECOMMENDATION**

Business uniqueness lives in the Povod database:
- provider entity keys;
- save uniqueness;
- import-version/hash tracking;
- material-change ledger;
- P1 notification delivery uniqueness.

Do not advertise “exactly-once notifications” or “exactly-once provider effects.”

---

## 6. WHAT CHANGED SINCE PREVIOUS ANALYSIS

See `DECISION_DELTA.md` for the full table.

Most important changes:

1. **pg-boss is conditional, not already selected by fact.**
2. **No generic queue is a valid P0 candidate.**
3. **BullMQ/PostgreSQL is officially feature-parity; maturity, not missing APIs, is the reason to defer new adoption.**
4. **Smart Povod notification runtime is P1.**
5. **Mutable Occurrence fingerprint is no longer allowed as permanent ID.**
6. **Retry/timeouts/concurrency are proposed defaults, not verified provider policy.**
7. **Redis/Valkey licensing and compatibility are now included.**
8. **pg-boss LISTEN/NOTIFY/PgBouncer caveats are explicit.**
9. **Current repository/runtime accessibility is a formal blocker.**

---

## 7. CONFIRMED FACTS

### pg-boss
- Active, non-archived MIT repository.
- Release 12.33.2 on 2026-09-18.
- Node >=22.12 in current `package.json`.
- PostgreSQL-backed queue; transaction adapter support.
- Delayed jobs, retries, queue policies, scheduling, DLQ/redrive.
- Polling is available; LISTEN/NOTIFY is optional and has connection/pooler constraints.
- A 2026-07 backoff bug was fixed; this is evidence to make retry parameters explicit and to pin/test.

### BullMQ
- Active MIT repository.
- Node package version 6.3.7 on 2026-09-18.
- v6 PostgreSQL backend exists and official docs state API parity.
- v6 introduced breaking changes around backend abstraction and legacy repeatable jobs.
- Redis-family production guidance requires durable configuration and no-eviction semantics where applicable.
- BullMQ officially supports Valkey-compatible clients/backends.

### Graphile Worker
- Active MIT project.
- 0.18.0 current release (2026-09-08).
- Node 22.18+ / PostgreSQL 12+ current requirements.
- Four-hour hard-crash lock behavior for OSS worker is current documented behavior.

### Kafka / Redpanda
- Kafka 4.3.1 is a current supported Apache release.
- Redpanda is active and Kafka-compatible, but its Community code uses BSL 1.1 terms rather than a simple Apache-only current license.

### Durable workflow platforms
- Temporal server 1.32.0 is current and active.
- Trigger.dev 4.6.3 is active; self-hosted topology is materially larger than Povod's needed P0 runtime.
- Inngest 1.45.1 is active; self-host scale path relies on additional state services and built-in idempotency is time-bounded.

---

## 8. RECOMMENDATIONS

### 8.1 Decision gate before code

Run exactly one short gate:
1. current Git SHA;
2. Node version;
3. actual `package.json` and lock;
4. `compose.yaml` services;
5. PostgreSQL version/availability;
6. Redis/Valkey service presence;
7. current worker behavior;
8. current provider sync path.

Then:
- **existing verified BullMQ** → KEEP;
- **Postgres + Node >=22.12 + multiple durable jobs needed** → pg-boss spike;
- **single periodic sync only** → no queue framework.

### 8.2 Data-authoritative correctness

Regardless of queue:
- DB uniqueness, not queue dedup, is authoritative;
- raw/source provenance survives normalization;
- `partial_sync` never authorizes absence-based deletions;
- a stale response cannot overwrite a newer observation;
- parser failure is not `UNKNOWN`;
- all retries are safe to repeat.

### 8.3 Normalize inside the fetch job

Do not insert a separate queue boundary between provider fetch and deterministic `Event → Occurrence` normalization for P0.

### 8.4 Rate-limit conservatively

Until the live provider contract is verified:
- per-provider request concurrency starts at **1**;
- increase only with documented quota or measured evidence;
- honor `429 Retry-After` when present;
- use bounded exponential backoff with jitter;
- do not keep a worker sleeping for long cooldowns if delayed scheduling is available.

### 8.5 Exact retry numbers are proposal, not fact

A reasonable spike default:
- HTTP operation timeout: 10 seconds;
- 4 retries / 5 total attempts for transient network/5xx;
- initial delay 2 seconds;
- exponential backoff + jitter;
- max automatic backoff 60 seconds;
- `Retry-After` overrides when valid.

These numbers must be adjusted to provider behavior and are not claimed as a verified provider policy.

---

## 9. REJECTED / DEFERRED OPTIONS

| Option | Status | Reason |
|---|---|---|
| Kafka | REJECTED P0 | replayable multi-consumer event log not required |
| Redpanda | REJECTED P0 | same abstraction mismatch; additional broker ops/licensing surface |
| Temporal | DEFER | no long-lived durable workflow yet |
| Trigger.dev self-host | DEFER | platform footprint disproportionate |
| Inngest self-host | DEFER | platform/state footprint disproportionate |
| Graphile Worker | REJECTED P0 | no benefit over pg-boss for this case; crash recovery caveat |
| custom full `SKIP LOCKED` queue | REJECTED | queue semantics become Povod-owned code |
| BullMQ PostgreSQL new adoption | DEFER | new backend; deadline maturity risk |
| new Redis/Valkey solely for jobs | REJECTED unless existing BullMQ | unnecessary extra state service |
| notification runtime | DEFER P1 | not part of frozen P0 |

---

## 10. RISKS

### P0 technical
1. Current repository dependencies unknown.
2. Node version may fail pg-boss >=22.12 requirement.
3. Queue migrations may need DB privileges unavailable in deployment.
4. Same PostgreSQL failure affects app state and queue together. For P0 this is an acceptable simplicity trade-off, not high availability.
5. Queue polling/listen configuration can interact with poolers.

### Data integrity
1. mutable occurrence identity;
2. partial snapshot treated as complete;
3. stale response overwriting current state;
4. parser regression hidden as `UNKNOWN`;
5. duplicate import effects.

### Provider operations
1. undocumented quota/rate-limit behavior;
2. 429 retry storm;
3. timeout ambiguity;
4. schema drift;
5. pagination gap / resume errors.

### P1 notification
1. duplicate MAX send after ambiguous response;
2. rate limit per conversation;
3. no documented client-supplied idempotency key in the reviewed send-message endpoint.

### Legal/licensing
- Redpanda and Inngest server licenses are non-trivial; legal review would be required if those self-hosted products became serious production choices.
- Redis version/license must be recorded if Redis is chosen.
- These legal questions do not block the recommended P0 because those services are not required.

---

## 11. BLOCKERS

### BLOCKER A — current HEAD unavailable

No current GitHub remote/repository is visible to the connected account. The available baseline is 2026-09-16 and explicitly is not runtime acceptance.

**Impact:** cannot truthfully state that PostgreSQL/Redis/BullMQ/pg-boss is currently configured.

### BLOCKER B — provider-specific runtime envelope

Exact provider quotas, latency distribution and partial-failure behavior are not established in this architecture pass.

**Impact:** timeout, concurrency and retry values remain proposed.

Neither blocker requires reopening Kafka/Temporal research.

---

## 12. OPEN QUESTIONS

1. What is the exact current Git SHA on 2026-09-18?
2. What Node.js version is used in local + Docker runtime?
3. What is the actual database image/service and version?
4. Does current `package.json` contain BullMQ, ioredis, node-redis, pg-boss or another queue?
5. Does current Compose already start Redis or Valkey?
6. What does `packages/platform/governor.lua` currently govern and does it imply a Redis runtime?
7. Is provider sync already invoked by host scheduler, worker loop, API call or another mechanism?
8. Does P0 truly require ad-hoc stale refresh, or is scheduled refresh sufficient?
9. Does the selected provider expose a stable occurrence/session identifier?
10. What are the actual provider limits for requests, pagination and retry cooldowns?
11. Is PgBouncer or another transaction/statement pooler used?
12. Are application DB credentials allowed to create/migrate the queue schema?

---

## 13. REQUIRED RUNTIME TESTS

No queue choice becomes `VERIFIED BY RUNTIME` before these pass:

1. **Install/build gate** — exact dependency installs under project Node version.
2. **Migration gate** — clean database + existing database upgrade.
3. **Enqueue/consume** — persisted job survives worker restart.
4. **Kill before DB commit** — job is retried; no business duplicate.
5. **Kill after domain commit / before handler return** — retry produces no duplicate business effect.
6. **Duplicate import** — same source page twice creates no duplicate Event/Occurrence.
7. **Partial pagination** — failure on page N does not tombstone unseen records.
8. **429** — `Retry-After` becomes delayed retry, not a tight loop.
9. **Timeout / 503** — bounded retry then terminal failed/DLQ state.
10. **Poison payload** — quarantined/failed without blocking other records.
11. **Graceful shutdown** — worker stops admission and closes cleanly.
12. **Schedule/restart** — periodic job resumes after restart without duplicate logical sync.
13. **Old-after-new response** — older fetch cannot roll canonical record back.
14. **Connection outage** — DB outage does not permit external side effects without durable intent.

If choosing BullMQ+Redis/Valkey, additionally:
- durable server persistence/restart;
- eviction policy;
- Redis/Valkey outage/recovery;
- DB→queue dual-write/outbox test if jobs are emitted from domain transactions.

---

## 14. REQUIRED MANUAL / LEGAL CHECKS

### Manual
- current package/lock/compose inspection;
- provider occurrence identity semantics;
- provider quota/rate-limit documentation;
- host scheduler availability;
- DB migration permissions;
- pooler mode.

### Legal
No new legal blocker is introduced by the recommended P0.

If later choosing:
- Redpanda → verify exact Community/Enterprise feature and BSL/RCL applicability;
- Inngest self-host → verify SSPL/future-license implications for intended deployment;
- Redis → record exact Redis version and chosen license option;
- hosted Trigger/Inngest/Temporal Cloud → review service terms/data residency separately.

---

## 15. EXACT CHANGES FOR «ПОВОД»

These are **PROPOSED changes**, not claims that files have already been edited.

### Repository gate first

Capture:
- `git rev-parse HEAD`;
- `node --version`;
- package dependencies + lock;
- Compose service names/images;
- PostgreSQL server version;
- Redis/Valkey presence;
- worker entrypoint.

Save output as evidence.

### If Option 0: no generic queue

Add/confirm:
- a single idempotent provider-sync command;
- `provider_sync_run` durable status/checkpoint;
- canonical provider/entity uniqueness constraints;
- scheduled invocation via existing host/runtime scheduler;
- bounded retry inside the sync command;
- failed-run visibility.

Do not build a homemade general queue.

### If pg-boss gate passes

Candidate files:
- `package.json` / lock — exact tested pg-boss pin;
- `apps/worker/main.ts` — queue startup, handlers, graceful close;
- `packages/persistence/db.ts` — expose compatible DB transaction path if needed;
- new small queue adapter module under `packages/platform` or a dedicated `packages/jobs`;
- one additive migration for sync state/business constraints if missing;
- `compose*.yaml` — no new service solely for pg-boss;
- `.env.example` — queue schema/poll interval only if needed;
- `docs/current/DECISIONS.md` — ADR;
- tests — crash/retry/dedup/partial-sync suite.

### Job surface for P0

Keep it small:
- `provider.sync.v1`;
- optional `provider.refresh.v1` only if ad-hoc stale refresh is a proven P0 need.

Do **not** create a job for pure deterministic normalization.

### Suggested job envelope

```json
{
  "job_type": "provider.sync",
  "job_version": 1,
  "idempotency_key": "provider:<provider>:city:<city>:window:<window>:slot:<slot>",
  "correlation_id": "<uuid>",
  "created_at": "<iso8601>",
  "payload": {
    "provider": "<provider>",
    "city_id": "<city>",
    "window_start": "<iso8601>",
    "window_end": "<iso8601>",
    "sync_run_id": "<uuid>"
  }
}
```

The queue key coalesces work; it does not replace database uniqueness.

### Occurrence identity — corrected contract

Preferred:
1. provider-stable occurrence/session ID;
2. otherwise provider-specific reconciliation logic with a local stable `occurrence_id`.

A fingerprint such as `(provider_event_id, start_time, venue)` may be stored as a **matching fingerprint**, but must not be the universal immutable identity because time/venue can change on reschedule/move.

### Database idempotency examples

- `UNIQUE(provider_id, provider_event_id)`;
- `UNIQUE(provider_id, provider_occurrence_id)` where stable provider ID exists;
- `UNIQUE(user_id, occurrence_id)` for save;
- source observation/raw hash for repeated fetch detection;
- `material_hash` separate from identity.

### Sync invariants

- `partial != complete`;
- only a verified complete reconciliation may mark absent records stale/removed;
- parse failure != `UNKNOWN`;
- each canonical record keeps provenance;
- incoming observation must not overwrite a newer authoritative observation;
- checkpoint advances only after required persistence/validation commit.

---

## 16. IMPACT ON P0 / P1 / STRETCH

### P0

No product-feature expansion.

Async architecture covers only:
- provider sync;
- retry;
- scheduled refresh;
- optional proven stale refresh;
- import deduplication;
- normalization inside the job/write path.

### P1

Smart Povod:
- durable notification intent/delivery ledger;
- notification deduplication;
- MAX rate-limit handling;
- material-change triggers if required.

This must not leak into P0 implementation merely because a queue exists.

### Stretch / scale

Future multi-provider:
- provider-specific queues/rate budgets if needed;
- cross-provider reconciliation after a separate data gate.

Future event bus:
- only after multiple independent services need replay/fan-out/history.

Future durable workflow:
- only after long-lived multi-step stateful processes with timers/signals/compensations exist.

---

## 17. WHAT NOT TO DO

- Do not add Kafka or Redpanda “for future scale.”
- Do not add Temporal for simple retries and schedules.
- Do not self-host Trigger.dev/Inngest to solve two background jobs.
- Do not introduce Redis/Valkey solely to satisfy BullMQ unless BullMQ is already the verified path.
- Do not choose the newest BullMQ PostgreSQL backend merely for API familiarity without a spike.
- Do not write a full custom `SKIP LOCKED` queue.
- Do not split deterministic normalization into another async boundary.
- Do not rely on queue deduplication as business idempotency.
- Do not use mutable event time/place as permanent occurrence identity.
- Do not hard-delete records after partial provider sync.
- Do not turn parser errors into legitimate `UNKNOWN`.
- Do not retry all 4xx.
- Do not sleep a worker for long `Retry-After` periods when durable delay is available.
- Do not claim exactly-once external effects.
- Do not pull P1 Smart Povod notifications into P0.

---

## 18. SELF-CRITIQUE / RED-TEAM FINDINGS

### What if pg-boss is the wrong recommendation?

It is wrong if:
- current runtime is below Node 22.12;
- PostgreSQL is not canonical or not available to the worker;
- DB schema privileges cannot support it;
- BullMQ is already implemented and passing failure tests;
- only one periodic sync exists, making any queue framework unnecessary.

This is why the final verdict is conditional.

### Hidden cost of “one PostgreSQL”

Queue work increases load and couples job availability to application DB availability. At large scale that can be a disadvantage. For P0, the same coupling is also an operational simplification: when authoritative state is unavailable, doing side effects is usually undesirable.

### Could raw PostgreSQL be simpler?

For a single `provider_sync_run`, yes. PostgreSQL `SKIP LOCKED` is explicitly suitable for queue-like consumers, though it exposes an inconsistent view and is not a general query pattern. The danger is gradual growth into retries, schedules, heartbeats, DLQ and cleanup owned by Povod. Therefore raw SQL is acceptable only if it remains a scheduler/checkpoint, not a reimplemented queue library.

### Is BullMQ+Redis really worse?

No. It may be better if already deployed, monitored and familiar. The recommendation against adding it is about **new persistent infrastructure**, not capability.

### Is BullMQ PostgreSQL now a stronger competitor?

Yes. Official docs claim API parity, and this is a substantive update from older BullMQ assumptions. It remains a newer backend with a short operational-history window as of the hackathon date.

### Are Trigger.dev/Inngest bad?

No. Both are actively maintained and solve a broader class of background/durable execution problems. They are rejected for fit/footprint, not quality.

### Are retry numbers proven?

No. The numerical defaults in this report are a proposal to start a spike. Provider-specific limits remain authoritative.

### Is a queue sufficient for exactly-once?

No. External HTTP side effects remain ambiguous around timeout/crash boundaries. Database constraints and ledgers are still required.

### Biggest earlier analytical mistake

Treating an occurrence fallback fingerprint containing mutable start/place values as if it could be a permanent identity. The final contract explicitly corrects this.

---

## 19. MISSING AREAS CHECK

### Potentially forgotten areas checked in this pass
- Redis server licensing;
- Valkey as BullMQ-compatible alternative;
- BullMQ v6 PostgreSQL breaking/migration history;
- pg-boss runtime/version requirements;
- pg-boss LISTEN/NOTIFY and PgBouncer implications;
- Graphile crash recovery and job-key caveats;
- Trigger.dev current self-host dependency footprint;
- Inngest self-host persistence and 24h idempotency;
- smart-notification scope classification;
- mutable occurrence identity;
- standards-level `429`/`Retry-After`.

### Still impossible to close without runtime
- current Node version;
- actual Compose topology;
- actual database version;
- actual queue dependencies;
- worker restart behavior;
- provider latency/rate envelope;
- current E2E path.

### Requires human/manual decision
- whether P0 truly needs ad-hoc stale refresh versus periodic refresh;
- whether current BullMQ implementation, if present, is too costly to change;
- acceptable sync freshness interval.

### Requires legal review only if later selected
- Redpanda BSL/RCL;
- Inngest SSPL self-host;
- hosted platform service terms;
- exact Redis license choice if Redis is intentionally adopted.

### Requires Codex/host
- repository gate;
- package/compose inspection;
- implementation spike;
- kill/restart tests;
- evidence capture.

### Considered closed
- Kafka/Redpanda are not justified for frozen P0;
- Temporal is not justified for current job-shaped P0;
- business idempotency must not rely on queue-level dedup;
- separate async normalization queue is unnecessary P0;
- Smart Povod notification transport remains P1.

---

## 20. SOURCE MANIFEST

The machine-readable source manifest is in:
- `SOURCE_MANIFEST.csv`
- `SOURCE_MANIFEST.json`

Primary sources dominate the evidence base. No recommendation depends on stars or random secondary articles.

---

## 21. FINAL CHECKLIST

- [x] Major claims mapped to evidence/status.
- [x] Time-sensitive project versions rechecked on 2026-09-18.
- [x] Official docs/repositories prioritized.
- [x] GitHub archive/activity/release/license metadata checked.
- [x] Redis/Valkey license gap added.
- [x] Runtime claims separated from documentation claims.
- [x] No Povod runtime was falsely marked verified.
- [x] Frozen P0 not silently expanded.
- [x] Smart Povod corrected to P1.
- [x] Deferred/rejected options recorded.
- [x] Open questions recorded.
- [x] Decision delta recorded.
- [x] Source manifest created.
- [x] `machine_summary.json` created.
- [x] `CODEX_ACTIONS.md` created.
- [x] ZIP integrity/readability check is performed after file creation.

**Verification status: FINAL WITH OPEN BLOCKERS.**
